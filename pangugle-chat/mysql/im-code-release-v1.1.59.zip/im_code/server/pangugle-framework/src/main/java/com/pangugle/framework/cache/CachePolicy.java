package com.pangugle.framework.cache;

public enum CachePolicy {
	
	PURGE

}
