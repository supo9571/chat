package com.pangugle.framework.lucene.searcher;

public interface Descriptor {
//	private String index;
//
//	public String getIndex() {
//		return index;
//	}
//
//	public void setIndex(String index) {
//		this.index = index;
//	}
}
