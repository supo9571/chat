package com.pangugle.framework.socketio.utils;

import java.util.HashMap;
import java.util.Map;

import com.pangugle.framework.bean.SystemErrorResult;
import com.pangugle.framework.socketio.model.MyProtocol;

public class LoginProtocolUtils {
	
	private static String DEFAULT_EVENT_TYPE = "login";
	
	public static MyProtocol INVALID_TOKEN = buildResponse(10001, "invalid token");
	public static MyProtocol MULTY_CONN = buildResponse(10002, "multi client conn");
	public static MyProtocol MAX_CONN_ERR = buildResponse(10003, "server error");
	public static MyProtocol CONN_SUCCESS = buildResponse(SystemErrorResult.SUCCESS.getCode(), SystemErrorResult.SUCCESS.getError());
	
	private static MyProtocol buildResponse(int code, String msg)
	{
		MyProtocol protocol = new MyProtocol();
		protocol.setEvent(DEFAULT_EVENT_TYPE);
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("code", code);
		data.put("msg", msg);
		protocol.setData(data);
		return protocol;
	}
	

}
