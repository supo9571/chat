package com.pangugle.framework.socketio.impl;

import java.util.Map;

import com.corundumstudio.socketio.SocketIOClient;
import com.google.common.collect.Maps;
import com.pangugle.framework.log.Log;
import com.pangugle.framework.log.LogFactory;
import com.pangugle.framework.socketio.ServerEventManager;
import com.pangugle.framework.socketio.model.MessageBody;
import com.pangugle.framework.socketio.utils.LoginProtocolUtils;

public class SingleIOClientSupport implements IOClientSupport {
	
	private Map<String, SocketIOClient> mClientMaps = Maps.newConcurrentMap();

	private static Log LOG = LogFactory.getLog(SingleIOClientSupport.class);
	
	@Override
	public boolean addClient(SocketIOClient client, String userid, String accessToken) {
		// 关闭当前连接
		SocketIOClient currentClient = mClientMaps.get(userid);
		if(currentClient != null)
		{
			ServerEventManager.getIntance().sendMessage(currentClient, LoginProtocolUtils.MULTY_CONN);
			// 关闭
			currentClient.disconnect();
		}
		mClientMaps.put(userid, client);
		return true;
	}

	@Override
	public boolean removeClient(SocketIOClient client, String userid) {
		SocketIOClient cacheClient = mClientMaps.get(userid);
		if(cacheClient == client)
		{
			// 正常关闭连接
			mClientMaps.remove(userid);
			if(client.isChannelOpen()) client.disconnect();
			return true;
		}
		else
		{
			 // 有多个连接请求上来，新来的把前面踢下线
		}
		return false;
	}
	
	public SocketIOClient kickOut(String userid, String accessToken)
	{
		try {
			SocketIOClient client = mClientMaps.get(userid);
			ServerEventManager.getIntance().sendMessage(client, LoginProtocolUtils.MULTY_CONN);
			client.disconnect();
			return client;
		} catch (Exception e) {
		}
		return null;
	}

	@Override
	public boolean sendMessage(MessageBody body) {
		SocketIOClient client = mClientMaps.get(body.getToUserid());
		if(client != null)
		{
			String accessToken = client.getHandshakeData().getSingleUrlParam(ServerEventManager.KEY_ACCESS_TOKEN);
			if(accessToken.equalsIgnoreCase(body.getFromUserToken()))
			{
				LOG.error("don't send message to same client ...");
				return true;
			}
			ServerEventManager.getIntance().sendMessage(client, body.getProtocol());
			return true;
		}
		return false;
	}

	@Override
	public boolean existClient(String userid) {
		return mClientMaps.get(userid) != null;
	}

}
