//package com.pangugle.framework.redis;
//
//import org.springframework.data.redis.core.RedisTemplate;
//
//public class MyRedisTemplate extends RedisTemplate<String, String> {
//	
//
//}
