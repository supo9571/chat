package com.pangugle.framework.ffmpeg;

import java.io.File;

import ws.schild.jave.AudioAttributes;
import ws.schild.jave.Encoder;
import ws.schild.jave.EncodingAttributes;
import ws.schild.jave.MultimediaObject;
import ws.schild.jave.VideoAttributes;
import ws.schild.jave.VideoSize;

public class VideoConvert {
	
	private static String DEFAULT_FORMAT = "mp4";
	
	public static void convertMP4(File source, File target, int width, int height)
	{
		try {
			// Audio Attributes
			AudioAttributes audio = new AudioAttributes();
			audio.setCodec(AudioConvert.DEFAULT_CODEC);
			audio.setBitRate(64000);
			audio.setChannels(1);
			audio.setSamplingRate(22050);
						
			// Audio Attributes
			VideoAttributes video = new VideoAttributes();
			video.setCodec("mpeg4");
			// 设置比特率
			video.setBitRate(160000); 
			// 设置帧率, 目前网络视频的帧数一般都是30帧/秒,最低可以降到25帧/秒。高于30帧/秒,视频格式会过大。低于25帧/秒,视频会出现卡屏现象
			video.setFrameRate(25); 
			video.setSize(new VideoSize(width, height));
			
			// Encoding attributes
			EncodingAttributes  attrs = new EncodingAttributes();
			attrs.setFormat(DEFAULT_FORMAT);
			attrs.setAudioAttributes(audio);
			attrs.setVideoAttributes(video);
			
			// Encode
			Encoder encoder = new Encoder();
			encoder.encode(new MultimediaObject(source), target, attrs);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
