package com.pangugle.framework.socketio.model;

public interface IEventType {

	public String getName();
	public String getRemark();
}
