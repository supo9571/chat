package com.pangugle.framework.socketio.model;

public interface IMsgType {
	
	public String getName();
	public String getRemark();

}
