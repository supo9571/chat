export default  {
	baseUrl: '',	// 域名替换地址
	upLoadImg: '', // 服务器地址(上传图片)
};