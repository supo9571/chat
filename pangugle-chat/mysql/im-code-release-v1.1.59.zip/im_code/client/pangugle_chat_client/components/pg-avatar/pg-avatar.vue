<template>
		<view>
			<!-- 单张图片, 小程序会有问题，图片缓存这里只能是H5和APP才可以使用 -->
			<!-- #ifndef APP-PLUS | H5 | APP-VUE | APP-NVUE | APP-PLUS-NVUE -->
			<image v-if="size == 1" :src="mSingleImgUrl" mode="" class="avatar_single"></image>
			<!-- #endif -->
			
			<!-- #ifdef APP-PLUS | H5 | APP-VUE | APP-NVUE | APP-PLUS-NVUE -->
			<pg-image-cache v-if="size == 1" :imgSrc="mSingleImgUrl" class="avatar_single"></pg-image-cache>
			<!-- #endif -->
			
			<view v-else-if="size > 1 && size <= 4" class="avatar_type1">
			
				<!-- #ifndef APP-PLUS | H5 | APP-VUE | APP-NVUE | APP-PLUS-NVUE -->
				<image 
					v-for="(showImgUrl, key) in mShowImageArray" :key="getKey(showImgUrl, key)" :src="showImgUrl" mode="">
				</image>
				<!-- #endif -->
				
				<!-- #ifdef APP-PLUS | H5 | APP-VUE | APP-NVUE | APP-PLUS-NVUE -->
				<pg-image-cache
					v-for="(showImgUrl, key) in mShowImageArray" :key="getKey(showImgUrl, key)" :imgSrc="showImgUrl" mode="">
				</pg-image-cache>
				<!-- #endif -->
				
			</view>
			<view v-else-if="size > 4" class="avatar_type2">
			
				<!-- #ifndef APP-PLUS | H5 | APP-VUE | APP-NVUE | APP-PLUS-NVUE -->
				<image
					v-for="(showImgUrl, key) in mShowImageArray" :key="getKey(showImgUrl, key)" :src="showImgUrl" mode="">
				</image>
				<!-- #endif -->
				
				
				<!-- #ifdef APP-PLUS | H5 | APP-VUE | APP-NVUE | APP-PLUS-NVUE -->
				<pg-image-cache
					v-for="(showImgUrl, key) in mShowImageArray" :key="getKey(showImgUrl, key)" :imgSrc="showImgUrl" mode="">
				</pg-image-cache>
				<!-- #endif -->
			</view>
		</view>
</template>

<script>
	
	
	/**
	 * 最多9张图片
	 */
	export default {
		props: {
			dataList: {
				type: Array,
				default () {
					return []
				}
			},
			imgUrl : {
				type: String,
				default: null
			}
		},
		data() {
			return {
				size : 0,
				mShowImageArray : null,
				mSingleImgUrl: '',
			}
		},
		
		methods:{
			getKey(imgURL, index)
			{
				return imgURL + index;
			},
			
		},
		
		/**
		 * 组件生命周期
		 * https://uniapp.dcloud.io/collocation/frame/lifecycle?id=%e7%bb%84%e4%bb%b6%e7%94%9f%e5%91%bd%e5%91%a8%e6%9c%9f
		 */
		mounted() {
			if(this.imgUrl != null)
			{
				this.size = 1;
				this.mSingleImgUrl = this.imgUrl;
				
				// clear
				//this.mShowImageArray.push(this.imgUrl);
				this.mShowImageArray = null;
				return;
			}
			
			
			this.size = this.dataList.length;
			if(this.size == 1)
			{
				this.mSingleImgUrl = this.dataList[0];
				this.mShowImageArray = null;
			}
			else
			{
				this.mShowImageArray = this.dataList;
			}
		}
	}
</script>

<style>
	.avatar_single{
		width: 100%;
		height: 100%;
		border-radius: 2px;
	}
	.avatar_type1{
		display: flex;
		flex-wrap: wrap-reverse;
		justify-content: center;
		align-items:center;
		align-content: space-around;
		background-color: #ccc;
		width: 100%;
		height: 100%;
		border-radius: 2px;
	}
	.avatar_type1 image{
		width: 50%!important;height: 50%!important;
		border-radius:2px;
		border: 1px solid transparent;
		box-sizing: border-box;
	}
	.avatar_type2{
		display: flex;
		flex-wrap: wrap-reverse;
		justify-content: center;
		align-items:center;
		align-content: center;
		background-color: #ccc;
		width: 100%;
		height: 100%;
		border-radius: 2px;
	}
	.avatar_type2 image{
		width: 33.3333%!important;
		height: 33.333%!important;
		border-radius: 2px;
		border: 0.45px solid transparent;
		box-sizing: border-box;
	}
</style>
