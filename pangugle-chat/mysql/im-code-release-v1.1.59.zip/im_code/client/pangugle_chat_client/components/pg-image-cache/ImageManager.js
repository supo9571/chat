import CryptoJS from "@/js_sdk/crypt/crypto-js.min.js"
import { pathToBase64, base64ToPath } from '@/js_sdk/image-tools/image-base64.js' 

// 最大缓存个数
let currentImgSize = 0;
const DEFAULT_CACHE_CAPACITY = 200;
const DEFAULT_CACHE_KEY = "framework_offline_image_cache_key"
const imgKeyCacheArray = uni.getStorageSync(DEFAULT_CACHE_KEY) || [];


const ImageManager = {
	loadImageCache(imgURL, callback)
	{
		let that = this;
		let key = CryptoJS.MD5(imgURL).toString();
		this.updateCacheKeyArray(key);
		
		let base64Img = uni.getStorageSync(key) || null;
		if(base64Img != null)
		{
			callback(base64Img);
			return;
		}
		
		pathToBase64(imgURL)
		.then(base64 => {
			uni.setStorageSync(key, base64);
			callback(base64);
			
			that.addCacheKeyArray(key);
		})
		.catch(error => {
			//console.error(error)
		})
	},
	
	saveCacheKeyArray()
	{
		uni.setStorageSync(DEFAULT_CACHE_KEY, imgKeyCacheArray);
	},
	
	addCacheKeyArray(key)
	{
		let size = imgKeyCacheArray.push(key);
		while(size > DEFAULT_CACHE_CAPACITY - 1)
		{
			// 删除第一个元素,并删除对应的图片缓存
			let cacheKey = imgKeyCacheArray.shift();
			uni.removeStorageSync(cacheKey);
			size --;
		}
		currentImgSize = size;
		this.saveCacheKeyArray();
	},
	
	updateCacheKeyArray(key)
	{
		let index = currentImgSize - 1;
		while(index >= 0) {
			let valueKey = imgKeyCacheArray[index];
			if(valueKey === key)
			{
				imgKeyCacheArray.splice(i, 1);
				imgKeyCacheArray.push(valueKey);
				this.saveCacheKeyArray();
				break;
			}
			index --;
		}
	},
	
	clearCache()
	{
		let size = currentImgSize;
		while(size > DEFAULT_CACHE_CAPACITY - 1)
		{
			// 删除第一个元素,并删除对应的图片缓存
			let cacheKey = imgKeyCacheArray.shift();
			uni.removeStorageSync(cacheKey);
			size --;
		}
		currentImgSize = size;
		this.saveCacheKeyArray();
	}
}

export default ImageManager