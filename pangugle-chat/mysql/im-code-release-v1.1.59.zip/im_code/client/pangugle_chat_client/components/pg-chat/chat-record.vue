<template>
	<!-- 录音UI效果 -->
	<view class="record" :class="recording?'':'hidden'">
		<view class="ing" :class="willStop?'hidden':''"><view class="icon luyin2" ></view></view>
		<view class="cancel" :class="willStop?'':'hidden'"><view class="icon chehui" ></view></view>
		<view class="tis" :class="willStop?'change':''">{{recordTis}}</view>
	</view>
</template>

<script>
	
	/**
	 * 录音效果组件
	 */
	export default {
		name: "chat-record",
		data() {
			return {
				// #ifndef H5
				//H5不能录音
				RECORDER:uni.getRecorderManager(),
				// #endif
				
				recording : false,
				willStop : false,
				recordTis:"手指上滑 取消发送",
				recordTimer:null,
				recordLength:0,
				
				isInit: false,
			}
		},
		
		/**
		 * 组件生命周期
		 * https://uniapp.dcloud.io/collocation/frame/lifecycle?id=%e7%bb%84%e4%bb%b6%e7%94%9f%e5%91%bd%e5%91%a8%e6%9c%9f
		 */
		created()
		{
			let self = this;
			this.RECORDER.onStart((e)=>{
				self.onRecordBegin(e);
			})
			//录音结束事件
			this.RECORDER.onStop((e)=>{
				self.onRecordEnd(e);
			})
		},
		
		methods: {
			start()
			{
				// #ifndef H5
				// 没有压缩，只能取5s
				this.RECORDER.start({format:"mp3", duration:5000, sampleRate:8000, encodeBitRate:24000});//录音开始, 设置最长10s
				// #endif
			},
			stop()
			{
				this.recording = false;
				this.RECORDER.stop();//录音结束
			},
			cancer()
			{
				this.recording = false;
				this.willStop = true;//不发送录音
				this.RECORDER.stop();//录音结束
			},
			updateStopStatus(willStop)
			{
				this.willStop = willStop;
				if(this.willStop)
				{
					this.recordTis = '松开手指 取消发送'
				}
				else
				{
					this.recordTis = '手指上滑 取消发送'
				}
			},
			onRecordBegin(e){
				this.recording = true;
				this.voiceTis='松开 结束';
				this.recordLength = 0;
				this.recordTimer = setInterval(()=>{
					this.recordLength++;
				},1000)
			},
			//录音结束(回调文件)
			onRecordEnd(e){
				let that = this;
				clearInterval(this.recordTimer);
				if(!this.willStop){
					let msg = {
						length:0,
						url:e.tempFilePath
					}
					let min = parseInt(this.recordLength/60);
					let sec = this.recordLength%60;
					min = min<10?'0'+min:min;
					sec = sec<10?'0'+sec:sec;
					msg.length = min+':'+sec;
					
					// 小于1s不要发送
					if(sec < 1)
					{
						return;
					}
					
					this.$emit("onRecordFinish", {
						recordPath : e.tempFilePath,
						recordLenght : that.recordLength
					});
				}else{
					// console.log('取消发送录音');
				}
				this.recording = false;
				this.willStop = false;
			},
		}
		
	}
</script>

<style lang="scss">
	@import "@/components/pg-chat/style.scss"; 
</style>
