export declare const openType: void;
