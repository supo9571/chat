<script>
	import PushManager from "@/pages/framework/push/PushManager.js"
	import JumpManager from "@/pages/main/logical/JumpManager.js"
	import LogonServer from "@/pages/user/logical/LogonServer.js"
	
    export default {
		data() {
			return {
				mTimeoutID : -1, //定时器返回值
			}
		},
        onLaunch() {
			//this.replaceUrl();
            console.log('App Launch');
            // #ifdef APP-PLUS
            // 锁定屏幕方向
            plus.screen.lockOrientation('portrait-primary'); //锁定
          
            var domModule = weex.requireModule('dom');
            domModule.addRule('fontFace', {
                'fontFamily': "uniicons",
                'src': "url('./static/uni.ttf')"
            });
            // #endif
			
			LogonServer.init();
			
			PushManager.addReceiveNotificationListener((msg) => {
				JumpManager.jumpToHome();
			});
			
        },
        onShow: function() {
            console.log('App onShow')
			PushManager.setAppActive(true);
			
			
			LogonServer.startListener();
        },
        onHide: function() {
            console.log('App Hide')
			PushManager.setAppActive(false);
        },
		methods : {
		}
    }
</script>

<style>
	/* #ifndef APP-PLUS-NVUE */
	/* pg_common.css */
	@import './common/pg_common.css';

    /* uni.css - 通用组件、模板样式库，可以当作一套ui库应用 */
    @import './common/uni.css';
	
    /*每个页面公共css */
    page{
    	font-size: 12px;
    }
	view{
		-webkit-box-sizing: border-box;  /*内边边距属于宽的一部分*/
		   -moz-box-sizing: border-box;
				box-sizing: border-box;
	}
	input{
		font-size: 13px;
	}
	button{
		font-size: 16px;
	}
    
	/* #endif*/
</style>
