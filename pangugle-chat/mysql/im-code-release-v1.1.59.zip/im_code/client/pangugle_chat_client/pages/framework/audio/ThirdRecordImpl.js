

class ThirdRecordImpl extends RecordSupport {
	constructor() {
	}
	
	registerListener(listener)
	{
		this.listener = listener;
	}
	
}

export default ThirdRecordImpl