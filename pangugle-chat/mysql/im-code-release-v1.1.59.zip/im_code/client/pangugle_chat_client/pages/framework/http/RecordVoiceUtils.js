

const RecordVoiceUtils = {
	
	play(path)
	{
		
	}
	
}