

const RouterUtils = {
	
	/**
	 * 保留当前页面，跳转到应用内的某个页面，使用uni.navigateBack可以返回到原页面。
	 * @param {Object} OBJECT
	 */
	navigateTo(OBJECT)
	{
		uni.navigateTo(OBJECT);
	},
	
	/**
	 * @param {Object} OBJECT关闭当前页面，跳转到应用内的某个页面。
	 */
	redirectTo(OBJECT)
	{
		uni.redirectTo(OBJECT);
	},
	
	/**
	 * 关闭所有页面，打开到应用内的某个页面。
	 * @param {Object} OBJECT
	 */
	reLaunch(OBJECT)
	{
		uni.reLaunch(OBJECT);
	},
	
	/**
	 * 跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面。
	 * @param {Object} OBJECT
	 */
	switchTab(OBJECT)
	{
		uni.switchTab(OBJECT);
	},
	
	/**
	 * 关闭当前页面，返回上一页面或多级页面。可通过 getCurrentPages() 获取当前的页面栈，决定需要返回几层。
	 * @param {Object} OBJECT
	 */
	navigateBack(OBJECT)
	{
		uni.navigateBack(OBJECT);
	}
	
}



export default RouterUtils