
import SystemRecordImpl from "./SystemRecordImpl.js"


const mRecordSupport = SystemRecordImpl;


// #ifdef H5
if(uni.getSystemInfoSync().platform === 'android')
{
	mRecordSupport = mThirdRecordImpl;
}
else
{
	mRecordSupport = null;
}
// #endif

const MyRecordManager = {
	
	isSupport()
	{
		return mRecordSupport !== null;
	},
	
	isActive()
	{
		
	},
	
	setActive(active)
	{
		this.mIsActive = active;
	},
	
	registerListener(listener)
	{
		if(mRecordSupport !== null)
		{
			mRecordSupport.registerListener(listener);
		}
	},
	start(options)
	{
		
	},
	stop()
	{
		
	},
	/**
	 * 暂停录音	
	 */
	pause()
	{
		
	},
	/**
	 * 继续录音	
	 */
	resume()
	{
		
	}
	
}

export default MyRecordManager