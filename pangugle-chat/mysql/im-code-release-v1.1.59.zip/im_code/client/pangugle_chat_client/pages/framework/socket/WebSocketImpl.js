// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import SocketSupport from '@/pages/framework/socket/SocketSupport.js'

class WebSocketImpl extends SocketSupport{
	
	constructor() {
	    this.isOpen = false;
	}
	
	open(url) {
		uni.connectSocket({
			url:url
		});
	}
	
	isClose()
	{
		return !this.isOpen;
	}
	
	start()
	{
		uni.onSocketOpen(function (res) {
			this.isOpen = true;
			console.log('open socket success');
		});
	}
	
	close()
	{
		uni.onSocketClose(function (res) {
			this.isOpen = false;
			console.log('console socket success');
		});
	}
	
	onClose(callback)
	{
		uni.onSocketClose(function (res) {
			this.isOpen = false;
		  console.log('监听到 socket 已关闭！');
		});
	}
	
	sendMessage(msg)
	{
		uni.sendSocketMessage({
			'message-event': msg
		});
	}
	
	onMessage(callback)
	{
		uni.onSocketMessage(function (res) {
			console.log('收到服务器内容：' + res.data);
			
			let jsonString = res.data;
			if(StringUtils.isEmpty(jsonString)) {
				return;
			}
			try{
				let json = JSON.parse(jsonString);
				if(json && json.data)
				{
					callback(json);
				}
			}catch(e){
				console.log(e);
			}
		});
	}
}



export default WebSocketImpl;