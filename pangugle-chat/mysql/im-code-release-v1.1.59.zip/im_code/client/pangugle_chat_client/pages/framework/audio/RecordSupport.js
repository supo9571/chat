
class RecordSupport {
	
	onStart()
	{
		
	}
	onStop()
	{
		
	}
	onPause()
	{
		
	}
	onError()
	{
		
	}
	////////////////////////////////////////////////////////////////////////////////
	registerListener(listener)
	{
		
	}
	start(options)
	{
		
	}
	stop()
	{
		
	}
	/**
	 * 暂停录音	
	 */
	pause()
	{
		
	}
	/**
	 * 继续录音	
	 */
	resume()
	{
		
	}
	
}

export default RecordSupport