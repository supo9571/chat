class PriorityQueue {
    constructor() {
        this.items = [];
    }
 
    isEmpty() {
        return !this.items.length;
    }
 
    size() {
        return this.items.length;
    }
 
    enqueue(ele, priority) {
        let queueEle = { ele, priority };
        if (this.isEmpty) {
            this.items.push(queueEle);
        } else {
            let preIndex = this.items.findIndex(item => queueEle.priority < item.priority);
            if (preIndex > -1) {
                this.items.splice(preIndex, 0, queueEle);
            } else {
                this.items.push(queueEle);
            }
        }
    }
 
    dequeue() {
        return this.items.shift();
    }
 
    front() {
        return this.items[0];
    }
 
    clear() {
        this.items = [];
    }
 
    print() {
        console.log(this.items)
    }
}

export default PriorityQueue