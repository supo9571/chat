// framework
import Cache from '@/pages/framework/cache/Cache.js'

import CachePolicy from '@/pages/framework/http/CachePolicy.js'

class CacheRequest {
	
	constructor(request) {
	    this.mRequest = request;
	}
	
	request(url, parameters, method, cachePolicy, success, failure)
	{
		if(this.handleLocalCache(url, cachePolicy, success)){
			return;
		}
		this.mRequest.request(url, parameters, method, (isCache, data) => 
		{
			this.handleRemoteCache(url, data, cachePolicy);
			success(false, data);
		}, failure);
	}
	
	get(url, parameters, cachePolicy, success, failure)
	{
		this.request(url, parameters, 'GET', cachePolicy, success, failure);
	}
	
	post(url, parameters, cachePolicy, success, failure)
	{
		this.request(url, parameters, 'POST', cachePolicy, success, failure);
	}
	
	handleLocalCache(url, cachePolicy, success)
	{
		let cacheData = Cache.getValue(url);
		if(cacheData)
		{
			if(cachePolicy == CachePolicy.HTTP_CACHE_POLICY_LOCAL_OR_REMOTE)
			{
				success(true, cacheData);
				return true;
			}
			else if(cachePolicy == CachePolicy.HTTP_CACHE_POLICY_LOCAL_AND_REMOTE)
			{
				success(true, cacheData);
			}
			else if(cachePolicy == CachePolicy.HTTP_CACHE_POLICY_IGNORE_LOCAL_AND_REMOTE)
			{
				success(true, cacheData);
			}
			
			//console.log();
		}
		return false;
	}
	
	handleRemoteCache(url, data, cachePolicy)
	{
		if(!data)
		{
			return;
		}
		if(cachePolicy == CachePolicy.HTTP_CACHE_POLICY_LOCAL_OR_REMOTE)
		{
			Cache.setValue(url, data);
		}
		else if(cachePolicy == CachePolicy.HTTP_CACHE_POLICY_LOCAL_AND_REMOTE)
		{
			Cache.setValue(url, data);
		}
		else if(cachePolicy == CachePolicy.HTTP_CACHE_POLICY_IGNORE_LOCAL_AND_REMOTE)
		{
			Cache.setValue(url, data);
		}
	}
	
}

export default CacheRequest