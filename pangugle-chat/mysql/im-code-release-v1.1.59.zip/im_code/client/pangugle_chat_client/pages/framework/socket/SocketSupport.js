
/**
 * 定义接口类
 */
class SocketSupport {
	
	open(url) {
	}
	
	isClose()
	{
		return false;
	}
	
	start()
	{
		return false;
	}
	
	close()
	{
	}
	
	onClose(callback)
	{
	}
	
	sendMessage(msg)
	{
		
	}
	
	onMessage(callback)
	{
	}
}

export default SocketSupport