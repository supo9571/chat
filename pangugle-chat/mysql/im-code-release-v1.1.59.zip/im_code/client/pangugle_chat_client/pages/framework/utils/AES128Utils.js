
import CryptoJS from "@/js_sdk/crypt/crypto-js.min.js"

const config = {mode:CryptoJS.mode.ECB,padding: CryptoJS.pad.Pkcs7};

const AES128Utils = {
	
	/**
	 * 加密（需要先加载lib/aes/aes.min.js文件）
	 * @param word
	 * @returns {*}
	 */
	encrypt(word, key){
	    var key = CryptoJS.enc.Utf8.parse(key);
	    var srcs = CryptoJS.enc.Utf8.parse(word);
	    var encrypted = CryptoJS.AES.encrypt(srcs, key, config);
	    return encrypted.toString();
	},
	 
	/**
	 * 解密
	 * @param word
	 * @returns {*}
	 */
	decrypt(word, key){
	    var key = CryptoJS.enc.Utf8.parse(key);
	    var decrypt = CryptoJS.AES.decrypt(word, key, config);
	    return CryptoJS.enc.Utf8.stringify(decrypt).toString();
	},
	
	test()
	{
		let encryText = "vpmHfgcFnxo/g3eQuWKNVQ==";
		let key = "1234567890123456";
		
		
		let decryptString = this.decrypt(encryText, key);
		
		console.log("decry string ============ ", decryptString);
		
	},
	
	
}

export default AES128Utils