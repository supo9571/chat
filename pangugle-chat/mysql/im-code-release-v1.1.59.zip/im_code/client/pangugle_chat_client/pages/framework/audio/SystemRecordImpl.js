

const mRecordManager = uni.getRecorderManager();
class SystemRecordImpl extends RecordSupport {
	constructor() {
		// init
		this.mListener = null;
		
		let self = this;
		mRecordManager.onStart(e)
		{
			if(self.mListener !== null)
			{
				self.mListener.onRecordStart();
			}
		};
		
		mRecordManager.onStop(e)
		{
			if(self.mListener !== null)
			{
				let tempFilePath = e.tempFilePath;
				self.mListener.onRecordStop(tempFilePath);
			}
		};
		
		mRecordManager.onError(e)
		{
			//console.log("on record error:", e);
			// 发生错误,直接结束
			if(self.mListener !== null)
			{
				self.mListener.onRecordStop();
			}
		};
		
		
	}
	
	registerListener(listener)
	{
		this.mListener = listener;
	}
	
}