
import JPush from "lib/JPush.js"

// 初始化 JPush 插件，如果没有调用这个方法，JS 端将不会收到相关事件。
JPush.init();

const JpushImpl = {
	
	applyPushAuthority: function() {
		JPush.applyPushAuthority();
	},
	
	addReceiveNotificationListener(handle)
	{
		JPush.addReceiveNotificationListener(function (notification) {
			handle(notification);
			//console.log('vue console111' + JSON.stringify(notification))
		})
	},
	
	setAlias(alias)
	{
		JPush.setAlias('123', (res) => {
			//console.log('setAlias success : ', res)
		}, (err) => {
			//console.log('setAlias error', Jerr)
		})
	},
	
	deleteAlias(alias)
	{
		JPush.deleteAlias((res) => {
			//console.log('deleteAlias success : ',  JSON.stringify(res))
		}, (err) => {
			//console.log('error' + JSON.stringify(err))
		})
	},
	
	getRegistrationID: function() {
		JPush.getRegistrationID( (res) => {
			//console.log('getRegistrationID' + JSON.stringify(res))
		})
	},
}

export default PushManager