
import CryptoJS from "@/js_sdk/crypt/crypto-js.min.js"

const Base64Utils = {
	
	encrypt(data)
	{
		var wordArray = CryptoJS.enc.Utf8.parse(data);
		var base64 = CryptoJS.enc.Base64.stringify(wordArray);
		return base64;
	},
	
	decrypt(data)
	{
		var parsedWordArray = CryptoJS.enc.Base64.parse(data);
		var parsedStr = parsedWordArray.toString(CryptoJS.enc.Utf8);
		return parsedStr;
	},
	
	
}

export default Base64Utils