

const DataChecker = {
	checkPwd : (pwd1, pwd2, minLength, maxLenght) => {
		
	},
}



export default DataChecker