import StringUtils from "@/pages/framework/utils/StringUtils.js"

let isAppShow = false;

let currentBadge = 0;

const PushManager = {
	
	addReceiveNotificationListener(handle)
	{
		// #ifdef APP-PLUS
		let that = this;
		// 从系统消息中心点击消息启动应用事件
		plus.push.addEventListener("click", function(msg) {
			//console.log("click:"+JSON.stringify(msg));  
			//console.log(msg.payload);  
			//console.log(JSON.stringify(msg));  
			//这里可以写跳转业务代码
			handle(msg);
			that.clearBadge();
		}, false);  
		
		// 监听在线消息事件=> 应用从推送服务器接收到推送消息事件。  
		plus.push.addEventListener("receive", function(msg) {  
			// plus.ui.alert(2);  
			//这里可以写跳转业务代码
			//console.log("recevice:"+JSON.stringify(msg)) 
			that.clearBadge();
			handle(msg);
		}, false);
		// #endif
	},
	
	setAppActive(show)
	{
		// #ifdef APP-PLUS
		isAppShow = show;
		this.clearBadge();
		// #endif
	},
	
	getAndIncreBadge()
	{
		currentBadge ++;
		if(currentBadge < 0)
		{
			currentBadge = 0;
		}
		return currentBadge;
	},
	
	clearBadge()
	{
		// #ifdef APP-PLUS
		currentBadge = 0;
		plus.runtime.setBadgeNumber(currentBadge);
		plus.push.clear();
		// #endif
	},
	
	sendLocalMessage(title, content, body)
	{
		// #ifndef H5
		if(isAppShow)
		{
			return;
		}
		let options = {
			"cover" : false, // 覆盖上次 
			"when" : new Date(),
			//"sound" : "none"
		}; 
		if(!StringUtils.isEmpty(title))
		{
			options.title = title;
		}
		let payload = JSON.stringify(body);
		plus.push.createMessage(content, payload, options);
		plus.runtime.setBadgeNumber(this.getAndIncreBadge());
		//plus.audio.createPlayer("/static/chat/tips-receiv-message.mp3").play();  
		// #endif
	}
}

export default PushManager