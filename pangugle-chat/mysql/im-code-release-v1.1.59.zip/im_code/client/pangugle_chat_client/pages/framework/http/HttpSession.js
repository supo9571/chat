
import request from '../plugins/luch-request/request.js'

const myRequest = new Request()

class HttpSession {
	constructor(arg) {
	    
	}
	
	get(url, options = {}) {
		return myRequest.get(url, options);
	}
}

if(!global.$httpSession)
{
	global.$httpSession  = new HttpSession();
}

export default global.$httpSession;