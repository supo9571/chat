import SocketSupport from '@/pages/framework/socket/SocketSupport.js'

const io = require('./lib/weapp.socket.io.js')

const DEFAULT_DATA_EVENT = 'message-event';

class SocketioManager {
	
	constructor() {
	    this.mIsOpen = false;
		
		let self = this;
		
		// 连接处理器
		this.connectHandler = () => {
			this.mIsOpen = true;
			//console.log('open socket success');
			// if(this.connectCallback)
			// {
			// 	this.connectCallback.onSuccess();
			// }
		}
		
		// reconnect
		this.reconnectHandler = () => {
			this.mIsOpen = true;
			console.log('reconnect socket success');
			// self.close();
			// if(this.connectCallback)
			// {
			// 	this.connectCallback.onSuccess();
			// }
		}
		
		// 重连次数
		this.reconnectAttemptHandler = (attemptNumber) => {
			console.log('reconnectAttemptHandler retry count = ' + attemptNumber);
			self.close();
		}
		
		this.disConnectHandler = () => {
			console.log('disconnect socket ....');
			self.close();
		}
		
		// error
		this.errorHandler = (error) => {
			let rs = null;
			if(typeof(error) == 'string' )
			{
				rs = error;
			}
			else
			{
				rs = "未知异常";
			}
			console.log("socket error:",error);
			self.close();
			if(this.connectCallback != null)
			{
				this.connectCallback.onError(-1, rs);
			}
		}
		
		this.dataHandler = (data) => {
			if(this.dataCallback)
			{
				this.dataCallback(data);
			}
		}
		
	}
	
	start(url)
	{
		// close
		this.close();
		
		// init socket
		let socket = io(url, { forceNew: true, autoConnect: false });
		this.mSocket = socket;
		
		this.mSocket.on('connect', this.connectHandler);
		this.mSocket.on('reconnect', this.reconnectHandler);
		this.mSocket.on('reconnect_attempt', this.reconnectAttemptHandler);
		this.mSocket.on('disconnect', this.disConnectHandler);
		this.mSocket.on('error', this.errorHandler);
		this.mSocket.on(DEFAULT_DATA_EVENT, this.dataHandler);
		
		this.mSocket.open();
	}
	
	isClose()
	{
		return !this.mIsOpen;
	}
	
	close()
	{
		//console.log("will close : ", this.mSocket);
		if(this.mSocket != null)
		{
			this.mSocket.close();
		}
		this.mSocket = null;
		this.mIsOpen = false;
	}
	
	sendMessage(msg)
	{
		// 验证消息能不能发送
		if(msg == null || !this.mIsOpen || this.mSocket == null) return false;
		// 发送
		this.mSocket.emit(DEFAULT_DATA_EVENT, msg);
		//console.log("send message : ", msg)
		return true;
	}
	
	setDataCallback(dataCallback)
	{
		this.dataCallback = dataCallback;
	}
	
	setConnectCallback(connectCallback)
	{
		this.connectCallback = connectCallback;
	}
}



export default SocketioManager