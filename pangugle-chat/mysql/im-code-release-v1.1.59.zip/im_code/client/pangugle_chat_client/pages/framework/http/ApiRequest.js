// framework
import ConfigHelper from '@/pages/framework/config/ConfigHelper.js'
import JsonUtils from '@/pages/framework/utils/JsonUtils.js'
import ToastUtils from '@/pages/framework/utils/ToastUtils.js'

import UserApi from '@/pages/user/service/UserApi.js'
import UserManager from '@/pages/user/logical/UserManager.js'
import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"

import Request from '@/js_sdk/luch-request/request.js'
import CacheRequest from '@/pages/framework/http/CacheRequest.js'

const baseRequest = new Request()

baseRequest.setConfig((config) => { /* 设置全局配置 */
  config.baseUrl = ConfigHelper.getString('api_server')
  config.header = {
    ...config.header,
    'content-type': 'application/json;charset=UTF-8'
  }
  config.dataType = 'json'
  return config
})

baseRequest.interceptor.request((config, cancel) => { /* 请求之前拦截器 */
  config.header = {
    ...config.header,
    a: 1
  }
  /*
  if (!token) { // 如果token不存在，调用cancel 会取消本次请求，但是该函数的catch() 仍会执行
    cancel('token 不存在') // 接收一个参数，会传给catch((err) => {}) err.errMsg === 'token 不存在'
  }
  */
  return config
})

baseRequest.interceptor.response((response) => { /* 请求之后拦截器 */
  return response
}, (response) => { // 请求错误做点什么
  return response
})


/**
 * 自定义验证器，如果返回true 则进入响应拦截器的响应成功函数(resolve)，否则进入响应拦截器的响应错误函数(reject)
 * @param { Object } response - 请求响应体（只读）
 * @return { Boolean } 如果为true,则 resolve, 否则 reject
 */
baseRequest.validateStatus = (response) => {
  return response.statusCode === 200
}

class ApiRequest {
	
	constructor() {
	    this.cacheRequest = new CacheRequest(this);
		
		// 并发请求
		this.isRefreshAccessTokenTask = false;
		this.mRetryRequestList = [];
	}
	
	request(url, data, method, success, failure) {
		//console.log("current request url = " + url);
		
		let self = this;
		// init accessToken
		let accessToken = UserManager.getAccessToken();
		if(data == null) data = {};
		data.accessToken = accessToken;
		
		// 没有这个参数会报错
		let options = {};
		baseRequest.request({
		  url,
		  data,
		  ...options
		})
		.then(res => {
			self.handleResult(res, success, failure);
		})
		.catch(err => {
			//console.log(err);
			// 需要判断错误类型
			console.log(err);
			this.handleFailure(-1, '妈耶, 服务端去外太空旅游了!', failure);
		});
	}
	
	
	getCacheRequest()
	{
		return this.cacheRequest;
	}
	
	get(url, parameter, success, failure)
	{
		this.request(url, parameter, 'GET', success, failure)
	}
	
	post(url, parameter, success, failure)
	{
		this.request(url, parameter, 'POST', success, failure)
	}
	
	uploadFile(url, parameter, success, failure)
	{
		// console.log("==========,", parameter);
		let self = this;
		parameter.url = ConfigHelper.getString('api_server') + url;
		parameter.name = 'file';
		parameter.method = "post";
		if(parameter.formData == null)
		{
			parameter.formData = {};
		}
		parameter.formData.accessToken = UserManager.getAccessToken();
		//console.log(parameter);
		parameter.success = function(res)
		{
			self.handleResult(res, success, failure);
		};
		parameter.fail = function(e)
		{
			console.log("upload file error : ", e)
			self.handleFailure(-1, '上传失败', failure);
		};
		uni.uploadFile(parameter);
	}
	
	handleResult(response, success, failure)
	{
	  try{
		  // console.log(response);
	  	var dataResult = JsonUtils.parseJson(response.data);
		if(typeof(dataResult) == 'string')
		{
			dataResult = JsonUtils.parseJson(dataResult);
		}
	  	if(dataResult == null || dataResult == undefined || !dataResult.hasOwnProperty("code"))
	  	{
	  		// 不是jsonovrn
	  		this.handleFailure(-1, "服务端异常!", failure);
	  	}
	  	else if(dataResult.code == 200)
	  	{
			//console.log("================================================")
			//console.log("================================================")
			//console.log("================================================")
			//console.log("url ======= ", response.config.url);
			//console.log("data result = ", response.data);
	  		this.handleSuccess(dataResult, success, failure);
	  	}
	  	// access token 异常,需要重新请求
	  	else if(dataResult.code == 20001)
	  	{
	  		//console.log("will access token  =========== ", url);
	  		this.doRetryRequest(response, success, failure);
	  	}
	  	// login token 异常,需要重新请求
	  	else if(dataResult.code == 20002)
	  	{
	  		//console.log("will login token by api  =========== ", url);
	  		// 重新登陆
	  		UserJumpHelper.jumpToLogin();
	  	}
	  	else
	  	{
	  		// 不是jsonovrn
	  		let code = dataResult.code;
	  		let msg = dataResult.msg;
			//console.log("===========", msg);
	  		this.handleFailure(code, msg, failure);
	  	}
	  }catch(e){
	  	console.log("handle data error:", e)
	  	this.handleFailure(-1, "数据异常!", failure);
	  }
	}
	
	handleSuccess(dataResult, success, failure)
	{
		ToastUtils.hideLoading();
		// 成功有两种，有data和无data
		if(dataResult.hasOwnProperty("data"))
		{
			let safeData = JsonUtils.null2Str(dataResult.data);
			success(false, safeData);
		}
		else
		{
			success(false, null);
		}
	}
	
	handleFailure(code, msg, failure)
	{
		ToastUtils.hideLoading();
		if(failure == null)
		{
			ToastUtils.showFailure(msg);
		}
		else {
			failure(code, msg);
		}
	}
	
	/**
	 * 获取accessToken
	 */
	refreshAccessToken(success, failure) {
		
		let self = this;
		this.isRefreshAccessTokenTask = true;
		let params = {
			loginToken : UserManager.getLoginToken()
		};
		this.post('/im/userApi/refreshAccessToken', params,
		(isCache, data) =>
		{
			//console.log("==================== token ", data);
			self.isRefreshAccessTokenTask = false;
			var accessToken = data.accessToken;
			var expiresTime = data.expires_time;
			UserManager.saveAccessToken(accessToken);
			UserManager.saveAccessTokenExpires(expiresTime);
			success();
		}, (code, msg) => {
			self.isRefreshAccessTokenTask = false;
			this.handleFailure(code, msg);
		});
	}
	
	/**
	 * 安全请求token，并继续请求之前的请求，目的降低并发的可能
	 * @param {Object} response
	 * @param {Object} success
	 * @param {Object} failure
	 */
	doRetryRequest(response, success, failure)
	{
		  var requestTask = {
			  "response" : response,
			  "success" : success,
			  "failure" : failure
		  };
		  this.mRetryRequestList.push(requestTask)
		  if(this.isRefreshAccessTokenTask)
		  {
			  return;
		  }
		  this.isRefreshAccessTokenTask = true;
		  var self = this;
		  this.refreshAccessToken( () => {
			  
		  	for(let index in self.mRetryRequestList)
		  	{
		  		let requestTask = self.mRetryRequestList[index];
		  			
				var response = requestTask["response"];
				var success = requestTask["success"];
				var failure = requestTask["failure"];
				
				var url = response.config.url;
				var method = response.config.method;
				var params = response.config.data;
				
				self.request(url, params, method, success, failure);
		  	}
			self.mRetryRequestList = [];
		  },
		  (code, msg) => {
			  for(let index in self.mRetryRequestList)
			  {
				let requestTask = self.mRetryRequestList[index];
				var failure = requestTask["failure"];
				self.handleFailure(code, msg, failure);
			  }
			  self.mRetryRequestList = [];
		  });
	}
	
}

const apiRequestIntance = new ApiRequest();

export default apiRequestIntance;