
const JsonUtils = {
	null2Str(data)
	{
		for (let x in data) {
		  if (data[x] === null) { // 如果是null 把直接内容转为 ''
		    data[x] = '';
		  } else {
		    if (Array.isArray(data[x])) { // 是数组遍历数组 递归继续处理
		      data[x] = data[x].map(z => {
		        return JsonUtils.null2Str(z);
		      });
		    }
		    if(typeof(data[x]) === 'object'){ // 是json 递归继续处理
		      data[x] = JsonUtils.null2Str(data[x])
		    }
		  }
		}
		return data;
	},
	
	parseJson(obj)
	{
		let rs = null;
		try{
			rs = JSON.parse(obj);
			rs = this.null2Str(rs);
		}catch(e){
			console.log("parse json error : ", e)
		}
		return rs;
	},
	
	toJsonString(json)
	{
		try{
			return JSON.stringify(json);
		}catch(e){
		}
		return null;
	},
	
	isEmptyForMap(value)
	{
		if(value == null || typeof(value) == undefined)
		{
			return true;
		}
		for(var key in value) {
			return false;
		}
		return true;
	}
	
	
}



export default JsonUtils