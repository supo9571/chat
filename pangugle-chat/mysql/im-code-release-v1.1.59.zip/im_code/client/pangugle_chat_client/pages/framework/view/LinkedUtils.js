
const LinkedUtils = {
	
	openURL(url, title)
	{
		var jsonMap = {
			'url' : url,
			'title' : title 
		}
		var data = encodeURIComponent(JSON.stringify(jsonMap))
		uni.navigateTo({
			url: '/pages/framework/view/Webview?data=' + data
		})
	}
	
}

export default LinkedUtils