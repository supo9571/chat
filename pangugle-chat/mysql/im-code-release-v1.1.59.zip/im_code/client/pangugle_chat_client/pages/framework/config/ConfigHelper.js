
import StringUtils from "@/pages/framework/utils/StringUtils.js"

var env = 'dev'; // dev|test|beta|prod
 
if(process.env.NODE_ENV === 'development')
{
}
else
{
    env = 'prod';
}
//env = 'prod';
const Configuration = {
	// 上传文件服务api
	"upload_server" : {
		'dev' : 'http://192.168.3.10:8081/uploads',
		'test' : '',
		'beta' : '',
		'prod' : 'http://114.67.115.15/uploads',
	},
	// rest server
	'api_server' : {
		'dev' : 'http://192.168.3.10:8081',
		'test' : '',
		'beta' : '',
		'prod' : 'http://114.67.115.15',
	},
	// socket server
	'socket_server' : {
		'dev' : 'http://192.168.3.10:8888',
		'test' : '',
		'beta' : '',
		'prod' : 'http://114.67.115.15:8888',
	},
	// static server 
	'static_server' : {
		'dev' : 'http://192.168.3.10:8081/h5',
		'test' : '',
		'beta' : '',
		'prod' : 'http://114.67.115.15/h5',
	},
}

const ConfigHelper = {
	getString(key)
	{
		try{
			let valueObj = Configuration[key];
			if(valueObj != null)
			{
				return valueObj[env];
			}
		}catch(e){
			console.log("get String error:", e)
		}
		return '';
	},
	getNumber(key)
	{
		try{
			let valueObj = Configuration[key];
			if(valueObj != null)
			{
				return valueObj[env];
			}
		}catch(e){
			console.log("get number error:", e)
		}
		return 0;
	}
}


export default ConfigHelper