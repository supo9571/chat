
import JsonUtils from "@/pages/framework/utils/JsonUtils.js"

import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"

const QrcodeManager = {
	
	generateContent(key, data)
	{
		let map = {
			key,
			data
		}
		return JsonUtils.toJsonString(map);
	},
	
	generateUserBasicInfo(username)
	{
		var data = {
			username
		}
		return this.generateContent("UserBasicInfo", data);
	},
	
	generateGroupQrcode(groupInfo)
	{
		var data = {
			groupInfo
		}
		return this.generateContent("GroupCreateQrcodeInfo", data);
	},
	
	handleResult(scanResult)
	{
		var result = null;
		try{
			result = JsonUtils.parseJson(scanResult);
			if(typeof(dataResult) == 'string')
			{
				result = JsonUtils.parseJson(result);
			}
			
			var key = result["key"];
			var data = result['data'];
			
			if("UserBasicInfo" == key)
			{
				var username = data["username"];
				ChatJumpHelper.jumpToUserBasicInfo(username);
			}
			else if("GroupCreateQrcodeInfo" == key)
			{
				ChatJumpHelper.jumpToJoinGroup(data.groupInfo);
			}
			else
			{
				// unHandle
			}
			
			
		}catch(e){
			console.log("un parse scan content : ", result);
		}
	}
	
}

export default QrcodeManager;