import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"

const userRegex = new RegExp("^user_*$");
const chatRegex = new RegExp("^chat_*$");

const JumpManager = {
	
	jump(key, parameter)
	{
		if(userRegex.test(key))
		{
			UserJumpHelper.handleRouter(key, parameter);
		}
		
	},
	
	jumpToHome()
	{
		uni.switchTab({
			url:'/pages/main/home/HomeTabbar'
		})
	}
	
}


export default JumpManager