<template>
	
	<uni-list>
		<uni-list-item thumb="/static/contact_add_friend.png" :show-badge="true" title="添加好友" @click="doAddFriend()" />
		<uni-list-item thumb="/static/chat_group_add.png" :show-badge="true" title="创建群组" @click="doCreateGroup()" />
		<!-- #ifndef H5 -->
		<uni-list-item thumb="/static/pg_def_qrcode.png" :show-badge="true" title="扫一扫"  @click="doScanCode()"/>
		<!-- #endif -->
	</uni-list>
	
</template>

<script>
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	
	import ChatManager from "@/pages/chat/logical/ChatManager.js"
	import ConversationManager from '@/pages/chat/logical/ConversationManager.js'
	import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'
	
	// framework
	import Cache from '@/pages/framework/cache/Cache.js'
	
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserManager from '@/pages/user/logical/UserManager.js'
	import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"
	
	import QrcodeManager from "@/pages/main/logical/QrcodeManager.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	
	export default {
		data() {
			return {
			}
		},
		components: {
			uniList,
			uniListItem,
			"pg-actionsheet" : actionSheet,
		},
		onShow() {
		},
		methods: {
			
			doScanCode()
			{
				uni.scanCode({
					scanType: ["qrCode"],
				    success: function (res) {
				        //console.log('条码类型：' + res.scanType);
				        //console.log('条码内容：' + res.result);
						//console.log("type = ", typeof(res.result));
						
						QrcodeManager.handleResult(res.result);
				    }
				});
			},
			
			doAddFriend()
			{
				ChatJumpHelper.jumpToAddFriend();
			},
			
			doCreateGroup()
			{
				ChatJumpHelper.jumpToGroupCreate();
			}
			
		}
	}
</script>

<style>
	.uni-list-cell{padding-top: 32px;padding-bottom: 10px;;}
	.uni-list::after{background-color: #fff;} 
	.uni-list{margin-bottom: 10px;}
	
	.logout {
		background-color: #fff;
		text-align: center;
		font-size:16px;
		line-height: 48px;
		margin-top: 10px;
	}
</style>
