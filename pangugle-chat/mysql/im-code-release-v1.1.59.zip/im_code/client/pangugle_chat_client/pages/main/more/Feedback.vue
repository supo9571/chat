<template>
	<view>
		<view class="uni-form-item uni-column">
			<view class="title">请描述具体内容</view>
			<textarea class="uni-input" maxlength="-1" placeholder-style="color:#999" placeholder="意见反馈"></textarea>
		</view>
	</view>
</template>

<script>
</script>

<style>
</style>
