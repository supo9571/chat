<template>
	
	<view>
		
		<uni-list>
			<uni-list-item thumb="/static/contact_add_friend.png" badge-type="error" :show-badge="true" title="新的朋友" :badge-text="mNewFriendVerifyBadge" @click="jumpToConfirmList()"/>
			<!-- 
			<uni-list-item thumb="/static/contact_new_friend.png" :show-badge="true" title="新的朋友" :badge-text="mNewFriendVerifyBadge" @click="jumpToConfirmList()" class="uni-list-cell-navigate uni-navigate-right pg_navigate_right" :show-arrow="false"/>
			-->
			<uni-list-item thumb="/static/contact_group_list.png" :show-badge="true" title="群聊" @click="jumpToGroupChatList()" />
		
			<uni-list-item thumb="/static/contact_kefu.png" :show-badge="true" title="客服" @click="jumpToKefuList()" />
		
			<!-- <uni-list-item thumb="/static/contact_kefu.png" :show-badge="true" title="test" @click="jumpToTest()" /> -->
		</uni-list>
		<view class="uni-form-item uni-column">
			<view class="title">朋友</view>
		</view>
		<uni-list>
			<uni-list-item
				:show-extra-icon="true" 
				:showArrow="false" 
				:thumb="userInfo.avatar"
				:title="handleUserInfoTitle()"
				@click="jumpToUserBasicInfo(userInfo)"/>
				
			<uni-list-item 
				v-for="(value, key) in contactDataList" :key="key"
				:show-extra-icon="true" 
				:showArrow="false" 
				:thumb="handleFriendAvatar(value)"
				:title="handleFriendTitle(value)" 
				@click="jumpToUserBasicInfo(value)"/>
		</uni-list>
		
		
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import Pinyin from '../../framework/utils/Pinyin.js'
	
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	
	
	import UserApi from "@/pages/user/service/UserApi.js"
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	import KefuJumpHelper from "@/pages/kefu/helper/KefuJumpHelper.js"
	
	var isInit = false;
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem
		},
		data() {
			return {
				mNewFriendVerifyBadge : '',
				isHasFriend : false,
				contactDataList : [],
				
				mUnconfirmList : [],
				
				userInfo : {
					username : '',
					nickname : '',
					avatar :  ''
				}
			}
		},
		onShow() {
			FriendCMDManager.setFriendListCallback(this);
			// 注意新的朋友、群聊更新数据以这里为主
			// 更新机制时机: 1、启动应用第一次进入; 2、下拉更新; 3、通知有新变化才更新
			
			// 获取用户信息
			this.userInfo = UserManager.getUserInfo();
			
			//console.log("=============", this.userInfo);
			
			
			// 设置回调，每次都要重新设置一次
			FriendCMDManager.setUnconfirmListCallback(this);
			
			// 新的朋友、群聊不做下拉更新, 
			this.loadDataRequest(!isInit)
			
			// 初始化完毕标识, 应用启动运行一次
			isInit = true;
		},
		onPullDownRefresh() {
			// 下拉更新
			this.loadDataRequest(true);
		},
		methods: {
			handleFriendTitle(value) 
			{
				let title = value.username;
				let friendInfo = FriendInfoManager.getFriendInfo(value.username);
				if(!StringUtils.isEmpty(friendInfo.alias))
				{
					title = friendInfo.alias;
				}
				else if(!StringUtils.isEmpty(friendInfo.nickname))
				{
					title = friendInfo.nickname;
				}
				return title;
			},
			handleFriendAvatar(value)
			{
				let title = value.username;
				let friendInfo = FriendInfoManager.getFriendInfo(value.username);
				return friendInfo.avatar;
			},
			handleUserInfoTitle()
			{
				if(!StringUtils.isEmpty(this.userInfo.nickname))
				{
					return this.userInfo.nickname + " (我)";
				}
				return this.userInfo.username + " (我)";
			},
			jumpToConfirmList()
			{
				uni.navigateTo({
					url:'../../chat/view/ConfirmFriendList'
				});
			},
			jumpToGroupChatList()
			{
				uni.navigateTo({
					url:'../../chat/view/GroupList'
					//url : '../../chat/view/SearchUser'
				});
			},
			
			jumpToKefuList()
			{
				KefuJumpHelper.jumpToKefuList();
			},
			
			jumpToUserBasicInfo(value)
			{
				let username = value.username;
				//let nickname = value.nickname;
				//let avatar = value.avatar;
				ChatJumpHelper.jumpToUserBasicInfo(username);
			},
			
			jumpToTest()
			{
				ChatJumpHelper.jumpToJoinGroup();
			},
			
			loadDataRequest(reload)
			{
				FriendCMDManager.refreshFriendList(reload, null);
				FriendCMDManager.refreshUnconfirmList(reload, null);
			},
			
			// 加载好友信息回调
			onUnconfirmListCallback(dataList)
			{
				this.mUnconfirmList = dataList;
				
				let len = this.mUnconfirmList.length;
				if(len > 0)
				{
					this.mNewFriendVerifyBadge = len + '';
				}
				else 
				{
					this.mNewFriendVerifyBadge = '';
				}
				//this.mNewFriendVerifyBadge = "1";
			},
			onFriendListCallback(dataList)
			{
				//console.log("===onFriendListCallback", dataList);
				this.isHasFriend = dataList.length > 0;
				this.contactDataList = dataList;
				uni.stopPullDownRefresh();
			}
		}
	}
</script>

<style>

</style>
