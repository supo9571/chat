<template>
	
	<view>
		
		<!-- 列表 key 在wx不行，但是这里必须唯一 -->
		<view v-if="!emptySdk.showView" class="uni-list">
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" 
				v-for="(item,index) in dataList" 
				:key="item.event+item.fromUserid+item.targetid"
				@longpress="openActionSheet(item)"
				@click="jumpToTargetView(item)"
				 >
				<view class="uni-media-list ">
					<view class="uni-media-list-logo">
						<pg-avatar :length="item.avatar.length" :dataList="item.avatar">
						</pg-avatar>
						<text v-if="item.showAlert" class="sp">{{getBadge(item)}}</text>
					</view>
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{item.title}}</view>
						<view  class="uni-media-list-text-bottom uni-ellipsis">
							<text v-if="item.showAt" style="color:red">[有人@我]</text> {{item.content}}
						</view>
					</view>
					<view class="pg_media_list_right">{{getTime(item)}}</view>
				</view>
			</view>
			
		</view>
		
		<!-- 空视图 -->
		<sunui-template :skyContent="emptySdk.showContent" :skyDesc="emptySdk.skyDesc" v-if="emptySdk.showView">
		</sunui-template>
		
		<!-- 长按视图 -->
		<pg-actionsheet
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.itemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
		<!-- 
		<view class="cu-list menu-avatar">
			<view class="cu-item" :class="modalName=='move-box-'+ index?'move-cur':''" v-for="(item,index) in 4" :key="index"
			 @touchstart="touchStart" @touchmove="touchMove" @touchend="touchEnd" :data-target="'move-box-' + index">
				<view class="cu-avatar radius lg" :style="[{backgroundImage:'url(https://ossweb-img.qq.com/images/lol/web201310/skin/big2100'+ (index+2) +'.jpg)'}]"></view>
				<view class="content">
					<view class="text-grey">文晓港</view>
					<view class="text-gray text-sm">
						<text class="cuIcon-infofill text-red  margin-right-xs"></text> 
						消息未送达
					</view>
				</view>
				<view class="action">
					<view class="text-grey text-xs">22:20</view>
					<view class="cu-tag round bg-red sm">1</view>
				</view>
				<view class="move">
					<view class="bg-grey">置顶</view>
					<view class="bg-red">删除</view>
				</view>
			</view>
		</view>-->
		
	</view>
	
</template>

<script>
	
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import ConversationManager from '@/pages/chat/logical/ConversationManager.js'
	import Cache from "@/pages/framework/cache/Cache.js"
	
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import ChatTimeHelper from "@/pages/chat/helper/ChatTimeHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import SingleChatManager from "@/pages/chat/logical/handler/SingleChatManager.js"
	import GroupChatManager from "@/pages/chat/logical/handler/GroupChatManager.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	
	import UserManager from '@/pages/user/logical/UserManager.js'
	import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"
	
	import KefuJumpHelper from "@/pages/kefu/helper/KefuJumpHelper.js"
	
	const APP_RELANUCH_FIRST = "app_relanuch_first"
	
	export default {
		components:{
			"pg-actionsheet" : actionSheet,
			pgAvatar
		},
		data() {
			return {
				isRefresh : false,
				emptyArray : [],
				longPress : {
					loopTime : -1,
					value : '',
				},
				
				actionSheet : {
					show: false,
					maskClosable: true,
					tips: "",
					itemList: [{text: "删除该聊天",color: "#1a1a1a"}],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
				
				modalName: null,
				
				dataList : [],
				
				
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无会话信息~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					showView : false,
					// 是否显示内容
					showContent: false,
				},
				
				skyDesc: {
					// 是否显示内容
					skyContent: false,
					// 是否显示返回
					// isBack:true,
					// 是否显示加载(加载和返回不建议同时显示)
					// isLoad: true,
					// 页面背景颜色
					bgColor: '#eee',
					// 为空格则不显示该文字
					Desc: '暂无数据~!',
					// 字体以及字体图标颜色
					iconColor: '#000000',
					// 字体图标(可更改iconfont.css，进行覆盖)
					iconName: 'icon-icon-test',
					// 返回按钮颜色/重新按钮颜色,加载字体默认白色
					// btnColor:'#ff0000',
					// 页面高度
					height: '100%',
					// 页面宽度
					width: '100%',
					// 字体图标大小
					fontSize: '5em'
				},
			}
		},
		
		onLoad(options) {
			ConversationManager.setUICallback(this);
			
			// // #ifdef APP-PLUS
			// let isRelaunch = Cache.getValue(APP_RELANUCH_FIRST);
			// if(StringUtils.isEmpty(isRelaunch))
			// {
			// 	uni.showModal({
			// 		title: "每次退出重新登陆需要重新启动!!!",
			// 		content:"由于系统问题，如聊天输入框无法监听到高度变化！请一定要退出应用重新进入，之后就不会了！",
			// 		showCancel: false
			// 	});
			// 	Cache.setValue(APP_RELANUCH_FIRST, "true");
			// }
			// // #endif
		},
		
		onShow() {
			if(!UserManager.isLogin())
			{
				//console.log("home tabber ...........");
				UserJumpHelper.jumpToLogin();
				return;
			}
			if(!this.isRefresh)
			{
				ConversationManager.reload();
				this.isRefresh = true;
			}
		},
		onNavigationBarButtonTap(e){
			uni.clearStorage();
			uni.navigateTo({
				url:"../../chat/view/hm-chat"
			})
		},
		methods: {
			onMessage(myDataList)
			{
				let len = myDataList.length;
				this.emptySdk.showView = len == 0;
				// if(len > 0)
				// {
				// 	this.dataList = this.emptyArray;
				// }
				this.dataList = myDataList;
				 //console.log(myDataList);
				// 解决页面刷新问题
				// this.$nextTick(function(){
				// 	this.dataList = myDataList;
				// })
			},
			
			handleKey(item)
			{
				//console.log("==========home key : ", item);
				return item.event+item.fromUserid+item.targetid
			},
			
			getTitle(value)
			{
				let nickname = value;
			},
			
			showAlert(item)
			{
				return item.status;
			},
			
			showBadge(item)
			{
				let badge = item.badge
				return badge > 0;
			},
			
			getBadge(item)
			{
				let badge = item.badge;
				//console.log("fasdfasdfsaf=", badge);
				if(badge > 0)
				{
					return badge + "";
				} else
				{
					return '';
				}
			},
			
			getTime(item)
			{
				return ChatTimeHelper.getTimeValue(item.time);
			},
			
			deleteItem(item)
			{
				ConversationManager.removeItem(item);
			},
			
			jumpToTargetView(item)
			{
				//console.log("=========jumpToTargetView", item);
				var fromUserid = item.fromUserid;
				var event = item.event;
				
				var userInfo = UserManager.getUserInfo();
				
				if(StringUtils.isEqual(MessageEvent.SINGLE, event))
				{
					// 获取目标id
					var targetid = item.fromUserid;
					if(StringUtils.isEqual(userInfo.username, fromUserid))
					{
						targetid = item.targetid;
					}
					// 好友id
					ChatJumpHelper.jumpToSingleChat(targetid);
				}
				else if(StringUtils.isEqual(MessageEvent.GROUP, event))
				{
					var targetid = item.targetid;
					// targetid 表示群id
					ChatJumpHelper.jumpToGroupChat(targetid);
				}
				else if(StringUtils.isEqual(MessageEvent.KEFU, event))
				{
					// 获取目标id
					var targetid = item.fromUserid;
					if(StringUtils.isEqual(userInfo.username, fromUserid))
					{
						targetid = item.targetid;
					}
					// targetid 表示群id
					KefuJumpHelper.jumpToKefuChat(targetid);
				}
				
				// 更新当前列表为第一个
				ConversationManager.updateItem(item);
			},
			// ListTouch触摸开始
			openActionSheet(value){
				var that = this;
				this.longPress.value = value;
				//this.actionSheet.show = true;
				var itemList = ['删除该聊天'];
				uni.showActionSheet({
				    itemList: itemList,
				    success: function (res) {
						that.onActionSheetItemClickForSystem(itemList[res.tapIndex])
				    },
				});
			},
			closeActionSheet: function() {
				this.longPress.value = '';
				this.actionSheet.show = false
			},
			onActionSheetItemClickForSystem(itemTextValue) {
				if(StringUtils.isEqual(itemTextValue, '删除该聊天'))
				{
					this.deleteItem(this.longPress.value);
					this.longPress.value = '';
				}
			},
			onActionSheetItemClick: function(e) {
				var index = e.index;
				var itemTextValue = this.actionSheet.itemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '删除该聊天'))
				{
					this.deleteItem(this.longPress.value);
					this.longPress.value = '';
				}
				this.closeActionSheet();
			},
		},
		
	}
</script>

<style>
	
	.flex-item {
		width: 33.3%;
		height: 100px;
		text-align: center;
		line-height: 100px;
	}
	
	.uni-media-list-logo {height: 48px;width: 48px;position: relative;}
	
	.uni-media-list-text-top{padding-top: 5px;}
	.uni-media-list-text-bottom{padding-top: 2px;}
	.pg_media_list_right{height: 48px;}
	.sp{
		position: absolute;
		right: -6px;
		background-color: #f95454;
		color: #fff;
		font-size: 12px;
		width: 19px;
		height: 19px;
		line-height: 19px;
		text-align: center;
		border-radius: 50%;
		top: -7px;
	}
</style>
