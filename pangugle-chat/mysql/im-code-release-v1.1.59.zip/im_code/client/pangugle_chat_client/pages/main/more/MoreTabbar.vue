<template>
	
	<view class="content">
		
		<view class="uni-list pg_uni_media_list">
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" @tap="jumpToPersonInfoList">
				<view class="uni-media-list uni-list-cell-navigate uni-navigate-right pg_media_list">
					<pg-image-cache class="uni-media-list-logo pg_media_list_logo" :imgSrc="userInfo.avatar"></pg-image-cache>
					
					<view class="uni-media-list-body pg_media_list_body">
						<view class="uni-media-list-text-top pg_media_list_text">{{userInfo.nickname}}</view>
						<view class="uni-media-list-text-bottom uni-ellipsis pg_media_list_bottom">用户名：{{userInfo.username}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<uni-list>
			<!-- <uni-list-item title="扫一扫"   class="uni-list-cell-navigate uni-navigate-right pg_navigate_right" :show-arrow="false" hover-class="uni-list-cell-hover" @click="jumpToSetting()" /> -->
			<uni-list-item title="修改密码" hover-class="uni-list-cell-hover"  @click="jumpToModifyPassword()" />
			<uni-list-item title="我的名片" hover-class="uni-list-cell-hover"  @click="jumpToMyQrcodeCard()" />
			<uni-list-item title="IM介绍" hover-class="uni-list-cell-hover"  @click="jumpToOfficial()" />
			<uni-list-item title="开发文档" hover-class="uni-list-cell-hover"  @click="jumpToDevDocument()" />
			<!-- <uni-list-item title="问题反馈" class="uni-list-cell-navigate uni-navigate-right pg_navigate_right" :show-arrow="false" hover-class="uni-list-cell-hover"  @click="jumpToFeedback()" /> -->
			<!-- <uni-list-item title="关于我们" hover-class="uni-list-cell-hover"  @click="jumpToAbout()" /> -->
		</uni-list>
		
		<view class="logout" @click="openActionSheet()">退出</view>
		
		<pg-actionsheet 
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.itemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
	</view>
	
</template>

<script>
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	
	import ChatManager from "@/pages/chat/logical/ChatManager.js"
	import ConversationManager from '@/pages/chat/logical/ConversationManager.js'
	import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'
	
	// framework
	import Cache from '@/pages/framework/cache/Cache.js'
	import LinkedUtils from "@/pages/framework/view/LinkedUtils.js"
	
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserManager from '@/pages/user/logical/UserManager.js'
	import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"
	
	export default {
		data() {
			return {
				
				actionSheet : {
					show: false,
					maskClosable: true,
					tips: "退出登录会清除您的登录信息，确认退出吗？",
					itemList: [{text: "退出登录",color: "#e53a37"}],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
				
				userInfo : {
					username : '',
					nickname : '',
					avatar : ''
				},
				
				reload : false,
			}
		},
		components: {
			uniList,
			uniListItem,
			"pg-actionsheet" : actionSheet,
		},
		onShow() {
			this.loadUserInfo(false);
		},
		onPullDownRefresh() {
			this.loadUserInfo(true);
		},
		methods: {
			openActionSheet(){
				
				// #ifdef APP-PLUS
				let that = this;
				uni.showModal({
				    content: '退出登录会清除您的登录信息，确认退出吗？',
				    success: function (res) {
				        if (res.confirm) {
							that.logout();
				        } else if (res.cancel) {
				        }
				    }
				});
				// #endif
				
				// #ifndef APP-PLUS
				this.actionSheet.show = true;
				// #endif
			},
			closeActionSheet: function() {
				this.actionSheet.show = false
			},
			onActionSheetItemClick: function(e) {
				this.closeActionSheet();
				this.logout();
			},
			loadUserInfo(reload)
			{
				let that = this;
				UserApi.getUserInfo(reload, userInfo => {
					//console.log(userInfo);
					that.userInfo = userInfo;
					uni.stopPullDownRefresh();
				}, (code, msg) => 
				{
					uni.stopPullDownRefresh();
				});
			},
			jumpToSetting()
			{
			},
			
			jumpToModifyPassword()
			{
				UserJumpHelper.jumpToModifyPassword();
			},
			
			jumpToMyQrcodeCard()
			{
				UserJumpHelper.jumpToMyQrcodeCard();
			},
			
			jumpToPersonInfoList()
			{
				uni.navigateTo({
					url:'/pages/user/view/more/PersonInfoList'
				})
			},
			
			jumpToFeedback()
			{
				uni.navigateTo({
					url:'/pages/main/more/Feedback'
				})
			},
			
			jumpToAbout()
			{
				uni.navigateTo({
					url:'/pages/main/more/About'
				})
			},
			
			jumpToOfficial()
			{
				LinkedUtils.openURL("https://www.pangugle.com/web/im.html", "IM介绍");
			},
			
			jumpToDevDocument()
			{
				LinkedUtils.openURL("https://www.pangugle.com/tech/article/pangugle_im/tutorial.html", "开发文档");
			},
			
			logout() {
				UserJumpHelper.jumpToLogin();
			}
			
		}
	}
</script>

<style>
	.uni-list-cell{padding-top: 32px;padding-bottom: 10px;;}
	.uni-list::after{background-color: #fff;} 
	.uni-list{margin-bottom: 10px;}
	
	.logout {
		background-color: #fff;
		text-align: center;
		font-size:16px;
		line-height: 48px;
		margin-top: 10px;
	}
</style>
