<template>
	
	<view class="page">
		
		<view class="uni-list">
			<view class="uni-list-cell" 
				hover-class="uni-list-cell-hover"  
				v-for="(item, key) in mDataList" :key="key"
				@tap="jumpToKefuChat(item)">
				<view class="uni-media-list ">
					<pg-avatar class="uni-media-list-logo" :dataList="[item.avatar]">
					</pg-avatar>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<sunui-template  
			v-if="emptySdk.show" 
			:skyContent="emptySdk.showContent" 
			:skyDesc="emptySdk.skyDesc">
		</sunui-template>
		
	</view>
	
</template>

<script>
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import KefuJumpHelper from "@/pages/kefu/helper/KefuJumpHelper.js"
	import KefuInfoManager from "@/pages/kefu/logical/KefuInfoManager.js"
	
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	export default {
		components: {
			uniList,
			uniListItem,
			pgAvatar
		},
		data() {
			return {
				mDataList : [],
				
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无数据~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					show : false,
					// 是否显示内容
					showContent: false,
				},
			}
		},
		onLoad(options) {
			this.loadDataRequest(false);
		},
		onPullDownRefresh() {
			this.loadDataRequest(true);
		},
		
		methods:{
			handleTitle(item)
			{
				let nickname = item.nickname;
				if(StringUtils.isEmpty(nickname))
				{
					nickname = item.username;
				}
				let userInfo = UserManager.getUserInfo();
				if(StringUtils.isEqual(userInfo.username, item.username))
				{
					nickname += "(我)";
				}
				return nickname;
			},
			loadDataRequest(reload)
			{
				let that = this;
				KefuInfoManager.refreshKefuList(reload, (dataList) => {
					that.emptySdk.show = dataList.length == 0;
					that.mDataList = [];
					that.$nextTick(function(){
						that.mDataList = dataList;
						//console.log(dataList);
					})
					uni.stopPullDownRefresh();
				})
			},
			jumpToKefuChat(item)
			{
				let userInfo = UserManager.getUserInfo();
				if(!StringUtils.isEqual(userInfo.username, item.username))
				{
					KefuJumpHelper.jumpToKefuChat(item.username);
				}
				else
				{
					ToastUtils.showText("无法对自己发送消息!");
				}
			}
		}
	}
</script>

<style>
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
</style>
