import Cache from "@/pages/framework/cache/Cache.js"
import StringUtils from "@/pages/framework/utils/StringUtils.js"
import KefuApi from "@/pages/kefu/service/KefuApi.js"

const CACHE_KEY = "pangugle_kefu_KefuInfoManager_kefulist";

const KefuInfoManager = {
	
	refreshKefuList(refresh, callback)
	{
		let cacheDataList = Cache.getValue(CACHE_KEY) || [];
		
		if(cacheDataList.length > 0 && !refresh)
		{
			if(callback != null)
			{
				callback(cacheDataList);
			}
			
			return;
		}
		
		KefuApi.getKefuList((dataList) => 
		{
			if(dataList != null && dataList.length > 0)
			{
				Cache.setValue(CACHE_KEY, dataList);
			}
			if(callback != null)
			{
				callback(dataList);
			}
		});
	},
	
	getKefuInfo(username, callback)
	{
		let self = this;
		self.refreshKefuList(false, (dataList) => {
			if(dataList == null || dataList.length == 0)
			{
				return;
			}
			let len = dataList.length;
			for(let i = 0; i < len; i ++)
			{
				let item = dataList[i];
				if(StringUtils.isEqual(item.username, username))
				{
					callback(item);
					return;
				}
			}
		});
	},
	
	getKefuInfoSync(username)
	{
		let cacheDataList = Cache.getValue(CACHE_KEY) || [];
		let len = cacheDataList.length;
		
		for(let i = 0; i < len; i ++)
		{
			let item = cacheDataList[i];
			if(StringUtils.isEqual(item.username, username))
			{
				return item;
			}
		}
		return null;
	}
}

export default KefuInfoManager