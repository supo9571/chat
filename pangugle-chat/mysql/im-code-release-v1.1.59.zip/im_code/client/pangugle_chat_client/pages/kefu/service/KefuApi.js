// framework
import ApiRequest from '@/pages/framework/http/ApiRequest.js'
import CachePolicy from '@/pages/framework/http/CachePolicy.js'


const KefuApi = {
	
	getKefuList(success)
	{
		//console.log("aaaaaaa");
		let params = {};
		let url = '/kefu/api/getKefuList';
		ApiRequest.get(url, params, (isCache, data) => 
		{
			success(data);
		}, 
		(code, msg) => {
			success([]);
		});
	}
	
}

export default KefuApi