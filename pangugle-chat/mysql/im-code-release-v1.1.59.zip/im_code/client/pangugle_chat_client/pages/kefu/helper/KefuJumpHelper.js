import KefuInfoManager from "@/pages/kefu/logical/KefuInfoManager.js"

import UserApi from "@/pages/user/service/UserApi.js"

const KefuJumpHelper = {
	
	jumpToKefuList()
	{
		uni.navigateTo({
			url: '/pages/kefu/view/KefuList'
		})
	},
	
	jumpToKefuChat(username)
	{
		//console.log("username = " + username );
		let kefuInfo = KefuInfoManager.getKefuInfoSync(username);
		if(kefuInfo != null)
		{
			uni.navigateTo({
				url: '/pages/kefu/view/KefuChat?data=' + encodeURIComponent(JSON.stringify(kefuInfo))
			})
			return;
		}
		
		UserApi.searchUserInfo(username, false, (userInfo) => {
			uni.navigateTo({
				url: '/pages/kefu/view/KefuChat?data=' + encodeURIComponent(JSON.stringify(userInfo))
			})
		});
	},
	
}

export default KefuJumpHelper