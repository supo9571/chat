<template>
	<view :style="{height:style.pageHeight+'px'}">
		<!-- :style="{height:style.contentViewHeight+'px'}" -->
		<view id="content" class="content" :style="{height:style.contentViewHeight+'px'}">
			<scroll-view class="msg-list" scroll-y="true"
				:style="{height:style.contentViewHeight+'px'}"
				:scroll-with-animation="scrollAnimation" 
				:scroll-top="scrollTop" 
				:scroll-into-view="scrollToView" 
				@click.stop="refreshDefault(true)"
				upper-threshold="50">
				<view class="row" v-for="(chatItem,index) in msgList" :key="index" :id="'msg'+chatItem.id">
					
					<!-- 系统消息 -->
					<block v-if="chatItem.data.belongType == 'system'">
						<view class="system">
							<!-- 文字消息 -->
							<view v-if="LocalMsgType.TEXT == chatItem.msgType" class="text">
								{{chatItem.data.content}}
							</view>
							<!-- 时间消息 -->
							<view v-else-if="LocalMsgType.TIME == chatItem.msgType" class="text">
								{{ChatTimeHelper.getTimeValue(chatItem.time)}}
							</view>
							<!-- 撤回消息 -->
							<view v-else-if="BasicMsgType.REVOKE == chatItem.msgType" class="text">
								{{ChatViewManager.handleRevokeMessage(chatItem)}}
							</view>
							
							<!-- 消息不支持 -->
							<view v-else class="verify_friend">
								该消息不支持
							</view>
						</view>
					</block>
					<!-- 用户消息-自己发送的 -->
					<block v-else-if="chatItem.data.belongType == 'user'">
						<!-- 自己发出的消息 -->
						<view class="my" v-if="chatItem.fromUserid == userInfo.username">
							<!-- 左-消息 -->
							<view class="left">
								<!-- 消息未送达提示 -->
								<view class="unsend" v-if="!chatItem.status" ><text >!</text></view>
								<!-- 文字消息 -->
								<!-- 
									@touchstart.stop.prevent="discard"
									@touchmove.stop.prevent="discard"
									-->
								<view v-if="BasicMsgType.TEXT == chatItem.msgType" class="bubble"
									@longpress="openActionSheet(chatItem)">
									<rich-text :nodes="chatItem.data.showText"></rich-text>
								</view>
								<!-- 语言消息 -->
								<view v-else-if="BasicMsgType.VOICE == chatItem.msgType" 
									@longpress="openActionSheet(chatItem)"
									class="bubble voice" 
									@click.stop="playVoice(chatItem)" 
									:class="playMsgid == chatItem.id?'play':''">
									<view class="length">{{chatItem.data.playTime}}</view>
									<view class="icon my-voice"></view>
								</view>
								<!-- 图片消息 -->
								<view v-else-if="BasicMsgType.IMAGE == chatItem.msgType"
									@longpress="openActionSheet(chatItem)"
									class="bubble img" 
									@click.stop="showPic(chatItem)">
									<pg-image-cache :imgSrc="chatItem.data.url" :style="{'width': chatItem.data.width+'px','height': chatItem.data.height+'px'}"></pg-image-cache>
								</view>
								<!-- 名片消息 -->
								<view v-else-if="BasicMsgType.CARD == chatItem.msgType" class="bubble card" 
									@longpress="openActionSheet(chatItem)"
									@click.stop="jumpToUserBasicInfo(chatItem)">
									<view class="card_top">
										<view class="card_top_img"><pg-image-cache :imgSrc="chatItem.data.avatar"></pg-image-cache></view>
										<view class="card_top_rg">
											<view>{{chatItem.data.nickname}}</view>
											<view>{{chatItem.data.username}}</view>
										</view>
									</view>
									<view class="card_bot">个人名片</view>
								</view>
								
								<!-- 消息不支持 -->
								<view v-else class="bubble">
									<text>该消息不支持,请升级最新版本</text>
								</view>
							</view>
							<!-- 右-头像 -->
							<view class="right">
								<pg-image-cache :imgSrc="userInfo.avatar"></pg-image-cache>
							</view>
						</view>
						<!-- 别人发出的消息 -->
						<view class="other" v-if="chatItem.fromUserid == friendInfo.username">
							<!-- 左-头像 -->
							<view class="left" @click="jumpToUserBasicInfo(null)">
								<pg-image-cache :imgSrc="friendInfo.avatar"></pg-image-cache>
							</view>
							<!-- 右-用户名称-时间-消息 -->
							<view class="right">
								<!-- 
								<view class="username">
									<view class="name">{{handleFriendTitle()}}</view>
								</view>
								-->
								<!-- 文字消息 -->
								<view 
									v-if="BasicMsgType.TEXT == chatItem.msgType" class="bubble"
									@longpress="openActionSheet(chatItem)">
									<rich-text :nodes="chatItem.data.showText" ></rich-text>
								</view>
								<!-- 语音消息 -->
								<view v-else-if="BasicMsgType.VOICE == chatItem.msgType" 
									@longpress="openActionSheet(chatItem)"
									class="bubble voice" 
									@click.stop="playVoice(chatItem)" 
									:class="playMsgid == chatItem.id?'play':''">
									<view class="icon other-voice"></view>
									<view class="length">{{chatItem.data.playTime}}</view>
								</view>
								<!-- 图片消息 -->
								<view v-else-if="BasicMsgType.IMAGE == chatItem.msgType"
									@longpress="openActionSheet(chatItem)"
									class="bubble img" @click.stop="showPic(chatItem)">
									<pg-image-cache :imgSrc="chatItem.data.url" :style="{'width': chatItem.data.width+'px','height': chatItem.data.height+'px'}"></pg-image-cache>
								</view>
								<!-- 名片消息 -->
								<view v-else-if="BasicMsgType.CARD == chatItem.msgType" class="bubble card" 
									@longpress="openActionSheet(chatItem)"
									@click.stop="jumpToUserBasicInfo(chatItem)">
									<view class="card_top">
										<view class="card_top_img"><pg-image-cache :imgSrc="chatItem.data.avatar"></pg-image-cache></view>
										<view class="card_top_rg">
											<view>{{chatItem.data.nickname}}</view>
											<view>{{chatItem.data.username}}</view>
										</view>
									</view>
									<view class="card_bot">个人名片</view>
								</view>
								
								<!-- 消息不支持 -->
								<view v-else class="bubble">
									<text>该消息不支持,请升级最新版本</text>
								</view>
							</view>
							
						</view>
					</block>
				</view>
			</scroll-view>
		</view>
			
		<!-- 底部 -->
		<view id="footInputBar">
			<!-- 抽屉栏 -->
			<view class="popup-layer" :class="popupLayerClass" 
			@touchmove.stop.prevent="discard">
				<!-- 表情 --> 
				<!-- -->
				<view :class="{hidden:optStatus != optStatusMap.emotion}" >
					<swiper class="emoji-swiper" 

					indicator-dots="true" 
					duration="150" 
					>
						<swiper-item v-for="(page,pid) in emojiList" :key="pid">
							<view v-for="(em,eid) in page" :key="eid" @tap="addEmoji(em)">
								<!-- <image mode="widthFix" :src="emojiPath+em.url"></pg-image-cache> -->
								<pg-image-cache :imgSrc="emojiPath+em.url"></pg-image-cache>
							</view>
						</swiper-item>
					</swiper> 
					<view class="foot_emoji">
						<view class="foot_emoji_send" @click="sendText()">发送</view>
						<view class="foot_emoji_del" @click="backText()"><pg-image-cache imgSrc="/static/chat/tab/keyboard_key_delete_down.png" ></pg-image-cache></view>
					</view>
				</view>
				<!-- 
				<emotion @addEmoji="addEmoji" :class="{hidden:optStatus != optStatusMap.emotion}" ></emotion>
				-->
				<!-- 更多功能 相册-拍照-红包 -->
				<view class="more-layer" :class="{hidden:optStatus != optStatusMap.more}">
					<view class="list">
						<view class="box" @tap="openAlbum">
							<view class="icon tupian2"></view>
						</view>
						<view class="box" @tap="openCamera">
							<view class="icon paizhao"></view>
						</view>
						<!--
						<view class="box" @tap="openPersonCard">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/userinfo.png"></pg-image-cache>
						</view>-->
					</view>
				</view>
			</view>
			<!-- 底部输入栏 -->
			<view class="input-box" 
				:style="{bottom:style.input_bottom +'px'}"
				:class="popupLayerClass" 
				@touchmove.stop.prevent="discard">
				<!-- H5下不能录音，输入栏布局改动一下     -->
				<!-- #ifndef H5 -->
				<view class="voice">
					<!--
					<view class="icon" :class="isVoice?'jianpan':'yuyin'" @tap="switchVoice"></view>
					<view class="icon" :class="optStatus == optStatusMap.input ? 'jianpan':'yuyin'" @tap="switchVoice"></view>
					-->
					<view v-if="optStatus == optStatusMap.def" class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					<view v-else-if="optStatus == optStatusMap.voice" class="jianpan" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/keyboard.png" mode=""></pg-image-cache>
					</view>
					<view v-else-if="optStatus == optStatusMap.input" class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					<view v-else class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					
				</view>
				<!-- #endif -->
				
				<view class="textbox">
					<view class="voice-mode" 
						:class="[(optStatus == optStatusMap.voice)?'':'hidden', recording?'recording':'']" 
						@touchstart="onVoiceBegin" @touchmove.stop.prevent="onVoiceIng"
						@touchend="onVoiceEnd" @touchcancel="onVoiceCancel">{{voiceTis}}
					</view>
					<view class="text-mode"  :class="optStatus == optStatusMap.voice?'hidden':''">
						<view class="box">
							<!-- <input 
								:maxlength="inputMaxlength" 
								:focus="optStatus == optStatusMap.input"
								:confirm-hold="true"
								confirm-type="go"
								v-model="textMsg" 
								@focus="onInputFocus" 
								@blur="onInputBlur"
								@confirm="onInputConfirm" /> -->
							<textarea 
								:maxlength="inputMaxlength" 
								:confirm-hold="true"
								:auto-height="false"
								:adjust-position="false"
								:show-confirm-bar="false"
								v-model="textMsg" 
								@focus="onInputFocus" 
								@blur="onInputBlur"
								/>
						</view>
						<view class="em" @tap="chooseEmoji">
							<view class="biaoqing">
								<pg-image-cache imgSrc="/static/chat/emotion.png" mode=""></pg-image-cache>
							</view>
						</view>
					</view>
				</view>
				
				<view class="more" @tap="showMore">
					<!--  v-if="textMsg.length == 0 || optStatus != optStatusMap.input" 发送会跳，暂时关闭 -->
					<view v-if="textMsg.length > 0 && optStatus == optStatusMap.input" @touchend.prevent="sendText" class="send">
						<view class="btn">发送</view>
					</view>
					<view v-else class="add">
						<pg-image-cache imgSrc="/static/chat/moreinfo.png" mode=""></pg-image-cache>
					</view>
					<!-- 发送会跳，暂时关闭, 日后有方案再处理
					<input v-else class="btn_send_message"
						:focus="isActiveSend"
						:adjust-position="false"
						:confirm-hold="true"
						value="发送"
						@focus="onSendFocus"
						@blur="onSendBlur"/>
						-->
				</view>
				
				<!-- <view class="send" :class="optStatus == optStatusMap.voice?'hidden':''" @tap="sendText">
					<view class="btn">发送</view>
				</view> -->
			</view>
			<!-- 录音UI效果 -->
			<!-- #ifndef H5 -->
			<chat-record ref="mChatRecordUI" @onRecordFinish="onRecordFinish" /> 
			<!-- #endif -->
		</view>
		
		<pg-actionsheet
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.currentItemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
	</view>
</template>
<script>
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import chatRecord from "@/components/pg-chat/chat-record.vue"
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import CachePolicy from '@/pages/framework/http/CachePolicy.js'
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	import EmotionUtils from "@/pages/framework/utils/EmotionUtils.js"
	
	// user
	import UserManager from '@/pages/user/logical/UserManager.js'
	
	// chat
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
	import ChatTimeHelper from "@/pages/chat/helper/ChatTimeHelper.js"
	import KefuChatManager from "@/pages/kefu/logical/KefuChatManager.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import ChatViewManager from "@/pages/chat/logical/ChatViewManager.js"
	
	import IMApi from "@/pages/chat/service/IMApi.js"
	
	
	
	// 进入其它特殊页面，并不是退出，如转成，查看图册
	var isActive = false;
	export default {
		components: {
			"pg-actionsheet" : actionSheet,
			chatRecord,
		},
		data() {
			return {
				
				style: {
					pageHeight: 0,
					defPageHeight : 0,
					contentViewHeight: 0,
					footInputHeight: 49,
					mitemHeight: 0,
					input_bottom : -0.5
				},
				optStatusMap : {
					def : 'def',
					voice : 'voice',
					input : 'input',
					more : 'more',
					emotion : 'emotion',
					showpic : 'showpic',
					dispatch : 'dispatch',
				},
				optStatus : 'def', // default, voice, input, more, emotion
				
				//文字消息
				// dotsCurrent:1,
				textMsg:'',
				inputMaxlength : 150,
				isActiveSend : false,
				mInputConfirmType : 'send',
				//消息列表
				isHistoryLoading:false,
				scrollAnimation:false,
				scrollTop:0,
				scrollToView:'',
				msgList:[],
				myuid:0,
				
				//录音相关参数
				voiceTis:'按住 说话',
				recording:false,
				initPoint:{identifier:0,Y:0},
				
				//播放语音相关参数
				AUDIO:uni.createInnerAudioContext(),
				playMsgid:null,
				VoiceTimer:null,
				// 抽屉参数
				popupLayerClass:'',
				// more参数
				//hideMore:true,
				//表情定义
				//hideEmoji:true,
				emojiList:[],
				emojiPath:'',
				
				//红包相关参数
				windowsState:'',
				redenvelopeData:{
					rid:null,	//红包ID
					from:null,
					face:null,
					blessing:null,
					money:null
				},
				
				// 实体信息
				friendInfo : {
					username : '',
					nickname : '',
					alias : '',
					avatar : '',
				},
				userInfo : {
					username : '',
					nickname : '',
					avatar : '',
				},
				
				// 引入进来的都要在这里定义下
				BasicMsgType : BasicMsgType,
				LocalMsgType : LocalMsgType,
				
				//
				ChatTimeHelper : ChatTimeHelper,
				ProtocolHelper : ProtocolHelper,
				ChatViewManager : ChatViewManager,
				
				//
				messageEvent : 'kefu',
				
				actionSheet : {
					optValue : null,
					show: false,
					maskClosable: true,
					tips: "",
					currentItemList : [],
					leftItemList : [
						{text: "复制",color: "#1a1a1a"},
						{text: "删除",color: "#1a1a1a"},
					],
					rightItemList: [
						{text: "复制",color: "#1a1a1a"},
						{text: "删除",color: "#1a1a1a"},
						//{text: "撤回",color: "#1a1a1a"},
					],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
			};
		},
		onLoad(options) {
			isActive = false;
			
			let data = JSON.parse(decodeURIComponent(options.data));
			// 参数有长度限制
			this.friendInfo.username = data.username;
			this.friendInfo.nickname = data.nickname;
			this.friendInfo.avatar = data.avatar;
			
			if(StringUtils.isEmpty(this.friendInfo.nickname))
			{
				this.friendInfo.nickname = data.username;
			}
			
			let title = this.friendInfo.nickname;
			// 设置导航栏标题
			uni.setNavigationBarTitle({
			    title: title
			});
			
			// user
			let userInfo = UserManager.getUserInfo();
			this.userInfo.username = userInfo.username;
			this.userInfo.nickname = userInfo.nickname;
			this.userInfo.avatar = userInfo.avatar;
			//console.log("user info : ", UserManager, userInfo);
			
			// 设置UI
			KefuChatManager.setUICallback(this, this.friendInfo.username)
			
			//this.getMsgList();
			// this.initTestData();
			
			//语音自然播放结束
			this.AUDIO.onEnded((res)=>{
				this.playMsgid=null;
			});
			
			// 微信表情
			this.emojiList = EmotionUtils.getDataList();
			this.emojiPath = EmotionUtils.getServerPath();
			
			let that = this;
			setTimeout(function() {
				that.scrollAnimation = true;
			}, 1500);
			
			// #ifdef H5
			uni.onWindowResize((res) => {
				//console.log("=====onWindowResize");
				//console.log('变化后的窗口宽度=' + res.size.windowWidth)
				//const info = uni.getSystemInfoSync();
				//console.log('变化后的窗口高度=', res)
				// // #ifdef APP-PLUS
				// that.style.pageHeight = res.size.windowHeight;
				// //  #endif
				
				let myRes = uni.getSystemInfoSync();
				let platform = myRes.platform;
				if(!StringUtils.isEqual("ios", platform))
				{
					that.style.pageHeight = res.size.windowHeight;
					//that.textMsg += res.size.windowHeight + "-"
					that.scrollToView = '';
					that.updateContentHeight(true);
				}
				
			})
			//  #endif
			
			// #ifndef H5
			uni.onKeyboardHeightChange(res => {
				//console.log("================= defPageHeight = " + that.style.defPageHeight, ", keybodyHeight = ",  res);
				let myRes = uni.getSystemInfoSync();
				let platform = myRes.platform;
				
				that.style.input_bottom = res.height;
				that.style.pageHeight = that.style.defPageHeight - res.height;
				that.scrollToView = '';
				that.updateContentHeight(true);
				
			});
			// #endif
			
		},
		
		onUnload() {
			uni.offWindowResize(function(){
			})
			isActive = false;
			KefuChatManager.setActive(false);
			uni.hideKeyboard();
		},
		
		onShow(){
			
			// const res = uni.getSystemInfoSync()
			// console.log(res);
			if(isActive)
			{
				this.optStatus = this.optStatusMap.def;
				this.updateContentHeight(false);
				return;
			}
			// 放在最后
			isActive = true;
			KefuChatManager.setActive(isActive);
			
			this.style.defPageHeight = uni.getSystemInfoSync().windowHeight;
			
			// 重新加载数据
			KefuChatManager.reload(UserManager.getUserInfo().username, this.friendInfo.username);
		},
		onHide() {
			
			if(StringUtils.isEqual(this.optStatus, this.optStatusMap.showpic))
			{
				return;
			}
			isActive = false;
			KefuChatManager.setActive(isActive);
		},
		methods:{
			scrollToBottom()
			{
				if(!StringUtils.isEqual(this.optStatus, this.optStatusMap.input))
				{
					this.scrollToView = '';
				}
				let that = this;
				this.$nextTick(function() {
					let len = that.msgList.length;
					if(len > 0)
					{
						let model = that.msgList[len - 1];
						// 滚动到底
						that.scrollToView = 'msg'+model.id;
					}
				});
			},
			
			updateContentHeight(isScrollToBottom)
			{
				let that = this;
				// #ifdef H5
				let myRes = uni.getSystemInfoSync(); 
				let platform = myRes.platform;
				if(StringUtils.isEqual("ios", platform))
				{
					that.style.contentViewHeight = that.style.defPageHeight - 50;
					if(isScrollToBottom)
					{
						//console.log("=======pageHeight = " + pageHeight, ", footerHeight = " + data.height, ",    contentHeight = " + that.style.contentViewHeight, "       = ", data);
						that.scrollToBottom();
					}
					return;
				}
				// #endif
				
				this.$nextTick(function(){
					
					// input
					if(StringUtils.isEqual(that.optStatus, that.optStatusMap.input))
					{
						const res = uni.getSystemInfoSync();// 获取系统信息
						let pageHeight = res.windowHeight;
						//that.style.pageHeight = res.windowHeight;
						// #ifndef H5
							// 由于app 计算高度时的bug，这里不就不采用这个api，直接采用监听windowsize的高度
							pageHeight = that.style.pageHeight;
						// #endif
						
						
						that.style.contentViewHeight = pageHeight - 50 ; //像素
						//that.textMsg = that.style.contentViewHeight + "-" + pageHeight
						if(isScrollToBottom)
						{
							//console.log("=======pageHeight = " + pageHeight, ", footerHeight = " + data.height, ",    contentHeight = " + that.style.contentViewHeight, "       = ", data);
							that.scrollToBottom();
						}	
						return;
						let popupQuery = uni.createSelectorQuery().in(that).select(".input-box");
						popupQuery.fields({
							size: true,
							rect : true
						}, data => {
							const res = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = res.windowHeight;
							//that.style.pageHeight = res.windowHeight;
							// #ifdef APP-PLUS
								// 由于app 计算高度时的bug，这里不就不采用这个api，直接采用监听windowsize的高度
								pageHeight = that.style.pageHeight;
							// #endif
							
							that.style.contentViewHeight = pageHeight - data.height ; //像素
							if(isScrollToBottom)
							{
								//console.log("=======pageHeight = " + pageHeight, ", footerHeight = " + data.height, ",    contentHeight = " + that.style.contentViewHeight, "       = ", data);
								that.scrollToBottom();
							}
							
						}).exec();
						
					}
					// more emotion
					else if(
						StringUtils.isEqual(that.optStatus, that.optStatusMap.more) || 
						StringUtils.isEqual(that.optStatus, that.optStatusMap.emotion))
					{
						let query = uni.createSelectorQuery()
						query.select('.input-box').boundingClientRect()
						query.select('.popup-layer').boundingClientRect()
						query.exec((res) => {
							
							const systemInfo = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = systemInfo.windowHeight;
							that.style.pageHeight = systemInfo.windowHeight;
							that.style.contentViewHeight = pageHeight - res[1].height - res[0].height ; //像素
							if(isScrollToBottom)
							{
								that.scrollToBottom();
							}
						})
					}
					else {
						let popupQuery = uni.createSelectorQuery().in(that).select(".input-box");
						popupQuery.fields({
							size: true
						}, data => {
							const res = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = res.windowHeight;
							that.style.pageHeight = res.windowHeight;
							that.style.contentViewHeight = that.style.pageHeight - data.height ; //像素
							if(isScrollToBottom)
							{
								that.scrollToBottom();
							}
						}).exec();
					}
				})
			},
			// 切换语音/文字输入
			switchVoice(){
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				this.hideDrawer();
				// 默认， 语音按钮
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.def))
				{
					this.optStatus = this.optStatusMap.voice;
				}
				else if(StringUtils.isEqual(this.optStatus, this.optStatusMap.voice))
				{
					// 输入状态，键盘
					this.optStatus = this.optStatusMap.input;
				}
				else if(StringUtils.isEqual(this.optStatus, this.optStatusMap.input))
				{
					// 语音状态，语音
					this.optStatus = this.optStatusMap.voice;
				}
				else 
				{
					this.optStatus = this.optStatusMap.def;
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			// 选择表情
			chooseEmoji(){
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.emotion))
				{
					this.optStatus = this.optStatusMap.def;
					this.hideDrawer();
				}
				else
				{
					this.optStatus = this.optStatusMap.emotion;
					this.openDrawer();
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			//更多功能(点击+弹出) 
			showMore(){
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.more))
				{
					this.optStatus = this.optStatusMap.def;
					this.hideDrawer();
				}
				else
				{
					this.optStatus = this.optStatusMap.more;
					this.openDrawer();
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			/**
			 * 恢复默认
			 */
			refreshDefault(isScrollToBottom)
			{
				if(this.optStatus != this.optStatusMap.def && this.optStatus != this.optStatusMap.voice)
				{
					this.optStatus = this.optStatusMap.def;
					//uni.hideKeyboard();
					this.hideDrawer();
					this.updateContentHeight(isScrollToBottom);
				}
			},
			// 打开抽屉
			openDrawer(){
				this.popupLayerClass = 'showLayer';
			},
			// 隐藏抽屉
			hideDrawer(){
				this.popupLayerClass = '';
			},
			onSendFocus(){
				this.isActiveSend = false;
				this.optStatus = this.optStatusMap.input;
				this.sendText();
			},
			onSendBlur()
			{
				this.isActiveSend = false;
				this.optStatus = this.optStatusMap.input;
			},
			//获取焦点，如果不是选表情ing,则关闭抽屉
			onInputFocus(e){
				//console.log("=====onInputFocus");
				this.optStatus = this.optStatusMap.input;
				this.hideDrawer();
				//this.updateContentHeight(true);
			},
			//失去焦点
			onInputBlur(e){
			},
			onInputConfirm()
			{
				this.sendText();
			},
			onInputChange(e)
			{
				try{
					let value = e.detail.value;
					let len = value.length;
					let ch = value.charAt(value.length - 1).charCodeAt();
					//let num = Number(ch);
					//console.log("========= ch " + ch);
					// 监听回车
					if(ch == 10)
					{
						this.$nextTick(function(){
							this.sendText();
						})
						return;
					}
					// 退格|删除
					else if(ch == 40664)
					{
						return;
					}
					
					if(len >= this.inputMaxlength - 1 )
					{
						//this.textMsg = value.substr(0, len - 2);
						this.$nextTick(function(){
							this.textMsg = value.substr(0, len - 2);
						})
					}
				}catch(e){
					//TODO handle the exception
				}
			},
			// =========================== 长按相关================
			openActionSheet(optValue){
				let itemList = [];
				this.actionSheet.optValue = optValue;
				let item = optValue;
				if(StringUtils.isEqual(BasicMsgType.TEXT, item.msgType))
				{
					//itemList.push({text: "复制",color: "#1a1a1a"});
				}
				itemList.push({text: "删除",color: "#1a1a1a"});
				if(ProtocolHelper.isSelfProtocol(item))
				{
					// 没有发送成功
					if(!item.status)
					{
						let resendItem = {text: "重发",color: "#1a1a1a"};
						itemList.push(resendItem);
					}
					// 时间超过120s 不能撤回
					let date = new Date();
					if( date.getTime() - item.time <= 120000)
					{
						let resendItem = {text: "撤回",color: "#1a1a1a"};
						itemList.push(resendItem);
					}
				}
				
				if(
					StringUtils.isEqual(BasicMsgType.TEXT, this.actionSheet.optValue.msgType) || 
					StringUtils.isEqual(BasicMsgType.IMAGE, this.actionSheet.optValue.msgType))
				{
					// 
					let dispatchItem = {text: "转发", color: "#1a1a1a"};
					itemList.push(dispatchItem);
				}
				if(StringUtils.isEqual(item.msgType, BasicMsgType.IMAGE))
				{
					let album = {text: "图册",color: "#1a1a1a"};
					itemList.push(album)
				}
				this.actionSheet.currentItemList = itemList;
				this.actionSheet.show = true;
				//
				this.$nextTick(function(){
					uni.hideKeyboard();
				})
			},
			closeActionSheet: function() {
				this.actionSheet.optValue = null;
				this.actionSheet.show = false;
			},
			onActionSheetItemClick: function(e) {
				if(this.actionSheet.optValue == null)
				{
					return;
				}
				let index = e.index;
				let itemTextValue = this.actionSheet.currentItemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '复制'))
				{
					let content = ProtocolHelper.getProtocolText(this.actionSheet.optValue);
					uni.setClipboardData({
					    data: content
					});
				}
				else if(StringUtils.isEqual(itemTextValue, '删除'))
				{
					KefuChatManager.deleteMessage(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '撤回'))
				{
					let msgBody = ProtocolHelper.revoke(this.actionSheet.optValue);
					MessageHelper.sendMessage(msgBody);
				}
				else if(StringUtils.isEqual(itemTextValue, '图册'))
				{
					this.showPic(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '重发'))
				{
					// 重新发送
					this.actionSheet.optValue.optType = 'resend';
					MessageHelper.sendMessage(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '转发'))
				{
					isActive = true;
					// 转发
					ChatJumpHelper.jumpToShareToConversation(this.actionSheet.optValue);
				}
				
				this.closeActionSheet();
			},
			//=================================================== 文本消息
			// 发送文字消息
			sendText(){
				if(StringUtils.isEmpty(this.textMsg))
				{
					return;
				}
				ChatViewManager.sendText(this.friendInfo.username, this.messageEvent, this.textMsg);
				this.textMsg = '';
			},
			backText()
			{
				if(StringUtils.isEmpty(this.textMsg))
				{
					return;
				}
				let value = this.textMsg;
				let len = value.length;
				this.textMsg = StringUtils.substr(value, 0, len - 2);
			},
			//添加表情
			addEmoji(em){
				this.textMsg+=em.alt;
			},
			
			//=================================================== 语音消息
			// 播放语音
			playVoice(row){
				if(!StringUtils.isEmpty(this.playMsgid))
				{
					this.playMsgid = null;
					this.AUDIO.stop();
				}
				this.playMsgid=row.id;
				this.AUDIO.src = row.data.url;
				//this.AUDIO.src = '/static/voice/2.mp3';
				this.AUDIO.play();
			},
			// 录音开始
			onVoiceBegin(e){
				if(e.touches.length>1){
					return ;
				}
				this.recording = true;
				this.initPoint.Y = e.touches[0].clientY;
				this.initPoint.identifier = e.touches[0].identifier;
				this.$refs.mChatRecordUI.start();
				//this.RECORDER.start({format:"mp3", duration:10000});//录音开始, 设置最长10s
			},
			//录音开始UI效果
			
			// 录音被打断
			onVoiceCancel(){
				this.recording = false;
				this.voiceTis='按住 说话';
				this.$refs.mChatRecordUI.cancer();
			},
			// 录音中(判断是否触发上滑取消发送)
			onVoiceIng(e){
				if(!this.recording){
					return;
				}
				let touche = e.touches[0];
				//上滑一个导航栏的高度触发上滑取消发送
				if(this.initPoint.Y - touche.clientY>=uni.upx2px(100)){
					this.$refs.mChatRecordUI.updateStopStatus(true);
				}else{
					this.$refs.mChatRecordUI.updateStopStatus(false);
				}
			},
			// 结束录音
			onVoiceEnd(e){
				if(!this.recording){
					return;
				}
				this.recording = false;
				this.voiceTis='按住 说话';
				this.$refs.mChatRecordUI.stop();
			},
			//录音结束(回调文件)
			onRecordFinish(e){
				let recordPath = e.recordPath;
				let recordLenght = e.recordLenght;
				// 上传音频地址
				let that = this;
				IMApi.uploadVoice(recordPath, (data) => {
					MessageHelper.sendVoice(that.friendInfo.username, that.messageEvent, data, recordLenght);
				}, null);
			},
			//=================================================== 图片消息
			//选照片 or 拍照
			chooseImage(type){
				this.refreshDefault(false);
				ChatViewManager.doChooseImage(type, this.friendInfo.username, this.messageEvent)
			},
			
			// 打开红包
			openRedEnvelope(msg,index){
			},
			//领取详情
			toDetails(rid){
				uni.navigateTo({
					url:'HM-details/HM-details?rid='+rid
				})
			},
			// 预览图片
			showPic(row){
				this.optStatus = this.optStatusMap.showpic;
				ChatViewManager.doShowPicture(row, this.msgList);
			},
			discard(){
				return;
			},
			
			//=================================================== 消息处理
			handleFriendTitle()
			{
				if(!StringUtils.isEmpty(this.friendInfo.alias))
				{
					return this.friendInfo.alias;
				}
				if(!StringUtils.isEmpty(this.friendInfo.nickname))
				{
					return this.friendInfo.nickname;
				}
				return this.friendInfo.username;
			},
			
			//=================================================== 消息监听
			/**
			 * 监听消息回调
			 * @param {Object} dataArray
			 */
			onReceivedMessage(dataArray)
			{
				// for(let i in dataArray)
				// {
				// 	let item = dataArray[i];
				// 	console.log("item time = " + item.data.belongType);
				// }
				// console.log(typeof(dataArray), "length = " +dataArray.length);
				this.msgList = dataArray;
				//console.log(dataArray);
				this.updateContentHeight(true);
				//this.scrollToBottom();
				//console.log(this.msgList);
			},
			
			//=================================================== 底部更多按钮
			// 选择图片发送
			openAlbum(){
				this.chooseImage('album');
			},
			//拍照发送
			openCamera(){
				this.chooseImage('camera');
				//ChatViewManager.doChooseVideo(this.friendInfo.username, this.messageEvent);
			},
			openPersonCard()
			{
				this.optStatus = this.optStatusMap.dispatch;
				let body = ProtocolHelper.card(this.friendInfo.username, this.messageEvent, '', '', '');
				ChatJumpHelper.jumpToShareCard(body);
				this.hideDrawer();
			},
			jumpToUserBasicInfo(item)
			{
				let username = '';
				// 点击头像
				if(item == null)
				{
					username = this.friendInfo.username;
				}
				else if(StringUtils.isEqual(item.msgType, BasicMsgType.CARD))
				{
					username = item.data.username;
				}
				else
				{
					username = item.data.username;
				}
				
				if(StringUtils.isEmpty(username))
				{
					return;
				}
				ChatJumpHelper.jumpToUserBasicInfo(username);
			},
			
		}
	}
</script>
<style lang="scss">
	@import "@/components/pg-chat/style.scss"; 
	.add image{width: 30px;height: 30px;margin-top: 6px;}
	
	.voice image{width: 30px;height: 30px;margin-top: 6px}
	.biaoqing{padding-right: 5px;}
	.biaoqing image{width: 30px;height: 30px;margin-top: 8px;}
	.uni-swiper-dots{bottom: 0;}
	
</style>