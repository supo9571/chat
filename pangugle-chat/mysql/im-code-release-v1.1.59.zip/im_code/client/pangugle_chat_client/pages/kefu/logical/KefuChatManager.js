// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ConversationManager from '@/pages/chat/logical/ConversationManager.js'
import LocalPushHelper from "@/pages/chat/helper/LocalPushHelper.js"

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js" 
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"

import RecordManager from "@/pages/chat/logical/RecordManager.js"
import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
import KefuChatInterceptor from "@/pages/kefu/interceptor/KefuChatInterceptor"

import UserManager from '@/pages/user/logical/UserManager.js'

const EVENT_NAME = MessageEvent.KEFU;

/**
 * 客服
 */
const mRecordManager = new RecordManager(EVENT_NAME);


const  KefuChatManager = {
	
	getInterceptor()
	{
		return KefuChatInterceptor;
	},
	
	getEvent()
	{
		return EVENT_NAME;
	},
	
	onStart()
	{
		this.mFriendUsername = '';
		ConversationManager.registerChatHandler(EVENT_NAME, this);
	},
	
	isActive()
	{
		return StringUtils.asBoolean(this.mIsActive);
	},
	
	setActive(active)
	{
		this.mIsActive = active;
	},
	
	/**
	 * 删除消息, 一个消息
	 * @param {Object} dataJson
	 */
	deleteMessage(dataJson)
	{
		let dataArray = mRecordManager.deleteRecordItem(dataJson);
		//console.log(dataArray);
		if(this.mUICallback != null)
		{
			this.mUICallback.onReceivedMessage(dataArray);
		}
	},
	
	/**
	 * 删除一个用户的所有消息, 每个消息处理器都要实现这个类
	 * @param {Object} event
	 * @param {Object} fromUserid
	 * @param {Object} targetid
	 */
	deleteMessageList: function(event, fromUserid, targetid)
	{
		//console.log("deleteMessageList = " + event, fromUserid + ", " + targetid);
		mRecordManager.deleteRecordList(event, fromUserid, targetid);
	},
	
	/*
	constructor() {
	    this.mRecordManager = new RecordManager('single');
		this.mUICallback = null;
	}*/
	/**
	 * @param {Object} dataJson
	 * @param {Object} msgOptStatus new|resend
	 */
	onReceivMessage(dataJson)
	{
		//console.log("receiv single chat : ", dataJson);
		let msgType = dataJson.msgType;
		let fromUserid = dataJson.fromUserid;
		let targetid = dataJson.targetid;
		// 消息操作状态
		let optType = dataJson.optType;
		
		// 不是好友关系的消息不能处理，非法消息
		let friendUsername = fromUserid;
		let selfUsername = UserManager.getUserInfo().username;
		// 自己发送的消息
		let isSelfSend = false;
		if(StringUtils.isEqual(selfUsername, fromUserid))
		{
			isSelfSend = true;
			friendUsername = targetid;
		}
		
		// 消息重新发送
		if(StringUtils.isEqual(optType, 'resend'))
		{
			let dataArray = mRecordManager.updateRecordItem(dataJson);
			if(this.mUICallback != null)
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
		}
		// 刷新消息发送失败状态
		else if(StringUtils.isEqual(optType, 'refresh_status'))
		{
			let dataArray = mRecordManager.updateRecordItem(dataJson);
			if(this.mUICallback != null)
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
		}
		// 消息撤回
		else if(BasicMsgType.REVOKE == msgType)
		{
			let dataArray = mRecordManager.updateRecordItem(dataJson);
			if(this.mUICallback != null)
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
			
			let addBadge = !this.mIsActive;
			ConversationManager.handle(dataJson, addBadge);
		}
		// 需要保存聊天记录的
		else if(BasicMsgType.TEXT == msgType ||
			BasicMsgType.IMAGE == msgType ||
			BasicMsgType.VOICE == msgType ||
			BasicMsgType.FILE == msgType ||
			BasicMsgType.SHOURT_VIDEO == msgType ||
			BasicMsgType.POSITION == msgType ||
			BasicMsgType.CARD == msgType ||
			BasicMsgType.RED_PACKET == msgType ||
			// 以下是local msg type
			StringUtils.isEqual(LocalMsgType.REJECT, msgType) || 
			StringUtils.isEqual(LocalMsgType.VERIFY_FRIEND, msgType) || 
			StringUtils.isEqual(LocalMsgType.TEXT, msgType)
			)
		{
			// 保存聊天记录
			let dataArray = mRecordManager.addRecord(dataJson);
			//
			if(this.mUICallback != null && StringUtils.isEqual(friendUsername, this.mFriendUsername))
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
			
			//console.log("UICallback =============== ", (this.mUICallback != null));
			
			let addBadge = !isSelfSend && !StringUtils.asBoolean(this.mIsActive) ;
			
			// 更新会话信息
			ConversationManager.handle(dataJson, addBadge);
			
			// 处理本地推送消息
			LocalPushHelper.sendNotify(dataJson);
		}
		else if(BasicMsgType.SHARE_POSITION_UPDATE == msgType)
		{
			// 实时位置信息
			if(this.mUICallback != null && StringUtils.isEqual(friendUsername, this.mFriendUsername))
			{
				this.mCallback.updatePosition(dataJson);
			}
		}
	},
	
	reload(fromUserid, targetid)
	{
		let dataArray = mRecordManager.getDataArray(EVENT_NAME, fromUserid, targetid);
		//console.log("aaaaaaaaaaa", dataArray);
		if(this.mUICallback != null)
		{
			this.mUICallback.onReceivedMessage(dataArray);
		}
	},
	
	setUICallback(callback, friendUsername)
	{
		this.mUICallback = callback;
		this.mFriendUsername = friendUsername;
		mRecordManager.setCurrentTargetid(friendUsername);
	}
}

export default KefuChatManager