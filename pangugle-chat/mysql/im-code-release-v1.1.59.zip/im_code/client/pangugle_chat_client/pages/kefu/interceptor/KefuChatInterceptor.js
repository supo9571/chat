import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import ChatManager from '@/pages/chat/logical/ChatManager.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"

// user
import UserManager from '@/pages/user/logical/UserManager.js'

import KefuInfoManager from '@/pages/kefu/logical/KefuInfoManager.js'

const KefuChatInterceptor = {
	
	doInputInterceptor(dataJson)
	{
		let fromUserid = dataJson.fromUserid;
		let targetid = dataJson.targetid;
		let kefuInfo = KefuInfoManager.getKefuInfoSync(fromUserid);
		// 客服->客户
		if(kefuInfo != null)
		{
			return true;
		}
		// 客户->客服
		kefuInfo = KefuInfoManager.getKefuInfoSync(targetid);
		if(kefuInfo != null)
		{
			return true;
		}
		return false;
	},
	
	doOutputInterceptor(dataJson)
	{
		let fromUserid = dataJson.fromUserid;
		let targetid = dataJson.targetid;
		let kefuInfo = KefuInfoManager.getKefuInfoSync(fromUserid);
		// 客服->客户
		if(kefuInfo != null)
		{
			return true;
		}
		// 客户->客服
		kefuInfo = KefuInfoManager.getKefuInfoSync(targetid);
		if(kefuInfo != null)
		{
			return true;
		}
		return false;
	},
	
}

export default KefuChatInterceptor