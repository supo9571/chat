<template>
	
	<view class="page">
		
		<view class="uni-list">
			<view class="uni-list-cell" 
				hover-class="uni-list-cell-hover"  
				v-for="(item, key) in mUserGroupList" :key="item.id"
				@tap="jumpToGroupChat(item)">
				<view class="uni-media-list ">
					<pg-avatar class="uni-media-list-logo" :dataList="item.iconArray">
					</pg-avatar>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<sunui-template  
			v-if="emptySdk.show" 
			:skyContent="emptySdk.showContent" 
			:skyDesc="emptySdk.skyDesc">
		</sunui-template>
		
	</view>
	
</template>

<script>
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	
	export default {
		components: {
			uniList,
			uniListItem,
			pgAvatar
		},
		data() {
			return {
				mUserGroupList : [],
				
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无数据~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					show : false,
					// 是否显示内容
					showContent: false,
				},
			}
		},
		onShow()
		{
			this.emptySdk.show = true;
			this.loadUserGroup(false);
		},
		onPullDownRefresh() {
			this.loadUserGroup(true);
		},
		onNavigationBarButtonTap(res) {
			ChatJumpHelper.jumpToGroupCreate();
		},
		methods:{
			handleTitle(item)
			{
				let groupInfo = GroupCMDManager.getGroupInfo(item.id);
				if(!StringUtils.isEmpty(groupInfo.name))
				{
					return groupInfo.name;
				}
				else
				{
					return groupInfo.alias;
				}
			},
			loadUserGroup(reload)
			{
				let that = this;
				GroupCMDManager.refreshUserGroup(reload, (isCache, dataList) => {
					let dataArray = [];
					if(dataList != null)
					{
						let split = ",";
						for(let i in dataList)
						{
							let item = dataList[i];
							let iconArray = item.icons.split(split);
							item.iconArray = iconArray;
							
							dataArray.push(item);
						}
					}
					
					that.emptySdk.show = dataArray.length == 0;
					uni.stopPullDownRefresh();
					
					that.mUserGroupList = dataArray;
					// console.log(dataArray);
					// that.mUserGroupList = [];
					// that.$nextTick(function(){
						
					// })
					
				});
			},
			jumpToGroupChat(item)
			{
				ChatJumpHelper.jumpToGroupChat(item.id);
			}
		}
	}
</script>

<style>
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
</style>
