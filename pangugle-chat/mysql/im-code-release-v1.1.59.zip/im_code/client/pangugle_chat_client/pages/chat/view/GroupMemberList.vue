<template>
	
	<view>
		<view class="uni-list">
			<view class="uni-list-cell" 
				hover-class="uni-list-cell-hover"  
				v-for="(item, key) in dataList" :key="key"
				@tap="onClickItemList(item)">
				<view class="uni-media-list ">
					<pg-avatar class="uni-media-list-logo" :dataList="[item.userAvatar]">
					</pg-avatar>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<pg-actionsheet
		 	:show="actionSheet.show" 
		 	:tips="actionSheet.tips" 
		 	:item-list="actionSheet.itemList" 
		 	:mask-closable="actionSheet.maskClosable"
		 	:color="actionSheet.color" 
		 	:size="actionSheet.size" 
		 	:is-cancel="actionSheet.isCancel" 
		 	@click="onActionSheetItemClick" 
		 	@cancel="closeActionSheet">
		</pg-actionsheet>
		
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import pgFab from "@/components/pg-fab/pg-fab.vue"
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	
	import GroupApi from "@/pages/chat/service/GroupApi.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	import GroupAtMemberManager from "@/pages/chat/logical/GroupAtMemberManager.js"
	
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	/**
	 * 消息转发器
	 */
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem,
			uniPopup,
			pgFab,
			pgAvatar,
			"pg-actionsheet" : actionSheet,
		},
		data() {
			return {
				mCurrentSelectStatus : '',
				maxSelectItemCount : 9, //最多能选择几个人
				
				dataList : [],
				mAdminList : [],
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无好友~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					showView : false,
					// 是否显示内容
					showContent: false,
				},
				
				groupInfo : {
					id : '',
					holder : '',
					enableAddFriend : false
				},
				mType : '',
				
				actionSheet : {
					optValue : {},
					show: false,
					maskClosable: true,
					tips: "",
					itemList: null,
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
			}
		},
		onLoad(options) {
			this.groupInfo.id = options.groupid;
			this.mType = options.type;
		},
		onShow() {
			this.loadMemberList(false);
		},
		onPullDownRefresh(e) {
			this.loadMemberList(true);
		},
		methods: {
			
			loadMemberList(refresh)
			{
				let that = this;
				GroupCMDManager.refreshGroupInfo(false, that.groupInfo.id, (isCache, groupInfo) => {
					
					this.mAdminList = GroupCMDManager.getAdminList(that.groupInfo.id);
					
					//console.log(this.mAdminList);
					
					that.groupInfo = groupInfo;
					//console.log(groupInfo);
					GroupCMDManager.refreshMemberList(refresh, this.groupInfo.id, (isCache, dataList) => {
						let dataArray = [];
						for(let i in dataList)
						{
							let item = dataList[i];
							item.checked = false;
							dataArray.push(item);
						}
						that.dataList = dataArray;
						uni.stopPullDownRefresh();
					})
				});
			},
			
			removeMember()
			{
				
			},
			
			handleTitle(item) 
			{
				let userInfo = UserManager.getUserInfo();
				let title = item.username;
				if(!StringUtils.isEmpty(item.groupNickname))
				{
					title = item.groupNickname;
				}
				else if(!StringUtils.isEmpty(item.userNickname))
				{
					title = item.userNickname;
				}
				if(StringUtils.isEqual(this.groupInfo.holder, item.username))
				{
					title += " (群主)";
				}
				
				if(StringUtils.isEqual(userInfo.username, item.username))
				{
					title += " - (我)";
				}
				
				if(this.isAdmin(item.username))
				{
					title += " - (管理员)";
				}
				return title;
			},
			//////////////////////////////////////////////////////
			onClickItemList(item)
			{
				let userInfo = UserManager.getUserInfo();
				
				if(this.mType == 'look')
				{
					var dataItems = [];
					dataItems.push({text: "查看群成员",color: "#1a1a1a"});
					
					// 目标人是群主
					if(StringUtils.isEqual(this.groupInfo.holder, item.username))
					{
						this.actionSheet.optValue = item;
						this.actionSheet.itemList = dataItems;
						this.actionSheet.show = true;
						return;
					}
					
					this.groupInfo = GroupCMDManager.getGroupInfo(this.groupInfo.id);
					// 操作人是群主
					if(StringUtils.isEqual(this.groupInfo.holder, userInfo.username))
					{
						if(this.isAdmin(item.username))
						{
							dataItems.push({text: "移除管理员",color: "#1a1a1a"});
						}
						else
						{
							dataItems.push({text: "设为管理员",color: "#1a1a1a"});
						}
					}
					
					// 操作人自己是管理员，被操作人不是管理员
					if(!this.isAdmin(item.username) && (this.isAdmin(userInfo.username) || StringUtils.isEqual(this.groupInfo.holder, userInfo.username)) )
					{
						dataItems.push({text: "解除禁言",color: "#1a1a1a"});
						dataItems.push({text: "禁言",color: "#1a1a1a"});
					}
					
					this.actionSheet.optValue = item;
					this.actionSheet.itemList = dataItems;
					this.actionSheet.show = true;
					
					//console.log(item);
					
				}
				else if(this.mType = 'at')
				{
					//console.log("=============");
					if(StringUtils.isEqual(userInfo.username, item.username))
					{
						ToastUtils.showText("无法@自己!");
						return;
					}
					let title = item.username;
					if(!StringUtils.isEmpty(item.groupNickname))
					{
						title = item.groupNickname;
					}
					else if(!StringUtils.isEmpty(item.userNickname))
					{
						title = item.userNickname;
					}
					GroupAtMemberManager.addMember(item.username, title);
					//console.log(currentPage);
					var delta = 1;
					uni.navigateBack({delta})
				}
				
			},
			
			onActionSheetItemClick(e) {
				let index = e.index;
				let itemTextValue = this.actionSheet.itemList[index].text;
				
				let userInfo = UserManager.getUserInfo();
				
				var groupMember = this.actionSheet.optValue;
				
				if(StringUtils.isEqual(itemTextValue, '查看群成员'))
				{
					if(this.groupInfo.enableAddFriend == true || userInfo.username == this.groupInfo.holder)
					{
						ChatJumpHelper.jumpToUserBasicInfo(groupMember.username);
					}
					else
					{
						ToastUtils.showText("群主已禁止群成员加好友!");
					}
				}
				else if(StringUtils.isEqual(itemTextValue, '移除管理员'))
				{
					GroupApi.deleteGroupAdmin(this.groupInfo.id, groupMember.username, (data) => {
						GroupCMDManager.refreshGroupAdminList(this.groupInfo.id, (dataList) => {
							this.mAdminList = dataList;
							this.$forceUpdate();
						});
					}, null);
				}
				else if(StringUtils.isEqual(itemTextValue, '设为管理员'))
				{
					GroupApi.addGroupAdmin(this.groupInfo.id, groupMember.username, (data) => {
						GroupCMDManager.refreshGroupAdminList(this.groupInfo.id, (dataList) => {
							this.mAdminList = dataList;
							this.$forceUpdate();
						});
					}, null);
				}
				else if(StringUtils.isEqual(itemTextValue, '解除禁言'))
				{
					GroupApi.updateGroupMemberChatDisabledTime(this.groupInfo.id, groupMember.username, 0, (data) => {
						ToastUtils.showText("解禁成功!");
					}, null);
				}
				else if(StringUtils.isEqual(itemTextValue, '禁言'))
				{
					GroupApi.updateGroupMemberChatDisabledTime(this.groupInfo.id, groupMember.username, 1, (data) => {
						ToastUtils.showText("禁言成功!");
					}, null);
				}
				
				this.closeActionSheet();
			},
			
			closeActionSheet: function() {
				this.actionSheet.show = false
				this.actionSheet.tips = '';
				this.actionSheet.itemList = null;
			},
			
			isAdmin(member)
			{
				var len = this.mAdminList.length;
				for(var i = 0; i < len; i ++)
				{
					var adminUsername = this.mAdminList[i];
					if(adminUsername == member)
					{
						return true;
					}
				}
				return false;
			}
			
		}
	}
</script>

<style>
	checkbox{
		display: flex;
	}
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
</style>
