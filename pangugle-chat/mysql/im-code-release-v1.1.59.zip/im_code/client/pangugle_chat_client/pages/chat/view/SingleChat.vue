<template>
	<view :style="{height:style.pageHeight+'px'}">
		<!-- :style="{height:style.contentViewHeight+'px'}" -->
		<view id="content" class="content" :style="{height:style.contentViewHeight+'px'}">
			<scroll-view class="msg-list" scroll-y="true"
				:style="{height:style.contentViewHeight+'px'}"
				:scroll-with-animation="scrollAnimation" 
				:scroll-top="scrollTop" 
				:scroll-into-view="scrollToView" 
				@click.stop="refreshDefault(true)"
				upper-threshold="50">
				<view class="row" v-for="(chatItem,index) in msgList" :key="index+chatItem.id" :id="'msg'+chatItem.id">
					
					<!-- 系统消息 -->
					<block v-if="chatItem.data.belongType == 'system'">
						<view class="system">
							<!-- 文字消息 -->
							<view v-if="LocalMsgType.TEXT == chatItem.msgType" class="text">
								{{chatItem.data.content}}
							</view>
							<!-- 时间消息 -->
							<view v-else-if="LocalMsgType.TIME == chatItem.msgType" class="text">
								{{ChatTimeHelper.getTimeValue(chatItem.time)}}
							</view>
							<!-- 撤回消息 -->
							<view v-else-if="BasicMsgType.REVOKE == chatItem.msgType" class="text">
								{{ChatViewManager.handleRevokeMessage(chatItem)}}
							</view>
							<view v-else-if="LocalMsgType.VERIFY_FRIEND == chatItem.msgType" class="verify_friend">
								对方开启了好友验证，你还不是他(她)的好友。请先发送好友验证请求，对方验证通过后，才能聊天。
								<text class="text-blue" @click.stop="sendAddFriendRequest()">发送好友验证</text>
							</view>
							<!-- 领取红包消息 -->
							<view v-else-if="chatItem.data.type=='redEnvelope'" class="red-envelope">
								<pg-image-cache imgSrc="/static/img/red-envelope-chat.png"></pg-image-cache>
								{{chatItem.data.text}}
							</view>
							<!-- 消息不支持 -->
							<view v-else class="verify_friend">
								该消息不支持
							</view>
						</view>
					</block>
					<!-- 用户消息-自己发送的 -->
					<block v-else-if="chatItem.data.belongType == 'user'">
						<!-- 自己发出的消息 -->
						<view class="my" v-if="chatItem.fromUserid == userInfo.username">
							<!-- 左-消息 -->
							<view class="left">
								<!-- 消息未送达提示 -->
								<view class="unsend" v-if="!chatItem.status" ><text >!</text></view>
								<!-- 文字消息 -->
								<!-- 
									@touchstart.stop.prevent="discard"
									@touchmove.stop.prevent="discard"
									-->
								<view v-if="BasicMsgType.TEXT == chatItem.msgType" class="bubble"
									@longpress="openActionSheet(chatItem)">
									<rich-text :nodes="chatItem.data.showText"></rich-text>
								</view>
								<!-- 语言消息 -->
								<view v-else-if="BasicMsgType.VOICE == chatItem.msgType" 
									@longpress="openActionSheet(chatItem)"
									class="bubble voice" 
									@click.stop="playVoice(chatItem)" 
									:class="playMsgid == chatItem.id?'play':''">
									<view class="length">{{chatItem.data.playTime}}</view>
									<view class="icon my-voice"></view>
								</view>
								<!-- 图片消息 -->
								<view v-else-if="BasicMsgType.IMAGE == chatItem.msgType"
									@longpress="openActionSheet(chatItem)"
									class="bubble img" 
									@click.stop="showPic(chatItem)">
									<pg-image-cache :imgSrc="chatItem.data.url" :style="{'width': chatItem.data.width+'px','height': chatItem.data.height+'px'}"></pg-image-cache>
								</view>
								<!-- 名片消息 -->
								<view v-else-if="BasicMsgType.CARD == chatItem.msgType" class="bubble card" 
									@longpress="openActionSheet(chatItem)"
									@click.stop="jumpToUserBasicInfo(chatItem)">
									<view class="card_top">
										<view class="card_top_img"><pg-image-cache :imgSrc="chatItem.data.avatar"></pg-image-cache></view>
										<view class="card_top_rg">
											<view>{{chatItem.data.nickname}}</view>
											<view>{{chatItem.data.username}}</view>
										</view>
									</view>
									<view class="card_bot">个人名片</view>
								</view>
								<!-- 红包 -->
								<view v-else-if="BasicMsgType.RED_PACKET == chatItem.msgType" class="bubble red-envelope" @click="openRedEnvelope(chatItem.msg,index)">
									<pg-image-cache imgSrc="/static/chat/red-envelope.png"></pg-image-cache>
									<view class="tis">
										<!-- 点击开红包 -->
									</view>
									<view class="blessing">
										<!-- 祝福语 -->
										{{chatItem.data.blessing}}
									</view>
								</view>
								<!-- 消息不支持 -->
								<view v-else class="bubble">
									<text>该消息不支持,请升级最新版本</text>
								</view>
							</view>
							<!-- 右-头像 -->
							<view class="right">
								<pg-image-cache :imgSrc="userInfo.avatar"></pg-image-cache>
							</view>
						</view>
						<!-- 别人发出的消息 -->
						<view class="other" v-if="chatItem.fromUserid == friendInfo.username">
							<!-- 左-头像 -->
							<view class="left" @click="jumpToUserBasicInfo(null)">
								<pg-image-cache :imgSrc="friendInfo.avatar"></pg-image-cache>
							</view>
							<!-- 右-用户名称-时间-消息 -->
							<view class="right">
								<!-- 
								<view class="username">
									<view class="name">{{handleFriendTitle()}}</view>
								</view>
								-->
								<!-- 文字消息 -->
								<view 
									v-if="BasicMsgType.TEXT == chatItem.msgType" class="bubble"
									@longpress="openActionSheet(chatItem)">
									<rich-text :nodes="chatItem.data.showText" ></rich-text>
								</view>
								<!-- 语音消息 -->
								<view v-else-if="BasicMsgType.VOICE == chatItem.msgType" 
									@longpress="openActionSheet(chatItem)"
									class="bubble voice" 
									@click.stop="playVoice(chatItem)" 
									:class="playMsgid == chatItem.id?'play':''">
									<view class="icon other-voice"></view>
									<view class="length">{{chatItem.data.playTime}}</view>
								</view>
								<!-- 图片消息 -->
								<view v-else-if="BasicMsgType.IMAGE == chatItem.msgType"
									@longpress="openActionSheet(chatItem)"
									class="bubble img" @click.stop="showPic(chatItem)">
									<pg-image-cache :imgSrc="chatItem.data.url" :style="{'width': chatItem.data.width+'px','height': chatItem.data.height+'px'}"></pg-image-cache>
								</view>
								<!-- 名片消息 -->
								<view v-else-if="BasicMsgType.CARD == chatItem.msgType" class="bubble card" 
									@longpress="openActionSheet(chatItem)"
									@click.stop="jumpToUserBasicInfo(chatItem)">
									<view class="card_top">
										<view class="card_top_img"><pg-image-cache :imgSrc="chatItem.data.avatar"></pg-image-cache></view>
										<view class="card_top_rg">
											<view>{{chatItem.data.nickname}}</view>
											<view>{{chatItem.data.username}}</view>
										</view>
									</view>
									<view class="card_bot">个人名片</view>
								</view>
								<!-- 红包 -->
								<view v-else-if="BasicMsgType.RED_PACKET == chatItem.msgType" class="bubble red-envelope" @click="openRedEnvelope(chatItem.msg,index)">
									<pg-image-cache imgSrc="/static/chat/red-envelope.png"></pg-image-cache>
									<view class="tis">
										<!-- 点击开红包 -->
									</view>
									<view class="blessing">
										{{chatItem.data.blessing}}
									</view>
								</view>
								<!-- 消息不支持 -->
								<view v-else class="bubble">
									<text>该消息不支持,请升级最新版本</text>
								</view>
							</view>
							
						</view>
					</block>
				</view>
			</scroll-view>
		</view>
			
		<!-- 底部 -->
		<view id="footInputBar">
			<!-- 抽屉栏 -->
			<view class="popup-layer" :class="popupLayerClass" 
			@touchmove.stop.prevent="discard">
				<!-- 表情 --> 
				<!-- -->
				<view :class="{hidden:optStatus != optStatusMap.emotion}" >
					<swiper class="emoji-swiper" 

					indicator-dots="true" 
					duration="150" 
					>
						<swiper-item v-for="(page,pid) in emojiList" :key="pid">
							<view v-for="(em,eid) in page" :key="eid" @tap="addEmoji(em)">
								<pg-image-cache :imgSrc="emojiPath+em.url"></pg-image-cache>
							</view>
						</swiper-item>
					</swiper> 
					<view class="foot_emoji">
						<view class="foot_emoji_send" @click="sendText()">发送</view>
						<view class="foot_emoji_del" @click="backText()"><pg-image-cache imgSrc="/static/chat/tab/keyboard_key_delete_down.png" ></pg-image-cache></view>
					</view>
				</view>
				<!-- 
				<emotion @addEmoji="addEmoji" :class="{hidden:optStatus != optStatusMap.emotion}" ></emotion>
				-->
				<!-- 更多功能 相册-拍照-红包 -->
				<view class="more-layer" :class="{hidden:optStatus != optStatusMap.more}">
					<view class="list">
						<view class="box" @tap="openAlbum">
							<view class="icon tupian2"></view>
						</view>
						<view class="box" @tap="openCamera">
							<view class="icon paizhao"></view>
						</view>
						<view class="box" @tap="openPersonCard">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/userinfo.png"></pg-image-cache>
						</view>
						
						<!-- 
						<view class="box" @tap="handRedEnvelopes">
							<view class="icon hongbao"></view>
						</view>
						<view class="box" @tap="yuyintonghua">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/yuyintonghua.png"></pg-image-cache>
						</view>
						<view class="box" @tap="weizhi">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/weizhi.png"></pg-image-cache>
						</view>
						<view class="box" @tap="yuyinshuru">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/yuyinshuru.png"></pg-image-cache>
						</view>
						<view class="box" @tap="meShouchang">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/me-shouchang.png"></pg-image-cache>
						</view>
						-->
						
					</view>
				</view>
			</view>
			<!-- 底部输入栏 -->
			<view class="input-box" 
				:style="{bottom:style.input_bottom +'px'}"
				:class="popupLayerClass" 
				@touchmove.stop.prevent="discard">
				<!-- H5下不能录音，输入栏布局改动一下     -->
				<!-- #ifndef H5 -->
				<view class="voice">
					<!--
					<view class="icon" :class="isVoice?'jianpan':'yuyin'" @tap="switchVoice"></view>
					<view class="icon" :class="optStatus == optStatusMap.input ? 'jianpan':'yuyin'" @tap="switchVoice"></view>
					-->
					<view v-if="optStatus == optStatusMap.def" class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					<view v-else-if="optStatus == optStatusMap.voice" class="jianpan" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/keyboard.png" mode=""></pg-image-cache>
					</view>
					<view v-else-if="optStatus == optStatusMap.input" class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					<view v-else class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					
				</view>
				<!-- #endif -->
				
				<view class="textbox">
					<view class="voice-mode" 
						:class="[(optStatus == optStatusMap.voice)?'':'hidden', recording?'recording':'']" 
						@touchstart="onVoiceBegin" @touchmove.stop.prevent="onVoiceIng"
						@touchend="onVoiceEnd" @touchcancel="onVoiceCancel">{{voiceTis}}
					</view>
					<view class="text-mode"  :class="optStatus == optStatusMap.voice?'hidden':''">
						<view class="box">
							<!-- <input 
								:maxlength="inputMaxlength" 
								:focus="optStatus == optStatusMap.input"
								:confirm-hold="true"
								confirm-type="go"
								v-model="textMsg" 
								@focus="onInputFocus" 
								@blur="onInputBlur"
								@confirm="onInputConfirm" /> -->
							<textarea 
								:maxlength="inputMaxlength" 
								:confirm-hold="true"
								:auto-height="false"
								:adjust-position="false"
								:show-confirm-bar="false"
								v-model="textMsg" 
								@focus="onInputFocus" 
								@blur="onInputBlur"
								/>
						</view>
						<view class="em" @tap="chooseEmoji">
							<view class="biaoqing">
								<pg-image-cache imgSrc="/static/chat/emotion.png" mode=""></pg-image-cache>
							</view>
						</view>
					</view>
				</view>
				
				<view class="more" @tap="showMore">
					<!--  v-if="textMsg.length == 0 || optStatus != optStatusMap.input" 发送会跳，暂时关闭 -->
					<view v-if="textMsg.length > 0 && optStatus == optStatusMap.input" @touchend.prevent="sendText" class="send">
						<view class="btn">发送</view>
					</view>
					<view v-else class="add">
						<pg-image-cache imgSrc="/static/chat/moreinfo.png" mode=""></pg-image-cache>
					</view>
					<!-- 发送会跳，暂时关闭, 日后有方案再处理 -->
					<!-- <input v-else class="btn_send_message"
						:adjust-position="false"
						:confirm-hold="true"
						value="发送"
						@focus="onSendFocus"/> -->
				</view>
				
				
			</view>
			<!-- 录音UI效果 -->
			<!-- #ifndef H5 -->
			<chat-record ref="mChatRecordUI" @onRecordFinish="onRecordFinish" /> 
			<!-- #endif -->
		</view>
		
		<!-- 红包弹窗 -->
		<view class="windows" :class="windowsState">
			<!-- 遮罩层 -->
			<!-- <view class="mask" @touchmove.stop.prevent="discard" @tap="closeRedEnvelope"></view> -->
			<view class="layer" @touchmove.stop.prevent="discard">
				<view class="open-redenvelope">
					<view class="top">
						<view class="close-btn">
							<!-- <view class="icon close" @tap="closeRedEnvelope"></view> -->
						</view>
						<!-- <pg-image-cache imgSrc="/static/chat/im/face/face_1.jpg"></pg-image-cache> -->
					</view>
					<view class="from">来自{{redenvelopeData.from}}</view>
					<view class="blessing">{{redenvelopeData.blessing}}</view>
					<view class="money">{{redenvelopeData.money}}</view>
					<view class="showDetails" @tap="toDetails(redenvelopeData.rid)">
						查看领取详情 <view class="icon to"></view>
					</view>
				</view>
			</view>
		</view>
		
		<pg-actionsheet
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.currentItemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
	</view>
</template>
<script>
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import chatRecord from "@/components/pg-chat/chat-record.vue"
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import CachePolicy from '@/pages/framework/http/CachePolicy.js'
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	import EmotionUtils from "@/pages/framework/utils/EmotionUtils.js"
	
	import CopyUtils from "@/pages/framework/utils/CopyUtils.js"
	
	import JumpManager from "@/pages/main/logical/JumpManager.js"
	
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserManager from '@/pages/user/logical/UserManager.js'
	import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'
	
	// chat
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
	import ChatTimeHelper from "@/pages/chat/helper/ChatTimeHelper.js"
	import SingleChatManager from "@/pages/chat/logical/handler/SingleChatManager.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import ChatViewManager from "@/pages/chat/logical/ChatViewManager.js"
	import ConversationManager from "@/pages/chat/logical/ConversationManager.js"
	
	import IMApi from "@/pages/chat/service/IMApi.js"
	import FriendApi from "@/pages/chat/service/FriendApi.js"
	
	// 进入其它特殊页面，并不是退出，如转成，查看图册
	var isActive = false;
	export default {
		components: {
			"pg-actionsheet" : actionSheet,
			chatRecord,
		},
		data() {
			return {
				
				style: {
					pageHeight: 0,
					defPageHeight : 0,
					contentViewHeight: 0,
					footInputHeight: 49,
					mitemHeight: 0,
					input_bottom : -0.5
				},
				optStatusMap : {
					def : 'def',
					voice : 'voice',
					input : 'input',
					more : 'more',
					emotion : 'emotion',
					showpic : 'showpic',
					dispatch : 'dispatch',
				},
				optStatus : 'def', // default, voice, input, more, emotion
				
				//文字消息
				// dotsCurrent:1,
				mInputFocus : false,
				textMsg:'',
				inputMaxlength : 150,
				isActiveSend : false,
				mInputConfirmType : 'send',
				//消息列表
				isHistoryLoading:false,
				scrollAnimation:false,
				scrollTop:0,
				scrollToView:'',
				msgList:[],
				myuid:0,
				
				//录音相关参数
				voiceTis:'按住 说话',
				recording:false,
				initPoint:{identifier:0,Y:0},
				
				//播放语音相关参数
				AUDIO:uni.createInnerAudioContext(),
				playMsgid:null,
				VoiceTimer:null,
				// 抽屉参数
				popupLayerClass:'',
				// more参数
				//hideMore:true,
				//表情定义
				//hideEmoji:true,
				emojiList:[],
				emojiPath:'',
				
				//红包相关参数
				windowsState:'',
				redenvelopeData:{
					rid:null,	//红包ID
					from:null,
					face:null,
					blessing:null,
					money:null
				},
				
				// 实体信息
				friendInfo : {
					username : '',
					nickname : '',
					alias : '',
					avatar : '',
				},
				userInfo : {
					username : '',
					nickname : '',
					avatar : '',
				},
				
				// 引入进来的都要在这里定义下
				BasicMsgType : BasicMsgType,
				LocalMsgType : LocalMsgType,
				
				//
				ChatTimeHelper : ChatTimeHelper,
				ProtocolHelper : ProtocolHelper,
				ChatViewManager : ChatViewManager,
				
				//
				messageEvent : 'single',
				
				actionSheet : {
					optValue : null,
					show: false,
					maskClosable: true,
					tips: "",
					currentItemList : [],
					leftItemList : [
						{text: "复制",color: "#1a1a1a"},
						{text: "删除",color: "#1a1a1a"},
					],
					rightItemList: [
						{text: "复制",color: "#1a1a1a"},
						{text: "删除",color: "#1a1a1a"},
						//{text: "撤回",color: "#1a1a1a"},
					],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
			};
		},
		onLoad(options) {
			isActive = false;
			// 参数有长度限制
			this.friendInfo.username = options.friendUsername;
			
			var friendInfo = FriendInfoManager.getFriendInfo(this.friendInfo.username);
			this.friendInfo.nickname = friendInfo.nickname;
			this.friendInfo.alias = friendInfo.alias;
			this.friendInfo.avatar = friendInfo.avatar;
			
			this.$nextTick(function(){
				// 设置导航栏标题
				var title = this.friendInfo.username;
				if(!StringUtils.isEmpty(this.friendInfo.alias))
				{
					title = this.friendInfo.alias;
				}
				else if(!StringUtils.isEmpty(this.friendInfo.nickname))
				{
					title = this.friendInfo.nickname;
				}
				uni.setNavigationBarTitle({
				    title: title
				});
			})
			
			// user
			var userInfo = UserManager.getUserInfo();
			this.userInfo.username = userInfo.username;
			this.userInfo.nickname = userInfo.nickname;
			this.userInfo.avatar = userInfo.avatar;
			//console.log("user info : ", UserManager, userInfo);
			
			// 设置UI
			SingleChatManager.setUICallback(this, this.friendInfo.username)
			
			//this.getMsgList();
			// this.initTestData();
			
			//语音自然播放结束
			this.AUDIO.onEnded((res)=>{
				this.playMsgid=null;
			});
			
			// 微信表情
			this.emojiList = EmotionUtils.getDataList();
			this.emojiPath = EmotionUtils.getServerPath();
			
			let self = this;
			setTimeout(function() {
				self.scrollAnimation = true;
			}, 1500);
			
			// #ifdef H5
			uni.onWindowResize((res) => {
				//console.log("=====onWindowResize");
				//console.log('变化后的窗口宽度=' + res.size.windowWidth)
				//const info = uni.getSystemInfoSync();
				//console.log('变化后的窗口高度=', res)
				// // #ifdef APP-PLUS
				// that.style.pageHeight = res.size.windowHeight;
				// //  #endif
				// console.log("================= defPageHeight = " + self.style.defPageHeight, ", keybodyHeight = ",  res);
				// if(self.optStatus == self.optStatusMap.more || self.optStatus == self.optStatusMap.emotion)
				// {
				// 	return;
				// }
				
				let myRes = uni.getSystemInfoSync();
				let platform = myRes.platform;
				if(!StringUtils.isEqual("ios", platform))
				{
					self.style.pageHeight = res.size.windowHeight;
					//self.textMsg += res.size.windowHeight + "-"
					self.scrollToView = '';
					self.updateContentHeight(true);
				}
			})
			//  #endif
			
			// #ifndef H5
			uni.onKeyboardHeightChange(res => {
				
				//console.log("=========onKeyboardHeightChange optType = " + self.optStatus);
				//console.log("================= defPageHeight = " + self.style.defPageHeight, ", keybodyHeight = ",  res);
				// if(self.optStatus == self.optStatusMap.more || self.optStatus == self.optStatusMap.emotion)
				// {
				// 	return;
				// }
				
				//console.log("================= defPageHeight = " + self.style.defPageHeight, ", keybodyHeight = ",  res);
				let myRes = uni.getSystemInfoSync();
				let platform = myRes.platform;
				
				self.style.input_bottom = res.height;
				self.style.pageHeight = self.style.defPageHeight - res.height;
				self.scrollToView = '';
				
				//console.log("====onKeyboardHeightChange = ", that.style.input_bottom)
				
				
				self.updateContentHeight(true);
				
			});
			// #endif
			this.updateContentHeight(false);
		},
		
		onUnload() {
			uni.offWindowResize(function(){
				
			})
			isActive = false;
			SingleChatManager.setActive(false);
			uni.hideKeyboard();
		},
		
		onShow(){
			
			// const res = uni.getSystemInfoSync()
			// console.log(res);
			if(isActive)
			{
				this.optStatus = this.optStatusMap.def;
				this.updateContentHeight(false);
				return;
			}
			// 放在最后
			isActive = true;
			SingleChatManager.setActive(isActive);
			
			this.style.defPageHeight = uni.getSystemInfoSync().windowHeight;
			
			
			// 重新加载数据
			SingleChatManager.reload(UserManager.getUserInfo().username, this.friendInfo.username);
		},
		onHide() {
			
			if(StringUtils.isEqual(this.optStatus, this.optStatusMap.showpic))
			{
				return;
			}
			isActive = false;
			SingleChatManager.setActive(isActive);
		},
		onNavigationBarButtonTap() {
			this.showRightMenu();
		},
		methods:{
			
			onTap()
			{
			},
			
			scrollToBottom()
			{
				if(!StringUtils.isEqual(this.optStatus, this.optStatusMap.input))
				{
					this.scrollToView = '';
				}
				let that = this;
				this.$nextTick(function() {
					let len = that.msgList.length;
					if(len > 0)
					{
						let model = that.msgList[len - 1];
						// 滚动到底
						that.scrollToView = 'msg'+model.id;
					}
				});
			},
			
			updateContentHeight(isScrollToBottom)
			{
				//console.log("=============updateContentHeight");
				let that = this;
				// #ifdef H5
				let myRes = uni.getSystemInfoSync(); 
				let platform = myRes.platform;
				if(StringUtils.isEqual("ios", platform))
				{
					that.style.contentViewHeight = that.style.defPageHeight - 50;
					if(isScrollToBottom)
					{
						//console.log("=======pageHeight = " + pageHeight, ", footerHeight = " + data.height, ",    contentHeight = " + that.style.contentViewHeight, "       = ", data);
						that.scrollToBottom();
					}
					return;
				}
				// #endif
				
				//console.log("updateContentHeight================");
				
				
				this.$nextTick(function(){
					
					// input
					if(StringUtils.isEqual(that.optStatus, that.optStatusMap.input))
					{
						const res = uni.getSystemInfoSync();// 获取系统信息
						let pageHeight = res.windowHeight;
						//that.style.pageHeight = res.windowHeight;
						// #ifdef APP-PLUS | MP-WEIXIN
							// 由于app 计算高度时的bug，这里不就不采用这个api，直接采用监听windowsize的高度
							pageHeight = that.style.pageHeight;
						// #endif
						
						
						that.style.contentViewHeight = pageHeight - 50 ; //像素
						
							
						//that.textMsg = that.style.contentViewHeight + "-" + pageHeight
						if(isScrollToBottom)
						{
							//console.log("=======pageHeight = " + pageHeight, ", footerHeight = " + data.height, ",    contentHeight = " + that.style.contentViewHeight, "       = ", data);
							that.scrollToBottom();
						}	
						
						
					}
					// more emotion
					else if(
						StringUtils.isEqual(that.optStatus, that.optStatusMap.more) || 
						StringUtils.isEqual(that.optStatus, that.optStatusMap.emotion))
					{
						let query = uni.createSelectorQuery()
						query.select('.input-box').boundingClientRect()
						query.select('.popup-layer').boundingClientRect()
						query.exec((res) => {
							
							const systemInfo = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = systemInfo.windowHeight;
							that.style.pageHeight = systemInfo.windowHeight;
							that.style.contentViewHeight = pageHeight - res[1].height - res[0].height ; //像素
							if(isScrollToBottom)
							{
								that.scrollToBottom();
							}
						})
					}
					else {
						let popupQuery = uni.createSelectorQuery().in(that).select(".input-box");
						popupQuery.fields({
							size: true
						}, data => {
							const res = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = res.windowHeight;
							that.style.pageHeight = res.windowHeight;
							that.style.contentViewHeight = that.style.pageHeight - data.height ; //像素
							if(isScrollToBottom)
							{
								that.scrollToBottom();
							}
						}).exec();
					}
				})
			},
			// 切换语音/文字输入
			switchVoice(){
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				this.hideDrawer();
				// 默认， 语音按钮
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.def))
				{
					this.optStatus = this.optStatusMap.voice;
				}
				else if(StringUtils.isEqual(this.optStatus, this.optStatusMap.voice))
				{
					// 输入状态，键盘
					this.optStatus = this.optStatusMap.input;
				}
				else if(StringUtils.isEqual(this.optStatus, this.optStatusMap.input))
				{
					// 语音状态，语音
					this.optStatus = this.optStatusMap.voice;
				}
				else 
				{
					this.optStatus = this.optStatusMap.def;
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			// 选择表情
			chooseEmoji(){
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.emotion))
				{
					this.optStatus = this.optStatusMap.def;
					this.hideDrawer();
				}
				else
				{
					this.optStatus = this.optStatusMap.emotion;
					this.openDrawer();
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			//更多功能(点击+弹出) 
			showMore(){
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.more))
				{
					this.optStatus = this.optStatusMap.def;
					this.hideDrawer();
				}
				else
				{
					this.optStatus = this.optStatusMap.more;
					this.openDrawer();
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			/**
			 * 恢复默认
			 */
			refreshDefault(isScrollToBottom)
			{
				if(this.optStatus != this.optStatusMap.def && this.optStatus != this.optStatusMap.voice)
				{
					this.optStatus = this.optStatusMap.def;
					//uni.hideKeyboard();
					this.hideDrawer();
					this.updateContentHeight(isScrollToBottom);
				}
			},
			// 打开抽屉
			openDrawer(){
				this.popupLayerClass = 'showLayer';
			},
			// 隐藏抽屉
			hideDrawer(){
				this.popupLayerClass = '';
			},
			onSendFocus(){
				this.isActiveSend = false;
				this.optStatus = this.optStatusMap.input;
				this.sendText();
				
				// this.$nextTick(function(){
				// 	this.mInputFocus = true;
				// })
			},
			onSendBlur()
			{
				this.isActiveSend = false;
				this.optStatus = this.optStatusMap.input;
			},
			//获取焦点，如果不是选表情ing,则关闭抽屉
			onInputFocus(e){
				//console.log("=====onInputFocus");
				this.optStatus = this.optStatusMap.input;
				this.hideDrawer();
				//this.updateContentHeight(true);
			},
			//失去焦点
			onInputBlur(e){
			},
			onInputConfirm()
			{
				this.sendText();
			},
			onInputChange(e)
			{
				try{
					let value = e.detail.value;
					let len = value.length;
					let ch = value.charAt(value.length - 1).charCodeAt();
					//let num = Number(ch);
					//console.log("========= ch " + ch);
					// 监听回车
					if(ch == 10)
					{
						this.$nextTick(function(){
							this.sendText();
						})
						return;
					}
					// 退格|删除
					else if(ch == 40664)
					{
						return;
					}
					
					if(len >= this.inputMaxlength - 1 )
					{
						//this.textMsg = value.substr(0, len - 2);
						this.$nextTick(function(){
							this.textMsg = value.substr(0, len - 2);
						})
					}
				}catch(e){
					//TODO handle the exception
				}
			},
			
			//
			showRightMenu()
			{
				var itemList = [];
				itemList.push({text: "删除会话", color: "#1a1a1a"});
				itemList.push({text: "清除聊天记录", color: "#1a1a1a"});
				this.actionSheet.currentItemList = itemList;
				this.actionSheet.show = true;
				//
				this.$nextTick(function(){
					uni.hideKeyboard();
				})
			},
			
			// =========================== 长按相关================
			openActionSheet(optValue){
				let itemList = [];
				this.actionSheet.optValue = optValue;
				let item = optValue;
				if(StringUtils.isEqual(BasicMsgType.TEXT, item.msgType))
				{
					itemList.push({text: "复制",color: "#1a1a1a"});
				}
				itemList.push({text: "删除",color: "#1a1a1a"});
				if(ProtocolHelper.isSelfProtocol(item))
				{
					// 没有发送成功
					if(!item.status)
					{
						let resendItem = {text: "重发",color: "#1a1a1a"};
						itemList.push(resendItem);
					}
					// 时间超过120s 不能撤回
					let date = new Date();
					if( date.getTime() - item.time <= 120000)
					{
						let resendItem = {text: "撤回",color: "#1a1a1a"};
						itemList.push(resendItem);
					}
				}
				
				if(
					StringUtils.isEqual(BasicMsgType.TEXT, this.actionSheet.optValue.msgType) || 
					StringUtils.isEqual(BasicMsgType.IMAGE, this.actionSheet.optValue.msgType))
				{
					// 
					let dispatchItem = {text: "转发", color: "#1a1a1a"};
					itemList.push(dispatchItem);
				}
				if(StringUtils.isEqual(item.msgType, BasicMsgType.IMAGE))
				{
					let album = {text: "图册",color: "#1a1a1a"};
					itemList.push(album)
				}
				this.actionSheet.currentItemList = itemList;
				this.actionSheet.show = true;
				//
				this.$nextTick(function(){
					uni.hideKeyboard();
				})
			},
			closeActionSheet: function() {
				this.actionSheet.optValue = null;
				this.actionSheet.show = false;
			},
			onActionSheetItemClick: function(e) {
				let index = e.index;
				let itemTextValue = this.actionSheet.currentItemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '复制'))
				{
					let content = ProtocolHelper.getProtocolText(this.actionSheet.optValue);
					CopyUtils.doCopy(content);
				}
				else if(StringUtils.isEqual(itemTextValue, '删除'))
				{
					SingleChatManager.deleteMessage(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '撤回'))
				{
					let msgBody = ProtocolHelper.revoke(this.actionSheet.optValue);
					MessageHelper.sendMessage(msgBody);
				}
				else if(StringUtils.isEqual(itemTextValue, '图册'))
				{
					this.showPic(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '重发'))
				{
					// 重新发送
					this.actionSheet.optValue.optType = 'resend';
					MessageHelper.sendMessage(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '转发'))
				{
					isActive = true;
					// 转发
					ChatJumpHelper.jumpToShareToConversation(this.actionSheet.optValue);
				}
				
				// right menu
				else if(StringUtils.isEqual(itemTextValue, '清除聊天记录'))
				{
					SingleChatManager.deleteMessageList(this.messageEvent, this.userInfo.username, this.friendInfo.username);
				}
				else if(StringUtils.isEqual(itemTextValue, '删除会话'))
				{
					ConversationManager.removeItemWithID(this.messageEvent, this.userInfo.username, this.friendInfo.username);
					JumpManager.jumpToHome();
				}
				else
				{
					return;
				}
				// if(this.actionSheet.optValue == null)
				// {
				// 	return;
				// }
				
				this.closeActionSheet();
			},
			//=================================================== 文本消息
			// 发送文字消息
			sendText(){
				if(StringUtils.isEmpty(this.textMsg))
				{
					return;
				}
				ChatViewManager.sendText(this.friendInfo.username, this.messageEvent, this.textMsg);
				this.textMsg = '';
			},
			backText()
			{
				if(StringUtils.isEmpty(this.textMsg))
				{
					return;
				}
				let value = this.textMsg;
				let len = value.length;
				this.textMsg = StringUtils.substr(value, 0, len - 2);
			},
			//添加表情
			addEmoji(em){
				this.textMsg+=em.alt;
			},
			
			//=================================================== 语音消息
			// 播放语音
			playVoice(row){
				if(!StringUtils.isEmpty(this.playMsgid))
				{
					this.playMsgid = null;
					this.AUDIO.stop();
				}
				this.playMsgid=row.id;
				this.AUDIO.src = row.data.url;
				//this.AUDIO.src = '/static/voice/2.mp3';
				this.AUDIO.play();
			},
			// 录音开始
			onVoiceBegin(e){
				if(e.touches.length>1){
					return ;
				}
				this.recording = true;
				this.initPoint.Y = e.touches[0].clientY;
				this.initPoint.identifier = e.touches[0].identifier;
				this.$refs.mChatRecordUI.start();
				//this.RECORDER.start({format:"mp3", duration:10000});//录音开始, 设置最长10s
			},
			//录音开始UI效果
			
			// 录音被打断
			onVoiceCancel(){
				this.recording = false;
				this.voiceTis='按住 说话';
				this.$refs.mChatRecordUI.cancer();
			},
			// 录音中(判断是否触发上滑取消发送)
			onVoiceIng(e){
				if(!this.recording){
					return;
				}
				let touche = e.touches[0];
				//上滑一个导航栏的高度触发上滑取消发送
				if(this.initPoint.Y - touche.clientY>=uni.upx2px(100)){
					this.$refs.mChatRecordUI.updateStopStatus(true);
				}else{
					this.$refs.mChatRecordUI.updateStopStatus(false);
				}
			},
			// 结束录音
			onVoiceEnd(e){
				if(!this.recording){
					return;
				}
				this.recording = false;
				this.voiceTis='按住 说话';
				this.$refs.mChatRecordUI.stop();
			},
			//录音结束(回调文件)
			onRecordFinish(e){
				let recordPath = e.recordPath;
				let recordLenght = e.recordLenght;
				// 上传音频地址
				let that = this;
				IMApi.uploadVoice(recordPath, (data) => {
					MessageHelper.sendVoice(that.friendInfo.username, that.messageEvent, data, recordLenght);
				}, null);
			},
			//=================================================== 图片消息
			//选照片 or 拍照
			chooseImage(type){
				this.refreshDefault(false);
				ChatViewManager.doChooseImage(type, this.friendInfo.username, this.messageEvent)
			},
			
			// 打开红包
			openRedEnvelope(msg,index){
			},
			//领取详情
			toDetails(rid){
				uni.navigateTo({
					url:'HM-details/HM-details?rid='+rid
				})
			},
			// 预览图片
			showPic(row){
				this.optStatus = this.optStatusMap.showpic;
				ChatViewManager.doShowPicture(row, this.msgList);
			},
			discard(){
				return;
			},
			
			//=================================================== 消息处理
			handleFriendTitle()
			{
				if(!StringUtils.isEmpty(this.friendInfo.alias))
				{
					return this.friendInfo.alias;
				}
				if(!StringUtils.isEmpty(this.friendInfo.nickname))
				{
					return this.friendInfo.nickname;
				}
				return this.friendInfo.username;
			},
			
			//=================================================== 消息监听
			/**
			 * 监听消息回调
			 * @param {Object} dataArray
			 */
			onReceivedMessage(dataArray)
			{
				// for(let i in dataArray)
				// {
				// 	let item = dataArray[i];
				// 	console.log("item time = " + item.data.belongType);
				// }
				// console.log(typeof(dataArray), "length = " +dataArray.length);
				this.msgList = dataArray;
				//console.log(dataArray);
				this.updateContentHeight(true);
				//this.scrollToBottom();
				//console.log(this.msgList);
			},
			
			//=================================================== 底部更多按钮
			// 选择图片发送
			openAlbum(){
				this.chooseImage('album');
			},
			//拍照发送
			openCamera(){
				this.chooseImage('camera');
				//ChatViewManager.doChooseVideo(this.friendInfo.username, this.messageEvent);
			},
			openPersonCard()
			{
				this.optStatus = this.optStatusMap.dispatch;
				let body = ProtocolHelper.card(this.friendInfo.username, this.messageEvent, '', '', '');
				ChatJumpHelper.jumpToShareCard(body);
				this.hideDrawer();
			},
			jumpToUserBasicInfo(item)
			{
				let username = '';
				// 点击头像
				if(item == null)
				{
					username = this.friendInfo.username;
				}
				else if(StringUtils.isEqual(item.msgType, BasicMsgType.CARD))
				{
					username = item.data.username;
				}
				else
				{
					username = item.data.username;
				}
				
				if(StringUtils.isEmpty(username))
				{
					return;
				}
				ChatJumpHelper.jumpToUserBasicInfo(username);
			},
			
			/**
			 * 好友验证请求
			 */
			sendAddFriendRequest()
			{
				if(FriendCMDManager.isFriend(this.friendInfo.username))
				{
					ToastUtils.showText("你已是对方的好友了!");
					return;
				}
				let that = this;
				let remark = '';
				if(!StringUtils.isEmpty(this.friendInfo.nickname))
				{
					remark = "我是" + this.friendInfo.nickname;
				}
				FriendApi.addFriend(that.friendInfo.username, remark, () => 
				{
					ToastUtils.showSuccess('验证请求已发送', null);
				}, 
				//
				(code, msg) => 
				{
					// 已为好友
					if(code == -16)
					{
						FriendCMDManager.refreshFriendList(true, null);
						// 你已添加了
						let showName = that.friendInfo.username;
						if(!StringUtils.isEmpty(that.friendInfo.alias))
						{
							showName = that.friendInfo.alias;
						}
						else if(!StringUtils.isEmpty(that.friendInfo.nickname))
						{
							showName = that.friendInfo.nickname;
						}
						let content = '你已添加了' + showName + ", 现在可以聊天了。";
						let body = ProtocolHelper.localTextTips(that.friendUsername, 'single', content);
						MessageHelper.sendMessage(body);
					}
					else
					{
						ToastUtils.showFailure(msg);
					}
				})
			},
			//=================================================== 底部按钮
			initTestData()
			{
				// local
				// revoke
				let body1_revoke = ProtocolHelper.text(this.userInfo.username, MessageEvent.SINGLE, 'hello a');
				body1_revoke = ProtocolHelper.revoke(body1_revoke);
				this.msgList.push(body1_revoke);
				
				// verify
				let body_verify_friend = ProtocolHelper.localVerifyFriend(this.friendInfo.username, this.messageEvent);
				this.msgList.push(body_verify_friend);
				
				let date = new Date();
				let body_date = ProtocolHelper.localTime(date);
				this.msgList.push(body_date);
				
				//////// friend
				// text
				let body1_text = ProtocolHelper.text(this.userInfo.username, MessageEvent.SINGLE, 'hello a');
				this.msgList.push(body1_text);
				
				let body2_text = ProtocolHelper.text(this.userInfo.username, MessageEvent.SINGLE, 'hello b');
				body2_text.fromUserid = this.friendInfo.username;
				body2_text.targetid = this.userInfo.username;
				this.msgList.push(body2_text);
				
				// voice
				let body1_voice = ProtocolHelper.voice(this.userInfo.username, MessageEvent.SINGLE, 'xxx', 22);
				this.msgList.push(body1_voice);
				
				let body2_voice = ProtocolHelper.voice(this.userInfo.username, MessageEvent.SINGLE, 'xxxx', 33);
				body2_voice.fromUserid = this.friendInfo.username;
				body2_voice.targetid = this.userInfo.username;
				this.msgList.push(body2_voice);
				
				this.updateContentHeight(true);
			},
			
			jumpToWebview(url)
			{
				console.log("url = " + url);
			},
		}
	}
</script>
<style lang="scss">
	@import "@/components/pg-chat/style.scss"; 
	.add image{width: 30px;height: 30px;margin-top: 6px;}
	
	.voice image{width: 30px;height: 30px;margin-top: 6px}
	.biaoqing{padding-right: 5px;}
	.biaoqing image{width: 30px;height: 30px;margin-top: 8px;}
	.uni-swiper-dots{bottom: 0;}
	
</style>