<template>
	
	<view>
		
		<view class="uni-list">
			<view class="uni-list-cell" 
				hover-class="uni-list-cell-hover"  
				v-for="(item, key) in mUserGroupList" :key="key"
				@tap="onClickForUserGroupList(item)">
				<view class="uni-media-list ">
					<checkbox v-if="actionSheet.isMultiCheckeMode" :value="item.username" :disabled="true" :checked="item.checked" />
					
					<pg-avatar class="uni-media-list-logo" :dataList="item.iconArray">
					</pg-avatar>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<pg-actionsheet
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.currentItemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
		
		<uni-popup class="pg_popup" :show="alertView.show" type="center" :mask-click="false" >
			<view class="title_top">{{handleAlertViewTopTitle()}}</view>
			<!-- 发送谁 -->
			<view class="pdLR">
				<view class="top_">
					<!-- 单人 显示头像和名字-->
					<view class="single_people"
						v-if="!actionSheet.isMultiCheckeMode && receivInfo.length > 0">
						<pg-avatar 
							:length="receivInfo[0].avatar.length" 
							:dataList="receivInfo[0].avatar">
						</pg-avatar>
						<text>{{receivInfo[0].title}}</text>
					</view>
					
					<!-- 多人 显示头像 -->
					<view v-else class="many_people">
						<pg-avatar
							v-for="(item, key) in receivInfo" :key="key"
							:length="item.avatar.length" 
							:dataList="item.avatar">
						</pg-avatar>
					</view>
				</view>
				
				<view class="bot_">
					<!-- 内容 内容 -->
					<view v-if="messageBody.msgType === BasicMsgType.TEXT" class="con_txt">
						<view>{{messageBody.data.content}}</view>
					</view>
					
					<!-- 内容 图片 -->
					<view v-else-if="messageBody.msgType === BasicMsgType.IMAGE" class="con_img">
						<image :src="messageBody.data.url" mode="aspectFit"></image>
					</view>
				</view>
				
			</view>
			<!-- 按钮 -->
			<view class="btn_bot">
				<view class="cancel" @click="onCloseAlertView()">取消</view>
				<view class="send" @click="onEnterAlertView()">确定</view>
			</view>
		</uni-popup>
		
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import Pinyin from '../../framework/utils/Pinyin.js'
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	import pgActionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import ConversationManager from "@/pages/chat/logical/ConversationManager.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem,
			pgAvatar,
			uniPopup,
			"pg-actionsheet": pgActionSheet
		},
		data() {
			return {
				mUserGroupList : [],
				
				mCurrentSelectStatus : '',
				maxSelectItemCount : 9, //最多能选择几个人
				
				
				actionSheet : {
					optValue : null,
					isMultiCheckeMode : false, //是否是多选
					show: false,
					maskClosable: true,
					tips: "",
					currentItemList : [
						{text: "单选",color: "#1a1a1a"},
						{text: "多选",color: "#1a1a1a"},
						{text: "立即发送",color: "#1a1a1a"},
					],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
				
				alertView : {
					show : false,
				},
				
				msgEvent : 'group',
				messageBody : null,
				
				// 发送人信息
				receivInfo : [],
				
				BasicMsgType : BasicMsgType,
			}
		},
		onLoad(options) {
			let data = JSON.parse(decodeURIComponent(options.data));
			this.messageBody = data;
		},
		onShow() {
			let dataArray = GroupCMDManager.getUserGroup();
			for(let i in dataArray)
			{
				let item = dataArray[i];
				item.checked = false;
			}
			
			this.mUserGroupList = dataArray;
		},
		onNavigationBarButtonTap(e) {
			if(this.actionSheet.currentItemList.length == 0)
			{
				this.actionSheet.currentItemList = this.actionSheet.singleItemList;
			}
			this.actionSheet.show = true;
		},
		methods: {
			handleTitle(item)
			{
				let title = item.alias;
				if(!StringUtils.isEmpty(item.name))
				{
					title = item.name;
				}
				return title;
			},
			
			////////////////
			jumpToShareToFriend()
			{
				ChatJumpHelper.jumpToShareToFriend(this.messageBody);
			},
			jumpToShareToGroup()
			{
				ChatJumpHelper.jumpToShareToGroup(this.messageBody);
			},
			handleAlertViewTopTitle()
			{
				if(this.actionSheet.isMultiCheckeMode)
				{
					return "分别发送给:";
				}
				else
				{
					return "发送给:";
				}
			},
			closeActionSheet: function() {
				this.actionSheet.optValue = null;
				this.actionSheet.show = false;
			},
			onActionSheetItemClick: function(e) {
				let index = e.index;
				let itemTextValue = this.actionSheet.currentItemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '单选'))
				{
					this.actionSheet.isMultiCheckeMode = false;
				}
				else if(StringUtils.isEqual(itemTextValue, '多选'))
				{
					for(let i in this.mUserGroupList)
					{
						let item = this.mUserGroupList[i];
						item.checked = false;
					}
					this.actionSheet.isMultiCheckeMode = true;
				}
				else if(StringUtils.isEqual(itemTextValue, '立即发送'))
				{
					let currentSelectCount = 0;
					//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
					let len = this.mUserGroupList.length;
					let selectItemList = [];
					for(let i = 0; i < len; i ++)
					{
						let item = this.mUserGroupList[i];
						if(item.checked)
						{
							let selectItem = {
								'avatar' : item.iconArray,
								'title' : item.name,
								'event' : this.msgEvent,
								'targetid' :item.id,
							};
							selectItemList.push(selectItem);
						}
					}
					if(selectItemList.length > 0)
					{
						this.receivInfo = selectItemList;
						this.alertView.show = true;
					}
					else
					{
						if(!this.actionSheet.isMultiCheckeMode)
						{
							ToastUtils.showText("多选时才使用!")
						}
						else
						{
							ToastUtils.showText("请选择发送人!")
						}
					}
					
				}
				
				this.closeActionSheet();
			},
			
			////////////////
			onCloseAlertView()
			{
				this.alertView.show = false;
			},
			
			/**
			 * 点击完成发送消息
			 */
			onEnterAlertView()
			{
				let userInfo = UserManager.getUserInfo();
				for(let i in this.receivInfo)
				{
					let item = this.receivInfo[i];
					
					let jsonString = JSON.stringify(this.messageBody);
					let newMsgBody = JSON.parse(jsonString);
					newMsgBody.targetid = item.targetid;
					newMsgBody.event = item.event;
					newMsgBody.fromUserid = userInfo.username;
					
					//console.log("send message body : ", newMsgBody);
					
					MessageHelper.sendMessage(newMsgBody);
				}
				this.onCloseAlertView();
				uni.navigateBack({
				    delta: 2
				});
			},
			
			/**
			 * item 点击事件
			 * @param {Object} item
			 */
			onClickForUserGroupList(item)
			{
				//console.log(item);
				// 单选模式
				if(!this.actionSheet.isMultiCheckeMode)
				{
					this.messageBody.event = item.event;
					this.messageBody.targetid = item.targetid;
					
					let receivList = [];
					let receivInfoItem = {
						"avatar" : item.iconArray,
						"title" : this.handleTitle(item),
						"event" : this.msgEvent,
						"targetid" : item.id,
					}
					//console.log("receiv info : ", receivInfoItem);
					receivList.push(receivInfoItem);
					this.receivInfo = receivList;
					
					this.alertView.show = true;
					return;
				}
				//多选模式
				let currentSelectCount = 0;
				//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
				let len = this.mUserGroupList.length;
				for(let i = 0; i < len; i ++)
				{
					let item = this.mUserGroupList[i];
					if(item.checked)
					{
						currentSelectCount ++;
					}
				}
				if(this.maxSelectItemCount <= currentSelectCount)
				{
					ToastUtils.showText("最多只能选择" + this.maxSelectItemCount + "人!")
					return;
				}
				item.checked = !item.checked;
			}
		}
	}
</script>

<style>
	checkbox{
		display: flex;
	}
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
	.pdLR{padding: 0 16px;width: 250px;}
	.title_top{
		padding: 10px 16px 6px 16px;
		color: #000;
		font-size: 18px;
		text-align: left;
	}
	.top_{
		border-bottom: 1px solid #f2f2f2;
		padding-bottom: 7px;
	}
	.single_people{
		display: flex;
		flex-direction: row;
		align-items:center;
	}
	.single_people view{height: 35px;width: 35px;}
	.single_people image{border-radius: 3px;}
	.single_people text{
		font-size: 18px;margin-left: 7px;
		overflow: hidden;
		white-space: nowrap;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
	}

	.many_people{
		padding: 2.5px;
		display: flex;
		/* flex-wrap: wrap; */
		/* justify-content: space-between; */
		/* background-color: #ccc; */
		max-height: 40px;
		overflow: hidden;
	}
	.many_people view{
		width: 35px;
		height: 35px;
		border:2px solid #fff;
	}
	
	.li{
		width: 35px;
		height: 35px;
	}
	.bot_{
		padding: 10px 0;
	}
	.con_img{
		text-align: center;
	}
	.con_img image{
		max-width: 70%;
		max-height: 250px;
	}
	.con_txt{
		max-height: 50px;
		min-height: 25px;
		overflow: hidden;
		text-align: left;
		background-color: #f2f2f2;
		padding: 5px;
	}
	.con_txt view,.con_sg_txt view{
		font-size: 14px;
		color: #999;
		line-height: 22px;
	}
	.con_sg_txt{
		text-align: left;
		height: 20px;
	}
	.con_sg_txt view{
		overflow: hidden;
		white-space: nowrap;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
	}
	.btn_bot{
		border-top: 1px solid #f2f2f2;
		display: flex;
		justify-content:space-between;
	}
	.btn_bot view{
		width: 50%;
		height: 45px;
		line-height: 45px;
		text-align: center;
		font-size: 18px;
		font-weight: 500;
	}
	.cancel{border-right: 1px solid #f2f2f2;color: #000;}
	.send{color: #657ee0;}
</style>
