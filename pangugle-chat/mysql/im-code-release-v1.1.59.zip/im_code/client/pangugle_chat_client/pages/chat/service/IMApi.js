// framework
import ApiRequest from '@/pages/framework/http/ApiRequest.js'


const IMApi = {
	getOfflineMessage(page, success)
	{
		let params = {
			page : page,
		}
		let url = '/im/api/getOfflineMessage';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, 
		(code, msg) => {
			// 报错也不用管理，只是离线数据
		});
	},
	
	uploadImage(filePath, success, failure)
	{
		let params = {
			filePath : filePath,
		}
		let url = '/im/api/uploadImage';
		ApiRequest.uploadFile(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	uploadVoice(filePath, success, failure)
	{
		let params = {
			filePath : filePath,
		}
		let url = '/im/api/uploadVoice';
		ApiRequest.uploadFile(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	uploadVideo(filePath, success, failure)
	{
		let params = {
			"filePath" : filePath,
		}
		let url = '/im/api/uploadVideo';
		ApiRequest.uploadFile(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	uploadFile(filePath, success, failure)
	{
		let params = {
			filePath : filePath,
		}
		let url = '/im/api/uploadFile';
		ApiRequest.uploadFile(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
}



export default IMApi