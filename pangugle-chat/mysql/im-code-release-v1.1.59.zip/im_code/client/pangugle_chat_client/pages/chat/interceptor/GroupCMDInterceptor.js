import StringUtils from '@/pages/framework/utils/StringUtils.js'

import MessageEvent from "@/pages/chat/logical/MessageEvent.js"

const GroupCMDInterceptor = {
	
	doInputInterceptor(dataJson)
	{
		return true;
	},
	
	doOutputInterceptor(body)
	{
		return true;
	},
	
}

export default GroupCMDInterceptor