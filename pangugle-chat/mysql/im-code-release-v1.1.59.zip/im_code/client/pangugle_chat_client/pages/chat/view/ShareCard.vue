<template>
	
	<view>
		
		<uni-list>
			<uni-list-item 
				v-if="isHasFriend" v-for="(value, key) in contactDataList" :key="key"
				:show-extra-icon="true" 
				:showArrow="false" 
				:thumb="handleFriendAvatar(value)"
				:title="handleFriendTitle(value)" 
				@click="onFriendListClick(value)"/>
		</uni-list>
		
		<sunui-template  v-if="emptySdk.show" :skyContent="emptySdk.showContent" :skyDesc="emptySdk.skyDesc">
		</sunui-template>
		
		<uni-popup class="pg_popup" :show="alertView.show" type="center" :mask-click="false" >
			<view class="title_top">发送给:</view>
			<!-- 发送谁 -->
			<view class="pdLR">
				<view class="top_">
					<!-- 单人 显示头像和名字-->
					<view class="single_people">
						<view>
							<pg-avatar 
								:dataList="receivInfo.avatar">
							</pg-avatar>
							<!-- <image :src="receivInfo.avatar[0]"></image> -->
						</view>
						<text v-if="receivInfo.title !== ''">{{receivInfo.title}}</text>
					</view>
				</view>
				<view class="bot_">
					<!-- 内容 名片 -->
					<view class="con_sg_txt">
						<view>[个人名片]&nbsp;&nbsp;{{cardInfo.title}}</view>
					</view>
				</view>
				
			</view>
			<!-- 按钮 -->
			<view class="btn_bot">
				<view class="cancel" @click="onCloseAlertView()">取消</view>
				<view class="send" @click="onEnterAlertView()">确定</view>
			</view>
		</uni-popup>
		
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import pgFab from "@/components/pg-fab/pg-fab.vue"
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	
	import Pinyin from '../../framework/utils/Pinyin.js'
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	
	/**
	 * 消息转发器
	 */
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem,
			uniPopup,
			pgFab,
			pgAvatar
		},
		data() {
			return {
				isHasFriend : false,
				contactDataList : [],
				
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无好友~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					show : false,
					// 是否显示内容
					showContent: false,
				},
				
				isFromUserBasicInfo : false, // singlechat, groupchat, userbasicinfo主要来源这三个地方
				
				// 发送人信息
				receivInfo : {
					avatar : [],
					title : '',
					targetid : '', // 目标id, 好友则为用户名，群组则为群组id
				},
				// 卡片信息
				cardInfo : {
					title : '',
				},
				
				// 消息体, text|image|card
				messageBody : {},
				
				alertView : {
					show : false,
				},
				
				BasicMsgType : BasicMsgType,
			}
		},
		onLoad(options) {
			let data = JSON.parse(options.data);
			this.messageBody = data;
		},
		onShow() {
			this.emptySdk.show = true;
			FriendCMDManager.setFriendListCallback(this);
			
			if(StringUtils.isEmpty(this.messageBody.targetid))
			{
				// 来自UserBasicInfo, 只需要选择发送人
				this.isFromUserBasicInfo = true;
				
				// 初始化页面内容
				this.cardInfo.title = this.messageBody.data.username;
				if(!StringUtils.isEmpty(this.messageBody.data.nickname))
				{
					this.cardInfo.title = this.messageBody.data.nickname;
				}
				
				FriendCMDManager.refreshFriendList(false, null);
			}
			else if(StringUtils.isEqual(this.messageBody.event, MessageEvent.SINGLE))
			{
				// 来自single chat
				let friendInfo = FriendInfoManager.getFriendInfo(this.messageBody.targetid);
				this.receivInfo.avatar.push(friendInfo.avatar);
				this.receivInfo.title = friendInfo.username;
				if(!StringUtils.isEmpty(friendInfo.alias))
				{
					this.receivInfo.title = friendInfo.alias;
				}
				else if(!StringUtils.isEmpty(friendInfo.nickname))
				{
					this.receivInfo.title = friendInfo.nickname;
				}
				this.receivInfo.targetid = this.messageBody.targetid;
				//console.log(this.receivInfo);
				FriendCMDManager.refreshFriendList(false, null);
			}
			else
			{
				// 初始化发送给谁
				GroupCMDManager.refreshGroupInfo(false, this.messageBody.targetid, (isCache, data) => {
					if(data != null)
					{
						this.receivInfo.avatar = data.iconArray;
						this.receivInfo.title = data.alias;
						if(!StringUtils.isEmpty(data.name))
						{
							this.receivInfo.title = data.name;
						}
						this.receivInfo.targetid = this.messageBody.targetid;
						FriendCMDManager.refreshFriendList(false, null);
					}
				})
				
			}
			
		},
		methods: {
			handleFriendTitle(value) 
			{
				let title = value.username;
				let friendInfo = FriendInfoManager.getFriendInfo(value.username);
				if(!StringUtils.isEmpty(friendInfo.alias))
				{
					title = friendInfo.alias;
				}
				else if(!StringUtils.isEmpty(friendInfo.nickname))
				{
					title = friendInfo.nickname;
				}
				return title;
			},
			handleFriendAvatar(value)
			{
				let title = value.username;
				let friendInfo = FriendInfoManager.getFriendInfo(value.username);
				return friendInfo.avatar;
			},
			handleCardInfo(item)
			{
				this.cardInfo.title = item.username
				if(!StringUtils.isEmpty(item.alias))
				{
					this.cardInfo.title = item.alias;
				}
				else if(!StringUtils.isEmpty(item.nickname))
				{
					this.cardInfo.title = item.nickname;
				}
			},
			/////////////////////////////////////////////////////
			onCloseAlertView()
			{
				this.alertView.show = false;
			},
			onEnterAlertView()
			{
				//console.log("message data : ", this.messageBody);
				
				MessageHelper.sendMessage(this.messageBody);
				uni.navigateBack();
			},
			
			//////////////////////////////////////////////////////
			onFriendListClick(item)
			{
				let that = this;
				//console.log(this.receivInfo);
				// 表示来自UserBaiscInfo页面的信息，发送
				if(this.isFromUserBasicInfo)
				{
					// 初始化页面内容
					let avatarArray = [];
					avatarArray.push(item.avatar)
					this.receivInfo.avatar = avatarArray;
					this.receivInfo.title = item.username
					if(!StringUtils.isEmpty(item.alias))
					{
						this.receivInfo.title = item.alias;
					}
					else if(!StringUtils.isEmpty(item.nickname))
					{
						this.receivInfo.title = item.nickname;
					}
					
					// 处理消息体
					this.messageBody.targetid = item.targetid;
					//console.log(this.receivInfo);
					this.alertView.show = true;
					return;
				}
				else if(StringUtils.isEqual(this.messageBody.event, MessageEvent.SINGLE) || 
						StringUtils.isEqual(this.messageBody.event, MessageEvent.GROUP))
				{
					// 初始化名片信息
					this.handleCardInfo(item);
					
					// 处理消息体
					this.messageBody.data.username = item.username;
					this.messageBody.data.nickname = item.nickname;
					this.messageBody.data.avatar = item.avatar;
				}
				else
				{
					return;
				}
				
				this.$nextTick(function(){
					this.alertView.show = true;
				})
			},
			
			onFriendListCallback(dataList)
			{
				let dataArray = [];
				if(StringUtils.isEqual(BasicMsgType.CARD, this.messageBody.msgType))
				{
					if(this.isFromUserBasicInfo)
					{
						for(let i in dataList)
						{
							let item = dataList[i];
							if(!StringUtils.isEqual(item.username, this.messageBody.data.username))
							{
								dataArray.push(item);
							}
						}
					}
					else
					{
						for(let i in dataList)
						{
							let item = dataList[i];
							if(!StringUtils.isEqual(item.username, this.messageBody.targetid))
							{
								dataArray.push(item);
							}
						}
					}
					
				}
				else
				{
					dataArray = dataList;
				}
				
				this.isHasFriend = dataArray.length > 0
				this.emptySdk.show = !this.isHasFriend;
				this.contactDataList = dataArray;
			},
			onFabClick()
			{
				console.log("");
			}
		}
	}
</script>

<style>
	.pdLR{padding: 0 32upx;width: 500upx;}
	.title_top{
		padding: 20upx 32upx 12upx 32upx;
		color: #000;
		font-size: 36upx;
		text-align: left;
	}
	.top_{
		border-bottom: 1px solid #f2f2f2;
		padding-bottom: 14upx;
	}
	.single_people{
		display: flex;
		flex-direction: row;
		align-items:center;
	}
	.single_people view{height: 70upx;width: 70upx;}
	.single_people image{border-radius: 6upx;}
	.single_people text{
		font-size: 36upx;margin-left: 14upx;
		overflow: hidden;
		white-space: nowrap;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
	}
	
	.bot_{
		padding: 20upx 0;
	}
	.con_img{
		text-align: center;
	}
	.con_img image{
		max-width: 70%;
		max-height: 300upx;
	}
	.con_txt{
		max-height: 100upx;
		min-height: 50upx;
		overflow: hidden;
		text-align: left;
		background-color: #f2f2f2;
		padding: 10upx;
	}
	.con_txt view,.con_sg_txt view{
		font-size: 28upx;
		color: #999;
		line-height: 44upx;
	}
	.con_sg_txt{
		text-align: left;
		height: 40upx;
	}
	.con_sg_txt view{
		overflow: hidden;
		white-space: nowrap;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
	}
	.btn_bot{
		border-top: 1px solid #f2f2f2;
		display: flex;
		justify-content:space-between;
	}
	.btn_bot view{
		width: 50%;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
	}
	.cancel{border-right: 1px solid #f2f2f2;color: #000;}
	.send{color: #657ee0;}
	.single_people{
		
	}
</style>
