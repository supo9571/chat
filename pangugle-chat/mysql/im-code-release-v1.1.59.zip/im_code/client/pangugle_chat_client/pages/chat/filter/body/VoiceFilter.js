// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"

import ChatTextHelper from "@/pages/chat/helper/ChatTextHelper.js"

const TextFilter = {
	
	support(dataJson)
	{
		return StringUtils.isEqual(dataJson.msgType, BasicMsgType.VOICE)
	},
	
	doInputFilter(dataJson, callback)
	{
		callback(dataJson);
	},
	
	doOutputFilter(dataJson)
	{
		let newBodyString = JSON.stringify(dataJson);
		let newBody = JSON.parse(newBodyString);
		delete newBody['local'];
		
		return newBody;
	}
	
}

export default TextFilter