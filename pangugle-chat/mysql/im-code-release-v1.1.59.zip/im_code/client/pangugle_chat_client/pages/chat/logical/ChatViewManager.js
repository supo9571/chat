
// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import CachePolicy from '@/pages/framework/http/CachePolicy.js'
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import EmotionUtils from "@/pages/framework/utils/EmotionUtils.js"

// user
import UserApi from '@/pages/user/service/UserApi.js'
import UserManager from '@/pages/user/logical/UserManager.js'
import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'

// chat
import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
import ChatTextHelper from "@/pages/chat/helper/ChatTextHelper.js"
import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import ChatTimeHelper from "@/pages/chat/helper/ChatTimeHelper.js"
import SingleChatManager from "@/pages/chat/logical/handler/SingleChatManager.js"
import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"


import IMApi from "@/pages/chat/service/IMApi.js"
import FriendApi from "@/pages/chat/service/FriendApi.js"
	
/**
 * 在vue页面有相同聊天功能，都放在这里，不需要到处写
 */
const ChatViewManager = {
	
	///////////////////////////// send message /////////////////
	sendText(targetid, event, content, atUserArray = null)
	{
		try{
			content = content.trim();
			if(StringUtils.isEmpty(content))
			{
				return;
			}
			let showText = ChatTextHelper.richText(content);
			MessageHelper.sendText(targetid, event, content, showText, atUserArray);
		}catch(e){
			console.log(e);
		}
	},
	
	/**
	 * 发送图片消息
	 * @param {Object} filePaths
	 * @param {Object} uploadIndex
	 */
	sendImageMessage(targetid, event, filePaths, uploadIndex)
	{
		let self = this;
		let len = filePaths.length;
		if(len - 1 < uploadIndex)
		{
			//console.log("发送完成")
			return;
		}
		let currentPath = filePaths[uploadIndex];
		IMApi.uploadImage(currentPath, (data) => 
		{
			uni.getImageInfo({
				src:currentPath,
				success(imgInfo) {
					let width = imgInfo.width;
					let height = imgInfo.height;
					let maxW = uni.upx2px(350);//350是定义消息图片最大宽度
					let maxH = uni.upx2px(350);//350是定义消息图片最大高度
					if(width > maxW || height > maxH){
						let scale = width / height;
						width = scale>1?maxW:maxH*scale;
						height = scale>1?maxW/scale:maxH;
					}
					// 发送消息
					let srcURL = data.src_path;
					let compressURL = data.compress_path;
					if(StringUtils.isEmpty(compressURL))
					{
						compressURL = srcURL;
					}
					MessageHelper.sendImage(targetid, event, srcURL, compressURL, width, height);
				},
				complete() {
					self.sendImageMessage(targetid, event, filePaths, uploadIndex + 1);
				}
			})
		}, 
		(code, msg) =>
		{
			console.log("upload failure : ", msg);
			// 上传失败，但还是上传下一个
			self.sendImageMessage(filePaths, uploadIndex + 1);
		});
	},
	
	/**
	 * 发送图片消息
	 * @param {Object} filePaths
	 * @param {Object} uploadIndex
	 */
	sendVideoMessage(targetid, event, filePath, width, height)
	{
		let self = this;
		IMApi.uploadVideo(filePath, (data) => 
		{
			console.log(data);
			return;
			let width = imgInfo.width;
			let height = imgInfo.height;
			let maxW = uni.upx2px(350);//350是定义消息图片最大宽度
			let maxH = uni.upx2px(350);//350是定义消息图片最大高度
			if(width > maxW || height > maxH){
				let scale = width / height;
				width = scale>1?maxW:maxH*scale;
				height = scale>1?maxW/scale:maxH;
			}
			// 发送消息
			let srcURL = data.src_path;
			let compressURL = data.compress_path;
			if(StringUtils.isEmpty(compressURL))
			{
				compressURL = srcURL;
			}
			MessageHelper.sendImage(targetid, event, srcURL, compressURL, width, height);
		}, 
		(code, msg) =>
		{
			console.log("upload failure : ", msg);
			
		});
	},
	
	////////////////////////////////// do ///////////////
	doChooseImage(type, targetid, event)
	{
		let self = this;
		uni.chooseImage({
			sourceType:[type],
			sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
			success: (res)=>{
				let filePaths = res.tempFilePaths;
				self.sendImageMessage(targetid, event, filePaths, 0);
			}
		});
	},
	
	doChooseVideo(targetid, event)
	{
		let self = this;
		uni.chooseVideo({
			count: 1,
			maxDuration: 10,
			compressed: true,
			sourceType: ['camera', 'album'],
			success: function (res) {
				self.sendVideoMessage(targetid, event, res.tempFilePath, res.width, res.height);
			}
		});
	},
	
	doShowPicture(item, msgList)
	{
		let myImgList = [];
		for(let index in msgList)
		{
			let model = msgList[index];
			if(StringUtils.isEqual(BasicMsgType.IMAGE, model.msgType))
			{
				myImgList.push(model.data.src_url);
			}
		}
		uni.previewImage({
			indicator:"none",
			current:item.data.src_url,
			urls: myImgList
		});
	},
	
	////////////////////////////// handle item value
	handleRevokeMessage(value)
	{
		if(ProtocolHelper.isSelfProtocol(value))
		{
			return "你撤回了一条消息!";
		}
		else
		{
			return "对方撤回了一条消息!";
		}
	},
	
}

export default ChatViewManager