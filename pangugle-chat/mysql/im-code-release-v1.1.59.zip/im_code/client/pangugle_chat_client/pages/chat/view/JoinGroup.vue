<template>
	<view>
		
		<view class="box">
			<view class="pho">
				<pg-avatar :length="mGroupInfo.iconArray.length" :dataList="mGroupInfo.iconArray"> </pg-avatar>
			</view>
			<view class="p">{{getName()}}</view>
		</view>
		 <button class="btn" @click="doJoinGroup()">加入该群聊</button>
	</view>
</template>

<script>


import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
import GroupApi from "@/pages/chat/service/GroupApi.js"
import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	
import JsonUtils from "@/pages/framework/utils/JsonUtils.js"
	
export default {
	components:{
		pgAvatar
	},
	data() {
		return {
			mGroupInfo : {
				groupid : '',
				alias : '',
				groupName : '',
				icon : '',
				iconArray : [],
				createUsername : '',
				time : '',
				sign : '',
			},
			// signGroupInfo : {
			// 	groupid : '',
			// 	alias : '',
			// 	groupName : '',
			// 	icon : '',
			// 	iconArray : [],
			// 	createUsername : '',
			// 	time : '',
			// 	sign : '',
			// }
		}
	},
	
	onLoad(options) {
		var data = decodeURIComponent(options.data);
		
		var gorupInfo = JsonUtils.parseJson(data);
		
		//console.log("================", gorupInfo);
		
		var avatarArray = gorupInfo.icon.split(",");
		gorupInfo.iconArray = avatarArray;
		
		this.mGroupInfo = gorupInfo;
		// console.log("================", this.signGroupInfo);
	},
	
	methods: {
		
		getName()
		{
			var title = this.mGroupInfo.groupName;
			if(!title)
			{
				title = this.mGroupInfo.alias;
			}
			return title;
		},
		
		doJoinGroup()
		{
			var groupid = this.mGroupInfo.groupid;
			var data = {
				"groupid" : this.mGroupInfo.groupid,
				"createUsername" : this.mGroupInfo.createUsername,
				"time" : this.mGroupInfo.time,
				"sign" : this.mGroupInfo.sign,
			}
			GroupApi.joinGroup(data, () => {
				GroupCMDManager.refreshUserGroup(true, (isCache, dataList) => {
					if(!isCache)
					{
						ChatJumpHelper.jumpToGroupChat(groupid, true);
					}
				})
			})
			
		}
	}
	
	
	
}
	
</script>

<style scoped>
	.box{
		background-color: #fff;
		display: flex;
		flex-direction:column;
		text-align: center;
		padding: 20px 50px;
		border-bottom: 1px solid #f2f2f2;
		
	}
	.pho{
		width: 50px;
		height: 50px;
		margin: 0 auto;
		background-color: #f2f2f2;
	}
	.pho view{width: 100%;height: 100%;}
	.p{
		font-size: 15px;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
		margin-top: 5px;
	}
	.sp{
		font-size: 12px;
		color: #CCCCCC;
	}
	.btn{
		background-color: #09BB07;
		width: 70%;
		margin: 50px auto 0 auto;
		color: #fff;
	}
</style>
