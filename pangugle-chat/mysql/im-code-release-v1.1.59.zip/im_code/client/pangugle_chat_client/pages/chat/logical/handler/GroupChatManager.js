// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ConversationManager from '@/pages/chat/logical/ConversationManager.js'
import LocalPushHelper from "@/pages/chat/helper/LocalPushHelper.js"

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js" 

import RecordManager from "@/pages/chat/logical/RecordManager.js"
import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import GroupChatInterceptor from "@/pages/chat/interceptor/GroupChatInterceptor"

import UserManager from '@/pages/user/logical/UserManager.js'

const EVENT_NAME = MessageEvent.GROUP;


const mRecordManager = new RecordManager(EVENT_NAME);

/**
 * 群聊
 */
const  GroupChatManager = {
	
	getInterceptor()
	{
		return GroupChatInterceptor;
	},
	
	getEvent()
	{
		return EVENT_NAME;
	},
	
	onStart()
	{
		this.mGroupid = '';
		ConversationManager.registerChatHandler(EVENT_NAME, this);
		this.mIsActive = false;
	},
	
	isActive()
	{
		return this.mIsActive;
	},
	
	setActive(active)
	{
		this.mIsActive = active;
	},
	
	/**
	 * 删除消息, 一个消息
	 * @param {Object} dataJson
	 */
	deleteMessage(dataJson)
	{
		let dataArray = mRecordManager.deleteRecordItem(dataJson);
		//console.log(dataArray);
		if(this.mUICallback != null)
		{
			this.mUICallback.onReceivedMessage(dataArray);
		}
	},
	
	/**
	 * 删除一个用户的所有消息, 每个消息处理器都要实现这个类
	 * @param {Object} event
	 * @param {Object} fromUserid
	 * @param {Object} targetid
	 */
	deleteMessageList: function(event, fromUserid, targetid)
	{
		//console.log("deleteMessageList = " + event, fromUserid + ", " + targetid);
		mRecordManager.deleteRecordList(event, fromUserid, targetid);
	},
	
	/*
	constructor() {
	    this.mRecordManager = new RecordManager('single');
		this.mUICallback = null;
	}*/
	/**
	 * @param {Object} dataJson
	 * @param {Object} msgOptStatus new|resend
	 */
	onReceivMessage(dataJson)
	{
		//console.log("receiv group chat : ", dataJson);
		
		let that = this;
		
		//console.log("receiv single chat : ", dataJson);
		let msgType = dataJson.msgType;
		let fromUserid = dataJson.fromUserid;
		let targetid = dataJson.targetid;
		// 消息操作状态
		let optType = dataJson.optType;
		
		// 不是好友关系的消息不能处理，非法消息
		let selfUsername = UserManager.getUserInfo().username;
		// 其他人发送的
		if(!StringUtils.isEqual(selfUsername, fromUserid))
		{
			// 验证是不是群成员,不是则直接丢弃消息
			// if(!GroupCMDManager.isJoinGroup(targetid))
			// {
			// 	return;
			// }
			// 获取发送人信息
			FriendInfoManager.refreshFriendInfo(false, fromUserid, (data) => {
				// 获取群与此人的关系
				GroupCMDManager.refreshGroupRelation(false, targetid, fromUserid, (data) => {
					that.handleMessageAndUpdateUI(dataJson, false);
				});
				
			}, null);
		}
		else
		{
			// 自己发送的
			that.handleMessageAndUpdateUI(dataJson, true);
		}
		
	},
	
	handleMessageAndUpdateUI(dataJson, isSelfSend)
	{
		let msgType = dataJson.msgType;
		let fromUserid = dataJson.fromUserid;
		let targetid = dataJson.targetid;
		// 消息操作状态
		let optType = dataJson.optType;
		
		// 消息重新发送
		if(StringUtils.isEqual(optType, 'resend'))
		{
			let dataArray = mRecordManager.updateRecordItem(dataJson);
			if(this.mUICallback != null)
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
		}
		// 刷新消息发送失败状态
		else if(StringUtils.isEqual(optType, 'refresh_status'))
		{
			let dataArray = mRecordManager.updateRecordItem(dataJson);
			if(this.mUICallback != null)
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
		}
		// 消息撤回
		else if(BasicMsgType.REVOKE == msgType)
		{
			let dataArray = mRecordManager.updateRecordItem(dataJson);
			if(this.mUICallback != null)
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
			
			let addBadge = !this.mIsActive;
			ConversationManager.handle(dataJson, addBadge);
		}
		// 需要保存聊天记录的
		else if(BasicMsgType.TEXT == msgType ||
			BasicMsgType.IMAGE == msgType ||
			BasicMsgType.VOICE == msgType ||
			BasicMsgType.FILE == msgType ||
			BasicMsgType.SHOURT_VIDEO == msgType ||
			BasicMsgType.POSITION == msgType ||
			BasicMsgType.CARD == msgType ||
			BasicMsgType.RED_PACKET == msgType ||
			// 以下是local msg type
			StringUtils.isEqual(LocalMsgType.REJECT, msgType) || 
			StringUtils.isEqual(LocalMsgType.VERIFY_FRIEND, msgType) || 
			StringUtils.isEqual(LocalMsgType.TEXT, msgType)
			)
		{
			// 保存聊天记录
			var dataArray = mRecordManager.addRecord(dataJson);
			//
			if(this.mUICallback != null && StringUtils.isEqual(targetid, this.mGroupid))
			{
				this.mUICallback.onReceivedMessage(dataArray);
			}
			
			var addBadge = true;
			// 自己发送的，或着当前会话id == 远程过来消息targetid
			if(isSelfSend || (this.mIsActive && this.mGroupid == targetid))
			{
				addBadge = false;
			}
			
			//console.log("addBadge  status = " + addBadge);
			
			// 更新会话信息
			ConversationManager.handle(dataJson, addBadge);
			
			// 处理本地推送消息
			LocalPushHelper.sendNotify(dataJson);
		}
		else if(BasicMsgType.SHARE_POSITION_UPDATE == msgType)
		{
			// 实时位置信息
		}
	},
	
	reload(fromUserid, targetid)
	{
		let dataArray = mRecordManager.getDataArray(EVENT_NAME, fromUserid, targetid);
		//console.log("aaaaaaaaaaa", dataArray);
		if(this.mUICallback != null)
		{
			this.mUICallback.onReceivedMessage(dataArray);
		}
	},
	
	setUICallback(callback, groupid)
	{
		this.mUICallback = callback;
		this.mGroupid = groupid;
		mRecordManager.setCurrentTargetid(groupid);
	}
}

export default GroupChatManager