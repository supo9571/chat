<template>
	<view class="uni-common-mt">
		<view class="uni-form-item uni-column">
			<!-- <checkbox-group class="uni-list" >
				<label class="uni-list-cell uni-list-cell-pd" >
					
					 <view>
						<uni-icon type="search" color="#007aff" size="25"/>
					</view>
					<view class="aa">
						<input class="uni-input" placeholder-style="color:#999" confirm-type="search" placeholder="用户名" @confirm="searchFriendInfo" />
					</view> 
				</label>
			</checkbox-group> -->
			<view class="search_group">
				<input class="uni-input" v-model="inputUsername" placeholder-style="color:#999" placeholder="用户名" />
				<view class="btn_search" @click="searchFriendInfo()">搜索</view>
			</view>
			<!-- <view class="btn_search">立即查找</view> -->
		</view>
		
		
		<!-- <view class="search">
			<uni-icon type="search" color="#007aff" size="25"/>
			<input class="uni-input" placeholder-style="color:#999" confirm-type="search" placeholder="用户名" @confirm="searchFriendInfo" />
		</view> -->
		<!--
		<view class="no_exist">该用户不存在</view>
		-->
	</view>
</template>

<script>
	
	import uniIcon from '@/components/uni-icons/uni-icons.vue'
	import RegexUtils from "@/pages/framework/utils/RegexUtils.js"
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserManager from '@/pages/user/logical/UserManager.js'
	
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	
	export default {
		data() {
			return {
				inputUsername : '',
			}
		},
		components:{
			uniIcon
		},
		
		methods:{
			searchFriendInfo()
			{
				let input = this.inputUsername;
				if(StringUtils.isEmpty(input)){
					return;
				}
				
				// verify params
				if(!RegexUtils.isLetterDigit(input))
				{
					ToastUtils.showText("只能是数字或字母!")
					return;
				}
				let len = input.length;
				if(len <= 5 || len > 20)
				{
					ToastUtils.showText("长度只能大于5且小于等于20个字符!")
					return;
				}
				
				// verify self
				let selfUsername = UserManager.getUserInfo().username;
				if(StringUtils.isEqual(selfUsername, input))
				{
					// 用户自己
					ToastUtils.showFailure("无法添加自己为好友!")
					return;
				}
				
				// 
				uni.hideKeyboard();
				
				FriendInfoManager.refreshFriendInfo(false, input, (friendInfo) =>
				{
					let username = friendInfo.username;
					ChatJumpHelper.jumpToUserBasicInfo(username);
				}, null);
				
				//
				// UserApi.searchUserInfo(input, false, data => 
				// {
				// 	let username = data.username;
					
				// 	ChatJumpHelper.jumpToUserBasicInfo(username);
				// });
				
			}
		}
	}
</script>
	
<style>
	/* .search{
		background-color: #fff;
		padding: 20upx 30upx;
	    display: flex;
	    -webkit-box-orient: horizontal;
	    -webkit-box-direction: normal;
	    -webkit-flex-direction: row;
	    -ms-flex-direction: row;
	    flex-direction: row;
	    -webkit-box-pack: justify;
	    -webkit-justify-content: space-between;
	    -ms-flex-pack: justify;
	    justify-content: space-between;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    -ms-flex-align: center;
	    align-items: center;
	
	}
	.search uni-icon{}*/
	/* .uni-input{
		height: 35px!important;
		line-height: 15px!important;
		width: 100%;
		font-size: 17px!important;
		text-align: left;
		padding: 0 21px!important;
	} */
	.no_exist{height: 80px;line-height: 80px;text-align: center;color: #999;
		background-color: #fff;margin-top: 10px;
	}
	.uni-list-cell {
		justify-content: flex-start
	}
	.uni-list-cell-pd {
	    padding: 0px 15px!important;
	}
	.uni-common-mt{margin-top: 0;}
	.search_group{
		display: flex;
		flex-direction: row;
		align-items:center;
		background-color: #fff;
	}
	.uni-input{
		display: flex;
		flex: 1;
		
	}

	.btn_search{
		width: 60px;
		height: 60px;
		line-height: 60px;
		/* color:#fff; */
		/* background-color: #0e90d2; */
		text-align: center;
		font-size: 16px;
		/* line-height: 35px; */
		/* height: 35px; */
		/* margin-right: 10px; */
		
	}
</style>
