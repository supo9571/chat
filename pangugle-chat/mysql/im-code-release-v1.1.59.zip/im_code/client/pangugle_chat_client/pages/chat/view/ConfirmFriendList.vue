<template>
	<view>
		<!--
		<view class="uni-list">
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" >
				<view class="uni-media-list">
					<view class="uni-media-list-logo">
						<image src="https://ossweb-img.qq.com/images/lol/web201310/skin/big21004.jpg"></image>
					</view>
					<view class="uni-media-list-body">
						<view class="uni-media-list-text-top" >张三</view>
						<view class="uni-media-list-text-bottom uni-ellipsis" >我是你老板啊,快回来上班，给你升职加薪！</view>
					</view>
					<view class="uni-media-list-right" @click="showPopup">
						<text>操作</text>
					</view>
				</view>
			</view>
			
		</view>
		-->
		<view class="uni-list" v-if="!showEmptyView">
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" v-for="(value,key) in list" :key="key">
				<view class="uni-media-list">
					<view class="uni-media-list-logo">
						<!--
						<an-image :src="value.img" alt="https://andot.org/images/default.png" mode="center"></an-image>
						-->
						<pg-image-cache :imgSrc="value.avatar" alt=""></pg-image-cache>
					</view>
					<view class="uni-media-list-body">
						<view class="uni-media-list-text-top" v-if="value.nickname">{{value.nickname}}</view>
						<view class="uni-media-list-text-top" v-else>{{value.username}}</view>
						<view class="uni-media-list-text-bottom uni-ellipsis" v-if="value.remark">{{value.remark}}</view>
						<view class="uni-media-list-text-bottom uni-ellipsis" v-else>我是{{value.nickname}}</view>
					</view>
					<view class="uni-media-list-right" @tap="openActionSheet(value)">
						<text>立即处理</text>
					</view>
				</view>
			</view>
		</view>
		
		<sunui-template :skyContent="skyContent" :skyDesc="skyDesc" v-if="showEmptyView">
		</sunui-template>
		
		<pg-actionsheet
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.itemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
		
	</view>
	
</template>

<script>
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	
	// framework
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	
	import FriendApi from "@/pages/chat/service/FriendApi.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	
	export default {
		
		components: {
			"pg-actionsheet" : actionSheet,
		},
		
		data() {
			return {
				// 是否显示内容
				skyContent: false,
				skyDesc: {
					// 是否显示返回
					// isBack:true,
					// 是否显示加载(加载和返回不建议同时显示)
					// isLoad: true,
					// 页面背景颜色
					bgColor: '#eee',
					// 为空格则不显示该文字
					Desc: '暂无数据~!',
					// 字体以及字体图标颜色
					iconColor: '#000000',
					// 字体图标(可更改iconfont.css，进行覆盖)
					iconName: 'icon-icon-test',
					// 返回按钮颜色/重新按钮颜色,加载字体默认白色
					// btnColor:'#ff0000',
					// 页面高度
					height: '100%',
					// 页面宽度
					width: '100%',
					// 字体图标大小
					fontSize: '5em'
				},
				
				showEmptyView: true,
				searchVal: '',
				list: [],
				
				selectDataModel : {},
				
				actionSheet : {
					optValue : {},
					show: false,
					maskClosable: true,
					tips: "",
					itemList: [
						{text: "通过",color: "#1a1a1a"},
						{text: "拒绝",color: "#1a1a1a"},
					],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
			}
		},
		
		onShow() {
			//console.log("onLoad confirm");
			FriendCMDManager.setUnconfirmListCallback(this);
			FriendCMDManager.refreshUnconfirmList(false, null);
		},
		
		onNavigationBarButtonTap(res) {
			let index = res.index;
			//console.log(index);
			uni.navigateTo({
				url: './SearchUser'
			})
		},
		
		methods:{
			enableFriend()
			{
				//console.log("fasdf");
				ToastUtils.showLoading();
				let model = this.actionSheet.optValue;
				let fromUsername = model.username;
				FriendApi.enableFriend(fromUsername, () => {
					FriendCMDManager.refreshAll(true);
				}, (code, msg) => {
					if(code == -16)
					{
						FriendCMDManager.refreshAll(true);
					}
					else
					{
						ToastUtils.showText(msg);
					}
				});
			},
			disableFriend()
			{
				ToastUtils.showLoading();
				let model = this.actionSheet.optValue;
				FriendApi.deleteFriend(model.username, () => {
					FriendCMDManager.refreshAll(true);
				}, null);
			},
			openActionSheet(value){
				this.actionSheet.optValue = value;
				this.actionSheet.show = true;
			},
			closeActionSheet: function() {
				this.actionSheet.optValue = '';
				this.actionSheet.show = false
			},
			onActionSheetItemClick(e) {
				let index = e.index;
				let itemTextValue = this.actionSheet.itemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '通过'))
				{
					this.enableFriend();
				}
				else if(StringUtils.isEqual(itemTextValue, '拒绝'))
				{
					this.disableFriend();
				}
				this.closeActionSheet();
			},
			//
			onUnconfirmListCallback(dataList)
			{
				this.list = dataList;
				this.showEmptyView = dataList.length == 0;
				//console.log(dataList[0]);
			},
		}
	}
</script>

<style>
	.uni-media-list-logo image{border-radius: 2px;}
	.uni-media-list-right{
		display: flex;
		align-items:center;
	}
	.uni-media-list-right text{width: 65px;height: 25px;color: #fff;line-height: 25px;
	background-color: #1AAD19;display: inline-block;text-align: center;
		border-radius: 3px;
	}
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	
	.logo {
		height: 100px;
		width: 100px;
		margin-top: 100px;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 25px;
	}
	
	.text-area {
		display: flex;
		justify-content: center;
	}
	
	.title {
		font-size: 18px;
		color: #8f8f94;
	}
	.foot{margin-top: 10px;text-align: center;background-color: #fff;padding: 0 12px;}
	.foot view{line-height: 50px;font-size: 17px;color: #007aff;border-bottom: 1px solid #e5e5e5;}
	.foot view:nth-last-child(1){border-bottom: none;}
</style>
