<template>
	<view>
		
		<uni-list>
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" @click="jumpToModifyGroupInfo()">
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="pg_list_cell_left">群聊名称</text>
					  <view class="pg_list_cell_right uni-ellipsis">
						  <text class="">{{handleTile()}}</text>
					  </view>
				  </view>
			 </view>
			<view v-if="isHolder || groupInfo.enableInvite" class="uni-list-cell" hover-class="uni-list-cell-hover" @click="jumpToGroupCreateQrcode()">
			  <view class="uni-list-cell-navigate uni-navigate-right">
				  <text>群二维码</text>
				  <view class="">
					  <!-- <image class="qrcode" src="/static/pg_def_qrcode.png"></image> -->
				  </view>
			  </view>
			</view>
			<!-- <view class="uni-list-cell" hover-class="uni-list-cell-hover" >
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="pg_list_cell_left">群公告</text>
					  <view class="pg_list_cell_right uni-ellipsis">
						  <text class="">{{handleNotice()}}</text>
					  </view>
				  </view>
			</view> -->
			<view v-if="isHolder"
				class="uni-list-cell" hover-class="uni-list-cell-hover"
				@click="openActionsheet(optType.group_invite_enter)">
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="pg_list_cell_left">群聊邀请确认</text>
					  <view class="pg_list_cell_right uni-ellipsis">
						  <text v-if="groupInfo.enableInvite" class="">关闭</text>
						  <text v-else class="">开启</text>
					  </view>
				  </view>
			</view>
			<view v-if="isHolder"
				class="uni-list-cell" hover-class="uni-list-cell-hover"
				@click="openActionsheet(optType.group_add_friend)">
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="pg_list_cell_left">禁止群成员加好友</text>
					  <view class="pg_list_cell_right uni-ellipsis">
						  <text v-if="groupInfo.enableAddFriend == true" class="">关闭</text>
						  <text v-else class="">开启</text>
					  </view>
				  </view>
			</view>
			<view v-if="isHolder"
				class="uni-list-cell" hover-class="uni-list-cell-hover"
				@click="openActionsheet(optType.group_enable_chat)">
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="pg_list_cell_left">全员禁言</text>
					  <view class="pg_list_cell_right uni-ellipsis">
						  <text v-if="groupInfo.enableChat" class="">关闭</text>
						  <text v-else class="">开启</text>
					  </view>
				  </view>
			</view>
			<!--
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" >
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="">群主管理员转让</text>
				  </view>
			</view> -->
		</uni-list>
		
		
		<uni-list>
			<!-- 
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" >
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="">我在本群的昵称</text>
					  <view class=" uni-ellipsis">
						  <text class="">王五</text>
					  </view>
				  </view>
			 </view>-->
			<!-- 
			 <view class="uni-list-cell" hover-class="uni-list-cell-hover" >
			 	  <view class="uni-list-cell-navigate uni-navigate-right">
			 		  <text class="">消息免打扰</text>
			 		  <view class=" uni-ellipsis">
			 			  <text class="">开启</text>
			 		  </view>
			 	  </view>
			  </view>-->
			<!-- <view class="uni-list-cell" hover-class="uni-list-cell-hover" @click="openActionsheet(optType.group_member_mgr)">
				<view class="uni-list-cell-navigate uni-navigate-right">
					<text class="pg_list_cell_left">群成员管理</text>
				</view>
			</view> -->
			<view v-if="isHolder || mIsAdmin || groupInfo.enableInvite"
				class="uni-list-cell" hover-class="uni-list-cell-hover"
				@click="jumpToGroupMemberAdd()">
				<view class="uni-list-cell-navigate uni-navigate-right">
					<text class="pg_list_cell_left">邀请新成员</text>
				</view>
			</view>
			<view v-if="isHolder || mIsAdmin" class="uni-list-cell" hover-class="uni-list-cell-hover"
				@click="jumpToGroupMemberRemove()">
				<view class="uni-list-cell-navigate uni-navigate-right">
					<text class="pg_list_cell_left">移除群成员</text>
				</view>
			</view>
			<view class="uni-list-cell" hover-class="uni-list-cell-hover"
				@click="jumpToGroupMemberList()">
				<view class="uni-list-cell-navigate uni-navigate-right">
					<text class="pg_list_cell_left">查看群成员</text>
				</view>
			</view>
		</uni-list>
		
		<view class="bot_opt">
			<view @click="showAlertView('clear_chat_record')">清空聊天记录</view>
			<view @click="showAlertView('delete_group')" v-if="isHolder" >解散群组</view>
			<view @click="showAlertView('delete_group')" v-else>删除并退出</view>
		</view>
		
		<pg-actionsheet
		 	:show="actionSheet.show" 
		 	:tips="actionSheet.tips" 
		 	:item-list="actionSheet.itemList" 
		 	:mask-closable="actionSheet.maskClosable"
		 	:color="actionSheet.color" 
		 	:size="actionSheet.size" 
		 	:is-cancel="actionSheet.isCancel" 
		 	@click="onActionSheetItemClick" 
		 	@cancel="closeActionSheet">
		</pg-actionsheet>
		
		<pg-modal :show="mAlertView.show"
			@click="onClickAlertView" title="" 
			:content="mAlertView.content">
		</pg-modal>
	</view>
</template>

<script>
	
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import pgmodal from "@/components/pg-modal/modal.vue"
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	import GroupChatManager from "@/pages/chat/logical/handler/GroupChatManager.js"
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import ConversationManager from "@/pages/chat/logical/ConversationManager.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import GroupApi from "@/pages/chat/service/GroupApi.js"
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	import JumpManager from "@/pages/main/logical/JumpManager.js"
	
	export default {
		components: {
			uniList,
			uniListItem,
			"pg-actionsheet" : actionSheet,
			'pg-modal' : pgmodal,
		},
		data() {
			return {
				actionSheet : {
					optValue : {},
					show: false,
					maskClosable: true,
					tips: "",
					itemList: null,
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
				
				optType : {
					currentStatus : '',
					group_member_mgr : 'group_member_mgr', //群成员管理
					group_invite_enter : 'group_invite_enter', // 群邀请确认
					group_add_friend : 'group_add_friend', // 群邀请确认
					group_enable_chat : 'group_enable_chat', // 群邀请确认
				},
				
				groupInfo : {
					id : '',
					name : '',
					enableInvite : false,
					enableAddFriend : true,
					holder : '', // 群主
				},
				// 群管理员列表
				mAdminList : [],
				
				jumpToMemberType : {
					list : 'list',
					remove : 'remove',
					add : 'add'
				},
				
				isHolder : false, // 是否是群主本人进入此页面
				mIsAdmin : false, // 是否为管理员
				
				mAlertView: {
					show : false,
					content : '',
					optType : ''
				},
			}
		},
		onLoad(options)
		{
			let groupid = options.groupid;
			this.groupInfo.id = groupid;
		},
		onShow(){
			this.loadGroupInfo(false);
		},
		onPullDownRefresh(e) {
			this.loadGroupInfo(true);
		},
		methods : {
			handleTile()
			{
				if(!StringUtils.isEmpty(this.groupInfo.name))
				{
					return this.groupInfo.name;
				}
				else
				{
					return this.groupInfo.alias;
				}
			},
			handleNotice()
			{
				if(StringUtils.isEmpty(this.groupInfo.notice))
				{
					return "未设置";
				}
				else
				{
					return this.groupInfo.notice;
				}
			},
			//////////////////////////////////
			showAlertView(type)
			{
				this.mAlertView.show = true;
				this.mAlertView.optType = type;
				if(StringUtils.isEqual(type, "clear_chat_record"))
				{
					this.mAlertView.content = "确定删除聊天记录?";
				}
				else
				{
					if(this.isHolder)
					{
						this.mAlertView.content = "确定解散群组吗?";
					}
					else
					{
						this.mAlertView.content = "确定删除并退出吗?";
					}
					
				}
			},
			onClickAlertView(event)
			{
				let that = this;
				this.mAlertView.show = false;
				if(event.index == 0)
				{
					return;
				}
				
				if(StringUtils.isEqual(this.mAlertView.optType, "clear_chat_record"))
				{
					GroupChatManager.deleteMessageList(MessageEvent.GROUP, '', this.groupInfo.id);
					ToastUtils.showSuccess("删除成功")
				}
				else
				{
					ToastUtils.showLoading();
					GroupApi.deleteGroup(this.groupInfo.id, (data) => 
					{
						ToastUtils.showLoading();
						
						// 删除相关信息
						ConversationManager.removeItemWithID(MessageEvent.GROUP, '', that.groupInfo.id);
						GroupCMDManager.refreshUserGroup(true, (isCache, dataList) => {
							ToastUtils.hideLoading();
							if(that.isHolder)
							{
								ToastUtils.showSuccess("解散成功!")
							}
							else
							{
								ToastUtils.showSuccess("退出成功!")
							}
							JumpManager.jumpToHome();
						})
					}, null);
				}
			},
			
			//////////////////////////////////
			jumpToGroupCreateQrcode()
			{
				ChatJumpHelper.jumpToCreateGroupQrcode(this.groupInfo.id);
			},
			jumpToGroupMemberList()
			{
				ChatJumpHelper.jumpToGroupMemberList(this.groupInfo.id);
			},
			jumpToGroupMemberAdd()
			{
				ChatJumpHelper.jumpToGroupMemberAdd(this.groupInfo.id);
			},
			jumpToGroupMemberRemove()
			{
				ChatJumpHelper.jumpToGroupMemberRemove(this.groupInfo.id);
			},
			jumpToModifyGroupInfo()
			{
				if(this.isHolder)
				{
					// 群主才能操作
					ChatJumpHelper.jumpToModifyGroupInfo(this.groupInfo.id, 'modify_group_name');
				}
				
			},
			//////////////////////////////
			loadGroupInfo(reload)
			{
				var selfUsername = UserManager.getUserInfo().username;
				var that = this;
				GroupCMDManager.refreshGroupInfo(reload, that.groupInfo.id, (isCache, groupInfo) => {
					//console.log("groupInfo ============== ", groupInfo.enableChat);
					
					that.groupInfo = groupInfo;
					
					this.mAdminList = GroupCMDManager.getAdminList(that.groupInfo.id);
					this.mIsAdmin = this.isAdmin(selfUsername)
					
					//console.log("isCache = " + isCache, groupInfo);
					let userInfo = UserManager.getUserInfo();
					that.isHolder = StringUtils.isEqual(userInfo.username, groupInfo.holder);
					
					uni.stopPullDownRefresh();
				});
			},
			openActionsheet(type)
			{
				let dataItems = [];
				if(StringUtils.isEqual(type, this.optType.group_member_mgr))
				{
					dataItems.push({text: "移出群成员",color: "#1a1a1a"});
					dataItems.push({text: "邀请好友加入",color: "#1a1a1a"})
					this.actionSheet.itemList = dataItems;
					this.optType.currentStatus = this.optType.group_member_mgr;
				}
				else if(StringUtils.isEqual(type, this.optType.group_invite_enter))
				{
					if(this.groupInfo.enableInvite)
					{
						this.actionSheet.tips = '确定开启群聊邀请?';
						dataItems.push({text: "开启",color: "#1a1a1a"});
					}
					else
					{
						this.actionSheet.tips = '确定关闭群聊邀请?';
						dataItems.push({text: "关闭",color: "#1a1a1a"});
					}
					
					this.actionSheet.itemList = dataItems;
					this.optType.currentStatus = this.optType.group_invite_enter;
				}
				else if(StringUtils.isEqual(type, this.optType.group_add_friend))
				{
					if(this.groupInfo.enableAddFriend)
					{
						this.actionSheet.tips = '确定禁止群成员添加为好友?';
						dataItems.push({text: "开启",color: "#1a1a1a"});
					}
					else
					{
						this.actionSheet.tips = '确定允许群成员添加为好友?';
						dataItems.push({text: "关闭",color: "#1a1a1a"});
					}
					
					this.actionSheet.itemList = dataItems;
					this.optType.currentStatus = this.optType.group_add_friend;
				}
				else if(StringUtils.isEqual(type, this.optType.group_enable_chat))
				{
					if(this.groupInfo.enableChat)
					{
						this.actionSheet.tips = '确定开启禁言吗?';
						dataItems.push({text: "开启",color: "#1a1a1a"});
					}
					else
					{
						this.actionSheet.tips = '确定关闭禁言吗?';
						dataItems.push({text: "关闭",color: "#1a1a1a"});
					}
					
					this.actionSheet.itemList = dataItems;
					this.optType.currentStatus = this.optType.group_enable_chat;
				}
				this.actionSheet.show = true;
			},
			
			closeActionSheet: function() {
				this.actionSheet.show = false
				this.actionSheet.tips = '';
				this.actionSheet.itemList = null;
			},
			onActionSheetItemClick(e) {
				let index = e.index;
				let itemTextValue = this.actionSheet.itemList[index].text;
				
				let type = this.optType.currentStatus;
				if(StringUtils.isEqual(type, this.optType.group_member_mgr))
				{
					if(StringUtils.isEqual(itemTextValue, '移出群成员'))
					{
						ChatJumpHelper.jumpToGroupMemberRemove(this.groupInfo.id);
					}
					else if(StringUtils.isEqual(itemTextValue, '邀请好友加入'))
					{
						ChatJumpHelper.jumpToGroupMemberAdd(this.groupInfo.id);
					}
				}
				else if(StringUtils.isEqual(type, this.optType.group_invite_enter))
				{
					let invite = true;
					if(StringUtils.isEqual(itemTextValue, '开启'))
					{
						invite = false;
					}
					else if(StringUtils.isEqual(itemTextValue, '关闭'))
					{
						invite = true;
					}
					ToastUtils.showLoading();
					GroupApi.updateInviteStatus(this.groupInfo.id, invite, () => 
					{
						this.groupInfo.enableInvite = invite;
						GroupCMDManager.saveGroupInfo(this.groupInfo);
						ToastUtils.showSuccess("操作成功!");
					}, (code, msg) => {
						ToastUtils.showText(msg);
					});
				}
				else if(StringUtils.isEqual(type, this.optType.group_add_friend))
				{
					let status = true;
					if(StringUtils.isEqual(itemTextValue, '开启'))
					{
						status = false;
					}
					else if(StringUtils.isEqual(itemTextValue, '关闭'))
					{
						status = true;
					}
					ToastUtils.showLoading();
					GroupApi.updateAddFriendStatus(this.groupInfo.id, status, () => 
					{
						this.groupInfo.enableAddFriend = status;
						GroupCMDManager.saveGroupInfo(this.groupInfo);
						ToastUtils.showSuccess("操作成功!");
					}, (code, msg) => {
						ToastUtils.showText(msg);
					});
				}
				else if(StringUtils.isEqual(type, this.optType.group_enable_chat))
				{
					var status = true;
					if(StringUtils.isEqual(itemTextValue, '开启'))
					{
						status = false;
					}
					else if(StringUtils.isEqual(itemTextValue, '关闭'))
					{
						status = true;
					}
					ToastUtils.showLoading();
					GroupApi.updateChatStatus(this.groupInfo.id, status, () => 
					{
						this.groupInfo.enableChat = status;
						GroupCMDManager.saveGroupInfo(this.groupInfo);
						ToastUtils.showSuccess("操作成功!");
					}, (code, msg) => {
						ToastUtils.showText(msg);
					});
				}
				
				this.closeActionSheet();
			},
		
			
			isAdmin(member)
			{
				var len = this.mAdminList.length;
				for(var i = 0; i < len; i ++)
				{
					var adminUsername = this.mAdminList[i];
					if(adminUsername == member)
					{
						return true;
					}
				}
				return false;
			}
		}
		
	}
	/**
	 * 群信息页面
	 */
</script>

<style>
	.uni-list{margin-top: 20upx;}
	
	.top_member{
		background-color: #fff;
		display: flex;
		flex-wrap:wrap;
		justify-content:space-between;
	}
	.top_member_img{text-align: center;padding: 0 8upx;}
	.top_member_img image{width: 80upx;height: 80upx;border-radius: 8upx;}
	.top_member_img view{color: #999;font-size: 24upx;}
	.top_member_img_blank{width: 96upx;height: 80upx;flex: 1;}
	
	.bot_opt{
		background-color: #fff;
		text-align: center;
		margin-top: 20upx;
	}
	.bot_opt view{
		color: #f95454;
		font-size: 32upx;
		line-height: 96upx;
		border-bottom: 1px solid #f2f2f2;
	}
	
</style>
