import Cache from '@/pages/framework/cache/Cache.js'
import JsonUtils from '@/pages/framework/utils/JsonUtils.js'

import UserDefHelper from "@/pages/user/helper/UserDefHelper.js"

import FriendApi from "@/pages/chat/service/FriendApi.js"

// cache key
const FRIEND_INFO_CACHE_PREFIX_KEY = "passport_friend_info_";

const FriendInfoManager = {
	
	saveFriendInfo(friendInfo)
	{
		if(friendInfo == null || !friendInfo.hasOwnProperty("username"))
		{
			return;
		}
		friendInfo.avatar = UserDefHelper.getAvatar(friendInfo.avatar);
		friendInfo.nickname = UserDefHelper.getNickname(friendInfo.nickname);
		// set cache
		Cache.setValue(FRIEND_INFO_CACHE_PREFIX_KEY + friendInfo.username, friendInfo);
	},
	
	getFriendInfo(friendUsername)
	{
		var model = Cache.getValue(FRIEND_INFO_CACHE_PREFIX_KEY + friendUsername) || {};
		return model;
	},
	
	refreshFriendInfo(reload, friendUsername, success, failure)
	{
		let model = this.getFriendInfo(friendUsername);
		if(!reload && !JsonUtils.isEmptyForMap(model))
		{
			if(success != null) success(model);
			return;
		}
		let self = this;
		FriendApi.getFriendInfo(friendUsername, (data) => {
			//console.log(data);
			self.saveFriendInfo(data);
			if(success != null) success(data);
		}, failure);
	},
	
}

export default FriendInfoManager