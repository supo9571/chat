import StringUtils from '@/pages/framework/utils/StringUtils.js'
import PushManager from "@/pages/framework/push/PushManager.js"
import UserManager from "@/pages/user/logical/UserManager.js"
import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js" 

const LocalPushHelper = {
	sendNotify(dataJson)
	{
		// #ifdef APP-PLUS
		let fromUserid = dataJson.fromUserid;
		let selfUsername = UserManager.getUserInfo().username;
		// 自己发送的消息
		if(StringUtils.isEqual(selfUsername, fromUserid))
		{
			return;
		}
		
		//console.log("receiv single chat : ", dataJson);
		let title = '';
		let content = '';
		let msgType = dataJson.msgType;
		if( BasicMsgType.TEXT == msgType)
		{
			content = "新消息: " + dataJson.data.content;
		}
		else if( 
			BasicMsgType.IMAGE == msgType ||
			BasicMsgType.VOICE == msgType ||
			BasicMsgType.FILE == msgType ||
			BasicMsgType.SHOURT_VIDEO == msgType ||
			BasicMsgType.POSITION == msgType ||
			BasicMsgType.CARD == msgType ||
			BasicMsgType.RED_PACKET == msgType)
		{
			content = "你有一条新消息!"
		}
		else
		{
			return;
		}
		
		PushManager.sendLocalMessage(title, content, dataJson);
		
		// #endif
	}
}

export default LocalPushHelper