
import TextFilter from "./body/TextFilter.js"
import JsonUtils from '@/pages/framework/utils/JsonUtils.js'


const mFilterArray = [TextFilter];

const mFilterLength = mFilterArray.length;

/**
 * 消息过滤器
 */
const ChatFilterManager = {
	
	doInputFilter(body, callback)
	{
		// 网络数据过来,没有其它用,就不进行copy了
		body.status = true;
		JsonUtils.null2Str(body);
		
		// do filters
		for(let i = 0; i < mFilterLength; i ++)
		{
			let filter = mFilterArray[i];
			if(filter.support(body))
			{
				filter.doInputFilter(body, callback);
				return;
			}
		}
		callback(body);
	},
	
	doOutputFilter(body)
	{
		// 对消息体进行深copy
		let bodyString = JSON.stringify(body);
		let newBody = JSON.parse(bodyString);
		
		// do filters
		for(let i = 0; i < mFilterLength; i ++)
		{
			let filter = mFilterArray[i];
			if(filter.support(body))
			{
				return filter.doOutputFilter(newBody);
			}
		}
		
		return body;
	}
	
}


export default ChatFilterManager