<template>
	<view>
		<view class="uni-form-item uni-column">
			<view class="title">备注名</view>
			<input class="uni-input" placeholder-style="color:#999" placeholder="备注名" v-model="input.alias" maxlength="20" />
		</view>
		<view class="uni-form-item uni-column">
			<view class="title">电话号码</view>
			<input class="uni-input" placeholder-style="color:#999" placeholder="电话号码" v-model="input.mobile" />
		</view>
	</view>
</template>

<script>
	// framework
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	
	// 备注好友信息
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import FriendApi from "@/pages/chat/service/FriendApi.js"
	
	export default {
		data() {
			return {
				friendInfo : {
					username : '',
					
					alias : '',
					mobile : '',
					remark : ''
				},
				
				input : {
					alias : '',
					mobile : '',
					remark : ''
				}
			}
		},
		onLoad(options) {
			//console.log(options);
			
			this.friendInfo.username = options.friendUsername;
			
			let self = this;
			FriendInfoManager.refreshFriendInfo(false, this.friendInfo.username, 
			(data) => {
				self.friendInfo = data;
				self.input.alias = data.alias;
				self.input.mobile = data.mobile;
				
			}, null);
		},
		onNavigationBarButtonTap(res) {
			if(
				StringUtils.isEqual(this.friendInfo.alias, this.input.alias) && 
				StringUtils.isEqual(this.friendInfo.mobile, this.input.mobile) && 
				StringUtils.isEqual(this.friendInfo.remark, this.input.remark))
			{
				return;
			}
			
			FriendApi.updateFriendInfo(this.friendInfo.username, this.input.alias, this.input.mobile, this.input.remark, () => 
			{
				uni.navigateBack();
			}, null);
		},
		
	}
</script>

<style>
</style>
