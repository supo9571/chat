// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ConfigHelper from '@/pages/framework/config/ConfigHelper.js'
import JsonUtils from '@/pages/framework/utils/JsonUtils.js'
import MessageEncrypt from "@/pages/chat/logical/MessageEncrypt.js"
import SocketioManager from '@/pages/framework/socket/SocketioManager.js'

import UserApi from "@/pages/user/service/UserApi.js"

import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import KefuChatManager from "@/pages/kefu/logical/KefuChatManager.js"
import SingleChatManager from "@/pages/chat/logical/handler/SingleChatManager.js"
import GroupChatManager from "@/pages/chat/logical/handler/GroupChatManager.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
import KefuInfoManager from "@/pages/kefu/logical/KefuInfoManager.js"

import ChatFilterManager from "@/pages/chat/filter/ChatFilterManager.js"


import IMApi from "@/pages/chat/service/IMApi.js"

import UserManager from '@/pages/user/logical/UserManager.js'


/**
 * 消息聊天类型分发器
 */
class ChatManager {
	
	constructor() {
		this.isConnectServerSuccess = false;
		
		// 处理器需要实现 onStart, getEvent, onReceivMessage
		this.messageHandleMaps = {};
		this.addHandle(SingleChatManager);
		this.addHandle(FriendCMDManager);
		this.addHandle(GroupChatManager);
		this.addHandle(GroupCMDManager);
		this.addHandle(KefuChatManager);

		let self = this;
		for(let key in this.messageHandleMaps)
		{
			let handle = this.messageHandleMaps[key];
			handle.onStart();
		}
		
		// init socketio
		this.mSocketioMgr = new SocketioManager();
		this.mSocketioMgr.setDataCallback((data) => 
		{
			try{
				//console.log("receive message : ", data);
				data = MessageEncrypt.decrypt(data);
				let unRawDataJson = JSON.parse(data);
				
				// 对消息信息内容进行过虑
				ChatFilterManager.doInputFilter(unRawDataJson, (dataJson) => {
					
					// 登陆消息
					if(StringUtils.isEqual(dataJson.event, MessageEvent.LOGIN))
					{
						self.handleLoginMessage(dataJson);
						return;
					}
					
					let messageHandle = this.messageHandleMaps[dataJson.event];
					if(messageHandle == null || typeof(messageHandle) == undefined) 
					{
						console.log("有新有消息事件待处理........");
						return false;
					}
					
					// 消息接收拦截器, 对业务进行过虑
					if(!messageHandle.getInterceptor().doInputInterceptor(dataJson))
					{
						return false;
					}
					
					messageHandle.onReceivMessage(dataJson);
					
				});
				
			}catch(e){
				console.log("listener message handle error:", e)
			}
		});
	}
	
	addHandle(handle)
	{
		let eventName = handle.getEvent();
		this.messageHandleMaps[eventName] = handle;
	}
	
	getHandle(event)
	{
		return this.messageHandleMaps[event];
	}
	
	setLogonServer(logonServer)
	{
		this.mLogonServer = logonServer;
		this.mSocketioMgr.setConnectCallback(logonServer);
	}
	
	start(url)
	{
		this.mSocketioMgr.start(url);
	}
	
	close()
	{
		this.isConnectServerSuccess = false;
		this.mSocketioMgr.close();
	}
	
	
	isClose()
	{
		return this.mSocketioMgr.isClose() || !this.isConnectServerSuccess;
	}
	
	handleLoginMessage(protocol)
	{
		let dataJson = protocol.data;
		let code = dataJson.code;
		
		// token 异常
		if(code == 200)
		{
			this.isConnectServerSuccess = true;
			this.mLogonServer.onSuccess();
			FriendCMDManager.refreshFriendList(true, null);
			GroupCMDManager.refreshUserGroup(true, (isCache, dataList) => {
				if(!isCache)
				{
					// 重新加载
					this.loadOffline(1);
				}
			});
			KefuInfoManager.refreshKefuList(true, null);
			return;
		}
		this.mLogonServer.onReceivMessage(protocol);
	}
	
	/**
	 * 处理消息
	 * @param {Object} dataJson
	 */
	handleMessage(dataJson)
	{
		let event = dataJson.event;
		let messageHandle = this.messageHandleMaps[dataJson.event];
		if(messageHandle == null || typeof(messageHandle) == undefined)
		{
			console.log("有新有消息事件待处理........");
			return false;
		}
		messageHandle.onReceivMessage(dataJson);
	}
	
	sendMessage(dataJson)
	{
		if(!this.isConnectServerSuccess)
		{
			return false;
		}
		let newBody = ChatFilterManager.doOutputFilter(dataJson);
		let msg = JsonUtils.toJsonString(newBody);
		if(StringUtils.isEmpty(msg))
		{
			return false;
		}
		let encryBody = MessageEncrypt.encrypt(msg);
		//encryBody = encodeURIComponent(encryBody);
		// + 这个字符在app下会被转换成[空隔]字符, 这里直接转换成_ 在后台再做一下正则替换
		encryBody = encryBody.replace(/\+/g,"_");
		//console.log(encryBody);
		
		return this.mSocketioMgr.sendMessage(encryBody);
	}
	
	/**
	 * 离线消息
	 * @param {Object} page
	 */
	loadOffline(page)
	{
		let self = this;
		IMApi.getOfflineMessage(page, (dataList) => {
			let len = dataList.length;
			if(len <= 0)
			{
				return;
			}
			for(let index in dataList)
			{
				let unRawDataJson = dataList[index];
				unRawDataJson.status = true;
				try{
					ChatFilterManager.doInputFilter(unRawDataJson, (dataJson) => {
						
						let messageHandle = self.messageHandleMaps[dataJson.event];
						if(messageHandle == null || messageHandle == undefined) 
						{
							console.log("有新有消息事件待处理........");
							return;
						}
						
						// 消息接收拦截器, 对业务进行过虑
						if(!messageHandle.getInterceptor().doInputInterceptor(dataJson))
						{
							return;
						}
						messageHandle.onReceivMessage(dataJson);
					});
				}catch(e){
					console.log("load offline message error:", e)
				}
				
			}
			let nextPage = page + 1;
			this.loadOffline(nextPage)
		});
	}
	
}

const messageIntance = new ChatManager();

export default messageIntance