import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import ChatManager from '@/pages/chat/logical/ChatManager.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import BlackFriendManager from "@/pages/chat/logical/BlackFriendManager.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"

import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"

// user
import UserManager from '@/pages/user/logical/UserManager.js'

const SingleChatInterceptor = {
	
	doInputInterceptor(dataJson)
	{
		let fromUserid = dataJson.fromUserid;
		
		// 好友发送的消息,不是朋友直接丢弃
		if(!FriendCMDManager.isFriend(fromUserid))
		{
			return false;
		}
		// 被我拉入黑名单的直接丢弃
		// let friendInfo = FriendInfoManager.getFriendInfo(fromUserid);
		// if(friendInfo != null && friendInfo.black )
		// {
		// 	return false;
		// }
		return true;
	},
	
	doOutputInterceptor(dataJson)
	{
		//console.log("===========doInputInterceptor");
		let event = dataJson.event;
		let targetid = dataJson.targetid;
		
		// 被对方拉黑
		// if(BlackFriendManager.isBlackIn(targetid))
		// {
		// 	// 对方拒绝你的消息
		// 	let body = ProtocolHelper.localTextTips(targetid, event, '对方拒绝你的消息');
		// 	ChatManager.handleMessage(body);
		// 	return false;
		// }
		// 被对方删除好友关系
		if(!FriendCMDManager.isFriend(targetid))
		{
			let body = ProtocolHelper.localVerifyFriend(targetid, event);
			ChatManager.handleMessage(body);
			return false;
		}
		return true;
	},
	
}

export default SingleChatInterceptor