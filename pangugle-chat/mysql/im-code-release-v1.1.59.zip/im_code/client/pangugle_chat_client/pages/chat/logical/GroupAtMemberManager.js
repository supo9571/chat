
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import StringUtils from "@/pages/framework/utils/StringUtils.js"

const GroupAtMemberManager = {
	
	start(inputMaxlength)
	{
		if(!this.isInit)
		{
			this.mInputMaxlength = inputMaxlength;
			this.isInit = true;
			this.mAtMemberArray = [];
		}
	},
	
	isActive()
	{
		if(!this.isInit)
		{
			return false;
		}
		return true;
	},
	
	isBackText(currentInputValue)
	{
		if(StringUtils.isEmpty(this.mInputValue))
		{
			return false;
		}
		
		//console.log("lastLength = " + this.mInputValue.length + ", current length = " + currentInputValue.length);
		
		if(this.mInputValue.length > currentInputValue.length)
		{
			return true;
		}
		return false;
	},
	
	
	clear()
	{
		this.mAtMemberArray = null;
		this.isInit = false;
		this.mCursor = -1;
	},
	
	setCursor(cursor)
	{
		this.mCursor = cursor;
	},
	
	setInputValue(input)
	{
		if(!input)
		{
			input = '';
		}
		this.mInputValue = input;
	},
	
	getInputValue()
	{
		if(!this.mInputValue)
		{
			return '';
		}
		return this.mInputValue;
	},
	
	addMember(username, nickname)
	{
		//console.log("=============");
		// 1 表示空字符
		var currentLen = this.mInputValue.length + nickname.length + 1;
		
		if(currentLen >= this.mInputMaxlength - 1)
		{
			ToastUtils.showText("已超过最大字符!");
			return;
		}
		
		var item = {
			username,
			nickname
		}
		this.mAtMemberArray.push(item);
		
		this.mInputValue = StringUtils.insertString(this.mInputValue, this.mCursor, nickname + " ");
		
		//console.log("=============== new value = " + this.mInputValue);
	},
	
	getAllMember()
	{
		return this.mAtMemberArray;
	}
	
	
}


export default GroupAtMemberManager