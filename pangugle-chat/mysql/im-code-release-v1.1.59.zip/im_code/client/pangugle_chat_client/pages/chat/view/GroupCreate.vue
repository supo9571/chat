<template>
	
	<view>
		
		<view class="uni-list">
			<view class="uni-list-cell" hover-class="uni-list-cell-hover"
				v-for="(item, key) in contactDataList" :key="key"
				@click="onClickFriendList(item)">
				<view class="uni-media-list ">
					<view class="uni-media-list-logo">
						<checkbox :value="item.username" :disabled="item.disabled" :checked="item.checked"/>
						<image :src="handleFriendAvatar(item)" mode=""></image>
					</view>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleFriendTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<sunui-template  
			v-if="emptySdk.showView" 
			:skyContent="emptySdk.showContent" 
			:skyDesc="emptySdk.skyDesc">
		</sunui-template>
		
		
		<!-- 
		<pg-fab :left="fab.left" :right="fab.right" :bottom="fab.bottom" :bgColor="fab.bgColor" @click="onFabClick"></pg-fab>
		-->
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import pgFab from "@/components/pg-fab/pg-fab.vue"
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	
	import GroupApi from "@/pages/chat/service/GroupApi.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	
	/**
	 * 消息转发器
	 */
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem,
			uniPopup,
			pgFab
		},
		data() {
			return {
				mCurrentSelectStatus : '',
				maxSelectItemCount : 9, //最多能选择几个人
				
				isHasFriend : false,
				contactDataList : [],
				
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无好友~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					showView : false,
					// 是否显示内容
					showContent: false,
				},
			}
		},
		onShow() {
			FriendCMDManager.setFriendListCallback(this);
			FriendCMDManager.refreshFriendList(false, null);
		},
		onNavigationBarButtonTap(e) {
			this.doCreateGroup();
		},
		methods: {
			handleFriendTitle(value) 
			{
				let title = value.username;
				let friendInfo = FriendInfoManager.getFriendInfo(value.username);
				if(!StringUtils.isEmpty(friendInfo.alias))
				{
					title = friendInfo.alias;
				}
				else if(!StringUtils.isEmpty(friendInfo.nickname))
				{
					title = friendInfo.nickname;
				}
				return title;
			},
			handleFriendAvatar(value)
			{
				let title = value.username;
				let friendInfo = FriendInfoManager.getFriendInfo(value.username);
				return friendInfo.avatar;
			},
			/////////////////////////////////////////////////////
			doCreateGroup()
			{
				let selectMemberList = [];
				let currentSelectCount = 0;
				//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
				let len = this.contactDataList.length;
				for(let i = 0; i < len; i ++)
				{
					let item = this.contactDataList[i];
					if(item.checked)
					{
						selectMemberList.push(item.username);
					}
				}
				if(selectMemberList.length <= 0)
				{
					ToastUtils.showText("请选择好友!")
					return;
				}
				
				ToastUtils.showLoading();
				GroupApi.createGroup(selectMemberList, (groupid) => 
				{
					ToastUtils.showLoading();
					GroupCMDManager.refreshUserGroup(true, (isCache, dataList) => {
						if(!isCache)
						{
							ChatJumpHelper.jumpToGroupChat(groupid, true);
						}
					})
				}, null);
			},
			
			//////////////////////////////////////////////////////
			onClickFriendList(item)
			{
				let currentSelectCount = 0;
				//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
				let len = this.contactDataList.length;
				for(let i = 0; i < len; i ++)
				{
					let item = this.contactDataList[i];
					if(item.checked)
					{
						currentSelectCount ++;
					}
				}
				if(this.maxSelectItemCount <= currentSelectCount)
				{
					ToastUtils.showText("最多只能选择" + this.maxSelectItemCount + "人!")
					return;
				}
				item.checked = !item.checked;
			},
			
			onFriendListCallback(dataList)
			{
				let dataArray = [];
				let len = dataList.length;
				if(len > 0)
				{
					for(let i = 0; i < len; i ++)
					{
						let item = dataList[i];
						item.checked = false;
						item.disabled = true;
						dataArray.push(item);
					}
				}
				this.isHasFriend = len > 0
				this.emptySdk.showView = !this.isHasFriend;
				this.contactDataList = dataArray;
				
			},
			
			/**
			 * 监听多选状态，暂时不需要
			 * @param {Object} e
			 */
			onCheckboxChange(e) {
				let items = this.contactDataList;
				let	checkArray = e.detail.value;
				let len = checkArray.length;
				
				
				let itemLen = items.length;
				for (var i = 0; i < itemLen; ++i) {
					let item = items[i]
					if(checkArray.indexOf(item.username) >= 0){
						this.$set(item,'checked',true)
					}else{
						this.$set(item,'checked',false)
					}
					if(len >= 9 && !item.checked)
					{
						this.$set(item,'disabled',true)
					}
					else
					{
						this.$set(item,'disabled',false)
					}
				}
			}
		}
	}
</script>

<style>
	checkbox{
		position: absolute;
		top: 16px;
		left: 10px;
		z-index:700 ;
	}
	.uni-list-item{padding-left: 30px!important;}
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
	
	.uni-media-list-logo{
		width: 78px;
	}
	.uni-media-list-logo image{
		height: 40px;
		width: 40px;
		margin-left: 32px;
	}
</style>
