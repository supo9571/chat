<template>
	
	<view>
		<view class="uni-list">
			<view class="uni-list-cell" 
				hover-class="uni-list-cell-hover"  
				v-for="(item, key) in mFriendList" :key="key"
				@tap="onClickForFriendList(item)">
				<view class="uni-media-list ">
					<checkbox v-if="actionSheet.isMultiCheckeMode" :disabled="true" :checked="item.checked" />
					
					<pg-avatar class="uni-media-list-logo" :dataList="[item.avatar]">
					</pg-avatar>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleFriendTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<pg-actionsheet
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.currentItemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
		
		<uni-popup class="pg_popup" :show="alertView.show" type="center" :mask-click="false" >
			<view class="title_top">{{handleAlertViewTopTitle()}}</view>
			<!-- 发送谁 -->
			<view class="pdLR">
				<view class="top_">
					<!-- 单人 显示头像和名字-->
					<view class="single_people"
						v-if="!actionSheet.isMultiCheckeMode && receivInfo.length > 0">
						<pg-avatar 
							:length="1" 
							:dataList="receivInfo[0].avatar">
						</pg-avatar>
						<text>{{receivInfo[0].title}}</text>
					</view>
					
					<!-- 多人 显示头像 -->
					<view v-else class="many_people">
						<pg-avatar
							v-for="(item, key) in receivInfo" :key="key"
							:length="item.avatar.length" 
							:dataList="item.avatar">
						</pg-avatar>
					</view>
				</view>
				
				<view class="bot_">
					<!-- 内容 内容 -->
					<view v-if="messageBody.msgType === BasicMsgType.TEXT" class="con_txt">
						<view>{{messageBody.data.content}}</view>
					</view>
					
					<!-- 内容 图片 -->
					<view v-else-if="messageBody.msgType === BasicMsgType.IMAGE" class="con_img">
						<image :src="messageBody.data.url" mode="aspectFit"></image>
					</view>
				</view>
				
			</view>
			<!-- 按钮 -->
			<view class="btn_bot">
				<view class="cancel" @click="onCloseAlertView()">取消</view>
				<view class="send" @click="onEnterAlertView()">确定</view>
			</view>
		</uni-popup>
		
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import Pinyin from '../../framework/utils/Pinyin.js'
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	import pgActionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import ConversationManager from "@/pages/chat/logical/ConversationManager.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem,
			pgAvatar,
			uniPopup,
			"pg-actionsheet": pgActionSheet
		},
		data() {
			return {
				mFriendList : [],
				
				mCurrentSelectStatus : '',
				maxSelectItemCount : 9, //最多能选择几个人
				
				
				actionSheet : {
					optValue : null,
					isMultiCheckeMode : false, //是否是多选
					show: false,
					maskClosable: true,
					tips: "",
					currentItemList : [
						{text: "单选",color: "#1a1a1a"},
						{text: "多选",color: "#1a1a1a"},
						{text: "立即发送",color: "#1a1a1a"},
					],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
				
				alertView : {
					show : false,
				},
				
				msgEvent : 'single',
				messageBody : null,
				
				// 发送人信息
				receivInfo : [],
				
				BasicMsgType : BasicMsgType,
			}
		},
		onLoad(options) {
			let data = JSON.parse(decodeURIComponent(options.data));
			this.messageBody = data;
		},
		onShow() {
			let dataArray = FriendCMDManager.getFriendList();
			for(let i in dataArray)
			{
				let item = dataArray[i];
				item.checked = false;
			}
			
			this.mFriendList = dataArray;
		},
		onNavigationBarButtonTap(e) {
			if(this.actionSheet.currentItemList.length == 0)
			{
				this.actionSheet.currentItemList = this.actionSheet.singleItemList;
			}
			this.actionSheet.show = true;
		},
		methods: {
			handleAlertViewTopTitle()
			{
				if(this.actionSheet.isMultiCheckeMode)
				{
					return "分别发送给:";
				}
				else
				{
					return "发送给:";
				}
			},
			handleFriendTitle(item)
			{
				let title = item.username;
				if(!StringUtils.isEmpty(item.alias))
				{
					title = item.alias;
				}
				else if(!StringUtils.isEmpty(item.nickname))
				{
					title = item.nickname;
				}
				return title;
			},
			closeActionSheet: function() {
				this.actionSheet.optValue = null;
				this.actionSheet.show = false;
			},
			onActionSheetItemClick: function(e) {
				let index = e.index;
				let itemTextValue = this.actionSheet.currentItemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '单选'))
				{
					this.actionSheet.isMultiCheckeMode = false;
				}
				else if(StringUtils.isEqual(itemTextValue, '多选'))
				{
					for(let i in this.mFriendList)
					{
						let item = this.mFriendList[i];
						item.checked = false;
					}
					this.actionSheet.isMultiCheckeMode = true;
				}
				else if(StringUtils.isEqual(itemTextValue, '立即发送'))
				{
					let currentSelectCount = 0;
					//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
					let len = this.mFriendList.length;
					let selectItemList = [];
					for(let i = 0; i < len; i ++)
					{
						let item = this.mFriendList[i];
						if(item.checked)
						{
							let selectItem = {
								'avatar' : [item.avatar],
								'title' : this.handleFriendTitle(item),
								'event' : this.msgEvent,
								'targetid' :item.username,
							};
							selectItemList.push(selectItem);
						}
					}
					if(selectItemList.length > 0)
					{
						this.receivInfo = selectItemList;
						this.alertView.show = true;
					}
					else
					{
						if(!this.actionSheet.isMultiCheckeMode)
						{
							ToastUtils.showText("多选时才使用!")
						}
						else
						{
							ToastUtils.showText("请选择发送人!")
						}
					}
					
				}
				
				this.closeActionSheet();
			},
			
			////////////////
			onCloseAlertView()
			{
				this.alertView.show = false;
			},
			
			/**
			 * 点击完成发送消息
			 */
			onEnterAlertView()
			{
				let userInfo = UserManager.getUserInfo();
				for(let i in this.receivInfo)
				{
					let item = this.receivInfo[i];
					
					let jsonString = JSON.stringify(this.messageBody);
					let newMsgBody = JSON.parse(jsonString);
					newMsgBody.targetid = item.targetid;
					newMsgBody.event = item.event;
					newMsgBody.fromUserid = userInfo.username;
					
					//console.log("send message body : ", newMsgBody);
					
					MessageHelper.sendMessage(newMsgBody);
				}
				this.onCloseAlertView();
				uni.navigateBack({
				    delta: 2
				});
			},
			
			/**
			 * item 点击事件
			 * @param {Object} item
			 */
			onClickForFriendList(item)
			{
				//console.log(item);
				// 单选模式
				if(!this.actionSheet.isMultiCheckeMode)
				{
					let receivList = [];
					let receivInfoItem = {
						"avatar" : [item.avatar],
						"title" : this.handleFriendTitle(item),
						"event" : this.msgEvent,
						"targetid" : item.username,
					}
					//console.log("receiv info : ", receivInfoItem);
					receivList.push(receivInfoItem);
					this.receivInfo = receivList;
					
					this.alertView.show = true;
					return;
				}
				//多选模式
				let currentSelectCount = 0;
				//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
				let len = this.mFriendList.length;
				for(let i = 0; i < len; i ++)
				{
					let item = this.mFriendList[i];
					if(item.checked)
					{
						currentSelectCount ++;
					}
				}
				if(this.maxSelectItemCount <= currentSelectCount)
				{
					ToastUtils.showText("最多只能选择" + this.maxSelectItemCount + "人!")
					return;
				}
				item.checked = !item.checked;
			}
		}
	}
</script>

<style>
	checkbox{
		display: flex;
	}
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
	.pdLR{padding: 0 32upx;width: 500upx;}
	.title_top{
		padding: 20upx 32upx 12upx 32upx;
		color: #000;
		font-size: 36upx;
		text-align: left;
	}
	.top_{
		border-bottom: 1px solid #f2f2f2;
		padding-bottom: 14upx;
	}
	.single_people{
		display: flex;
		flex-direction: row;
		align-items:center;
	}
	.single_people view{height: 70upx;width: 70upx;}
	.single_people image{border-radius: 6upx;}
	.single_people text{
		font-size: 36upx;margin-left: 14upx;
		overflow: hidden;
		white-space: nowrap;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
	}

	.many_people{
		padding: 5upx;
		display: flex;
		/* flex-wrap: wrap; */
		/* justify-content: space-between; */
		background-color: #ccc;
		max-height: 80upx;
		overflow: hidden;
	}
	.many_people view{
		width: 70upx;
		height: 70upx;
		border:4upx solid #ccc;
	}
	.li{
		width: 70upx;
		height: 70upx;
	}
	.bot_{
		padding: 20upx 0;
	}
	.con_img{
		text-align: center;
	}
	.con_img image{
		max-width: 70%;
		max-height: 300upx;
	}
	.con_txt{
		max-height: 100upx;
		min-height: 50upx;
		overflow: hidden;
		text-align: left;
		background-color: #f2f2f2;
		padding: 10upx;
	}
	.con_txt view,.con_sg_txt view{
		font-size: 28upx;
		color: #999;
		line-height: 44upx;
	}
	.con_sg_txt{
		text-align: left;
		height: 40upx;
	}
	.con_sg_txt view{
		overflow: hidden;
		white-space: nowrap;
		-o-text-overflow: ellipsis;
		text-overflow: ellipsis;
	}
	.btn_bot{
		border-top: 1px solid #f2f2f2;
		display: flex;
		justify-content:space-between;
	}
	.btn_bot view{
		width: 50%;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
	}
	.cancel{border-right: 1px solid #f2f2f2;color: #000;}
	.send{color: #657ee0;}
</style>
