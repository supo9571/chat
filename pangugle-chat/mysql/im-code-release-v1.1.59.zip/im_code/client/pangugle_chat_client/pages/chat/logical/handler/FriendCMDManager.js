// framework
import Cache from '@/pages/framework/cache/Cache.js'
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import FriendCMDInterceptor from "@/pages/chat/interceptor/FriendCMDInterceptor"

import FriendApi from "@/pages/chat/service/FriendApi.js"
import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
import BlackFriendManager from "@/pages/chat/logical/BlackFriendManager.js"


//===========================================
// ******** 指令类型也是消息类型 start ********
// 通知我更新待确认列表
const MSG_TYPE_UNCONFIRM = "unconfirm";
const MSG_TYPE_ENABLE = "enable";
const MSG_TYPE_DELETE = "delete";
const MSG_TYPE_BLACK = "black";
// ******** 指令类型也是消息类型 end **********
//===========================================

// 好友列表
const CACHE_FRIEND_LIST = "chat_friend_friend_list";
// 待确认列表
const CACHE_UNCONFIRM_LIST = "chat_friend_unconfirm_list";


const EVENT_NAME = MessageEvent.FRIEND;

/**
 * 好友指令管理器
 * 更新机制时机: 
 * 		1、通讯录启动应用第一次进入更新和下拉刷新
 * 		2、居于socket通知才更新
 * 		3、好友信息页面[删除]操作
 */
const FriendCMDManager = {
	
	getEvent()
	{
		return EVENT_NAME;
	},
	
	getInterceptor()
	{
		return FriendCMDInterceptor;
	},
	
	onStart()
	{
		//console.log("onstart FriendCMDManager ...");
	},
	
	/**
	 * 处理消息
	 * @param {Object} dataJson
	 */
	onReceivMessage(dataJson)
	{
		//console.log("receiv friend message : ", dataJson);
		let msgType = dataJson.msgType;
		let fromUserid = dataJson.fromUserid;
		let targetid = dataJson.targetid;
		
		if(StringUtils.isEqual(MSG_TYPE_UNCONFIRM, msgType))
		{
			// 影响的是我的待确认列表
			// 待确认列表消息, 主要更新通知用户去[新的朋友]去操作
			this.refreshUnconfirmList(true, null);
		}
		else if(StringUtils.isEqual(MSG_TYPE_ENABLE, msgType))
		{
			// 影响的是我的好友列表
			// 对方已通过好友验证请求, 此时应该更新好友列表
			this.refreshFriendList(true, (isCache) => 
			{
				if(!isCache)
				{
					// 本地推送消息
					let content = '我通过了你的好友请求验证请求，现在我们可以开始聊天了';
					
					// 创建消息体
					let body = ProtocolHelper.text(targetid, 'single', content, content);
					body.fromUserid = fromUserid;
					body.targetid = targetid;
					body.local = true;
					
					// 发送
					MessageHelper.sendMessage(body);
				}
			});
		}
		else if(StringUtils.isEqual(MSG_TYPE_DELETE, msgType))
		{
			this.refreshAll(true);
		}
		// 
		else if(StringUtils.isEqual(MSG_TYPE_BLACK, msgType))
		{
			BlackFriendManager.refreshStatus(true, fromUserid);
		}
	},
	
	/**
	 * 好友列表回调，页面UI里
	 * @param {Object} callback
	 */
	setFriendListCallback(callback)
	{
		this.mFriendListCallback = callback;
	},
	
	/**
	 * 添加好友申请页面回调
	 * @param {Object} callback
	 */
	setUnconfirmListCallback(callback)
	{
		this.mUnconfirmListCallback = callback;
	},
	
	/**
	 * 刷新所有数据
	 */
	refreshAll(reload)
	{
		// refresh friend list
		this.refreshFriendList(reload, null);
		
		// refresh add list
		this.refreshUnconfirmList(reload, null);
	},
	
	/**
	 * 待添加好友列表 {
		 username:用户名
		 nickname: 好友自己的昵称
		 remark:添加好友时备注
	 }
	 * @param {Object} success
	 */
	refreshUnconfirmList(reload, finishCallback)
	{
		let dataList = Cache.getValue(CACHE_UNCONFIRM_LIST);
		if(this.mUnconfirmListCallback != null)
		{
			// 更新列表
			this.mUnconfirmListCallback.onUnconfirmListCallback(dataList);
		}
		if(!reload)
		{
			if(finishCallback != null)
			{
				finishCallback();
			}
			return;
		}
		dataList = [];
		this.loadUnConfirmDataList(dataList, 1, 
		() => 
		{
			Cache.setValue(CACHE_UNCONFIRM_LIST, dataList);
			// 更新待确认列表
			if(this.mUnconfirmListCallback != null)
			{
				this.mUnconfirmListCallback.onUnconfirmListCallback(dataList);
			}
			// 执行完成回调
			if(finishCallback != null)
			{
				finishCallback();
			}
		});
	},
	
	/**
	 * 好友列表{
		 username:用户名
		 nickname: 好友自己的昵称
		 alias:别名，表示用户自己对好友的备注 - 目前还没这个字段
	 }
	 * @param {Object} success
	 */
	refreshFriendList(refresh, finishCallback)
	{

		let self = this;
		this.loadFriendDataList(refresh, 
		(isCache, dataList) => 
		{
			if(self.mFriendListCallback != null)
			{
				// 更新好友列表
				self.mFriendListCallback.onFriendListCallback(dataList);
			}
			if(finishCallback != undefined && finishCallback != null)
			{
				finishCallback(isCache);
			}
			Cache.setValue(CACHE_FRIEND_LIST, dataList);
		});
	},
	
	/**
	 * 好友列表数据
	 * @param {Object} dataList
	 * @param {Object} page
	 * @param {Object} success
	 */
	loadFriendDataList(refresh, success)
	{
		FriendApi.queryFriendList(refresh, (isCache, data) => 
		{
			if(!isCache)
			{
				for(let index in data)
				{
					let model = data[index];
					FriendInfoManager.saveFriendInfo(model);
				}
			}
			success(isCache, data);
		}, null);
	},
	
	/**
	 * 好友列表数据
	 * @param {Object} dataList
	 * @param {Object} page
	 * @param {Object} success
	 */
	loadUnConfirmDataList(dataList, page, success)
	{
		FriendApi.queryUnConfirmList(page, (data) => 
		{
			let pagesize = data.pagesize;
			let list = data.list;
			let size = list.length;
			if(size > 0)
			{
				for(let i = 0; i < size; i ++)
				{
					dataList.push(list[i]);
				}
			}
			// 服务端只有一页,最多保存10条
			success();
			
			// if(pagesize > 0 && size < pagesize)
			// {
			// 	page ++;
			// 	this.loadUnConfirmDataList(dataList, page, success);
			// }
			// else
			// {
			// 	success();
			// }
		}, null);
	},
	
	/**
	 * 判断是不是好友
	 * @param {Object} friendUsername
	 */
	isFriend(friendUsername)
	{
		let dataList = Cache.getValue(CACHE_FRIEND_LIST);
		for(let index in dataList)
		{
			let value = dataList[index];
			let username = value.username;
			if(StringUtils.isEqual(friendUsername, username))
			{
				return true;
			}
		}
		return false;
	},
	
	getFriendList()
	{
		return Cache.getValue(CACHE_FRIEND_LIST) || [];
	},
	
	deleteFriend(friendUsername)
	{
		let dataList = Cache.getValue(CACHE_FRIEND_LIST);
		for(let index in dataList)
		{
			let value = dataList[index];
			let username = value.username;
			if(StringUtils.isEqual(friendUsername, username))
			{
				dataList.splice(index, 1);
				Cache.setValue(CACHE_FRIEND_LIST, dataList);
				break;
			}
		}
	}
	
}


export default FriendCMDManager