//framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import ChatManager from '@/pages/chat/logical/ChatManager.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import BlackFriendManager from "@/pages/chat/logical/BlackFriendManager.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"

// user
import UserManager from '@/pages/user/logical/UserManager.js'


const MessageHelper = {
	
	sendMessage(dataJson)
	{
		let event = dataJson.event;
		let targetid = dataJson.targetid;
		
		// 本地消息发送,直接进入处理,不进入拦截器
		if(dataJson.local)
		{
			// 本地消息不发送到网络
			dataJson.status = true;
			ChatManager.handleMessage(dataJson);
			return true;
		}
		
		// 消息发送拦截器
		let handle = ChatManager.getHandle(event);
		if(!handle.getInterceptor().doOutputInterceptor(dataJson))
		{
			return false;
		}
		
		// 以下是发送消息流程
		// 撤回消息流程
		if(StringUtils.isEqual(dataJson.msgType, BasicMsgType.REVOKE))
		{
			let rs = ChatManager.sendMessage(dataJson);
			if(rs)
			{
				dataJson.status = true;
				ChatManager.handleMessage(dataJson);
			}
			else
			{
				//不成功
				ToastUtils.showText("连接异常,撤回失败!", null);
			}
		}
		// 重新发送消息流程
		else if(StringUtils.isEqual(dataJson.optType, 'resend'))
		{
			let rs = ChatManager.sendMessage(dataJson);
			if(rs)
			{
				dataJson.status = true;
				ChatManager.handleMessage(dataJson);
			}
			else
			{
				// 失败不做处理
			}
		}
		// 通用处理流程
		else
		{
			// 发送结果处理
			dataJson.status = true;
			ChatManager.handleMessage(dataJson);
			
			// 发送消息
			let rs = ChatManager.sendMessage(dataJson);
			if(!rs)
			{
				dataJson.status = false;
				dataJson.optType = "refresh_status";
				ChatManager.handleMessage(dataJson);
			}
		}
		return true;
	},
	
	sendText(targetid, event, content, showText, atUserArray = null)
	{
		let body = ProtocolHelper.text(targetid, event, content, showText, atUserArray);
		MessageHelper.sendMessage(body);
	},
	
	sendImage(targetid, event, srcImg, compressUrl, width, height)
	{
		let body = ProtocolHelper.image(targetid, event, srcImg, compressUrl, width, height);
		MessageHelper.sendMessage(body);
	},
	
	/**
	 * 个人名片
	 * @param {Object} targetid
	 * @param {Object} event
	 * @param {Object} friendUsername
	 * @param {Object} nickname
	 * @param {Object} avatar
	 */
	sendCard(targetid, event, friendUsername, nickname, avatar)
	{
		let body = ProtocolHelper.card(targetid, event, friendUsername, nickname, avatar);
		MessageHelper.sendMessage(body);
	},
	
	/**
	 * @param {Object} targetid
	 * @param {Object} event
	 * @param {Object} url 音频地址
	 * @param {Object} playTime 音频播放时长
	 */
	sendVoice(targetid, event, url, playTime)
	{
		let body = ProtocolHelper.voice(targetid, event, url, playTime);
		MessageHelper.sendMessage(body);
	}
	
}

export default MessageHelper
	