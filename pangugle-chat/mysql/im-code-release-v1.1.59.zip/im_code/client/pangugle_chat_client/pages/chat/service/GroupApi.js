import ApiRequest from '@/pages/framework/http/ApiRequest.js'
import CachePolicy from "@/pages/framework/http/CachePolicy.js"
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import MessageHelper from "@/pages/chat/helper/MessageHelper.js"

import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"

const GroupApi = {
	
	createGroup(memebers, success, failure)
	{
		//console.log(memebers);
		var params = {
			"memebers" : memebers.join(","),
		}
		var url = '/im/groupApi/createGroup';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	createGroupQrcodeInfo(groupid, success, failure)
	{
		//console.log(memebers);
		var params = {
			"groupid" : groupid,
		}
		var url = '/im/groupApi/createGroupQrcodeInfo';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	joinGroup(signGroupInfo, success)
	{
		var params = signGroupInfo;
		var url = '/im/groupApi/joinGroup';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, null);
	},
	
	deleteGroup(groupid, success, failure)
	{
		var params = {
			groupid : groupid,
		}
		var url = '/im/groupApi/deleteGroup';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	/**
	 * 邀请好友加入群组
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	inviteMembers(groupid, addMemebers, success, failure)
	{
		var params = {
			"groupid" : groupid,
			"addMemebers" : addMemebers.join(","),
		}
		var url = '/im/groupApi/inviteMembers';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	/**
	 * 
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	removeMembers(groupid, removeMembers, success, failure)
	{
		var params = {
			"groupid" : groupid,
			"removeMembers" : removeMembers.join(","),
		}
		var url = '/im/groupApi/removeMembers';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	/**
	 * 获取群成员列表
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	getMemberList(refresh, groupid, success, failure)
	{
		var params = {
			"groupid" : groupid,
		}
		var cachePolicy = CachePolicy.HTTP_CACHE_POLICY_LOCAL_OR_REMOTE;
		if(refresh)
		{
			cachePolicy = CachePolicy.HTTP_CACHE_POLICY_LOCAL_AND_REMOTE;
		}
		
		var url = '/im/groupApi/getMemberList?groupid=' + groupid;
		ApiRequest.getCacheRequest().post(url, params, cachePolicy, (isCache, data) => 
		{
			success(data["list"]);
		}, failure);
	},
	
	/**
	 * 获取用户加入加入了哪些群
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	getUserGroupList(success, failure)
	{
		var params = {}
		var url = '/im/groupApi/getUserGroupList';
		ApiRequest.post(url, params, (isCache, dataList) => 
		{
			success(dataList);
		}, failure);
	},
	
	/**
	 * 获取群信息
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	getGroupInfo(groupid, success, failure)
	{
		var params = {groupid}
		var url = '/im/groupApi/getGroupInfo';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	updateInviteStatus(groupid, inviteStatus, success, failure)
	{
		var params = {
			"groupid" : groupid,
			"invite" : inviteStatus
		}
		var url = '/im/groupApi/updateInviteStatus';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, failure);
	},
	
	updateAddFriendStatus(groupid, status, success, failure)
	{
		var params = {
			"groupid" : groupid,
			"status" : status
		}
		//console.log("===========");
		var url = '/im/groupApi/updateAddFriendStatus';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, failure);
	},
	
	updateChatStatus(groupid, status, success, failure)
	{
		var params = {
			"groupid" : groupid,
			"enableChat" : status
		}
		var url = '/im/groupApi/updateChatStatus';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, failure);
	},
	
	
	
	/**
	 * 获取群成员在群里的信息，如群内昵称、免打扰
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	getGroupRelation(groupid, username, success, failure)
	{
		let params = {
			groupid,
			username
		}
		let url = '/im/groupApi/getGroupRelation';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	/**
	 * 更新群名称
	 * @param {Object} groupid
	 * @param {Object} name
	 * @param {Object} success
	 */
	updateGroupName(groupid, name, success, failure)
	{
		let params = {
			groupid,
			name
		}
		let url = '/im/groupApi/updateGroupName';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			console.log("updateGroupName ========= ", data);
			GroupCMDManager.saveGroupInfo(data);
			success();
		}, failure);
	},
	
	updateGroupMemberChatDisabledTime(groupid, targetUsername, hours, success, failure)
	{
		let params = {
			groupid,
			targetUsername,
			hours,
		}
		let url = '/im/groupApi/updateGroupMemberChatDisabledTime';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	getGroupMemberChatDisableTime(groupid, username, success, failure)
	{
		let params = {
			groupid,
			username
		}
		let url = '/im/groupApi/getGroupMemberChatDisableTime';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	getGroupAdminList(groupid, success, failure)
	{
		let params = {groupid}
		let url = '/im/groupApi/getGroupAdminList';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	addGroupAdmin(groupid, username, success, failure)
	{
		let params = {
			groupid,
			username
		}
		let url = '/im/groupApi/addGroupAdmin';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	deleteGroupAdmin(groupid, username, success, failure)
	{
		let params = {
			groupid,
			username
		}
		let url = '/im/groupApi/deleteGroupAdmin';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	}
	
}

export default GroupApi