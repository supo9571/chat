import Cache from '@/pages/framework/cache/Cache.js'
import JsonUtils from '@/pages/framework/utils/JsonUtils.js'
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import UserDefHelper from "@/pages/user/helper/UserDefHelper.js"

import FriendApi from "@/pages/chat/service/FriendApi.js"

// cache key
const FRIEND_BLACK_IN_CACHE_PREFIX_KEY = "chat_friend_in_black";

/**
 * 查看自己是否被对方拉入黑名单
 * MessageHelper, UserBasicInfo, FriendCMDManager
 */
const BlackFriendManager = {
	
	saveStatus(friendUsername, isBlack)
	{
		// set cache
		Cache.setValue(FRIEND_BLACK_IN_CACHE_PREFIX_KEY + friendUsername, isBlack);
	},
	
	refreshStatus(reload, friendUsername)
	{
		let status = Cache.getValue(FRIEND_BLACK_IN_CACHE_PREFIX_KEY + friendUsername);
		if(!StringUtils.isEmpty(status) && !reload)
		{
			return;
		}
		let self = this;
		FriendApi.getBlackSelfStatus(friendUsername, (isBlack) => {
			self.saveStatus(friendUsername, isBlack);
		}, null);
	},
	
	isBlackIn(friendUsername)
	{
		let status = Cache.getValue(FRIEND_BLACK_IN_CACHE_PREFIX_KEY + friendUsername) || false;
		return status;
	}
	
	
}

export default BlackFriendManager