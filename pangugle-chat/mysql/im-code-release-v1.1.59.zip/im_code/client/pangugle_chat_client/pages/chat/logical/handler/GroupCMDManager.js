import Cache from '@/pages/framework/cache/Cache.js'
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
import GroupApi from "@/pages/chat/service/GroupApi.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import GroupCMDInterceptor from "@/pages/chat/interceptor/GroupCMDInterceptor"
import UserManager from "@/pages/user/logical/UserManager.js"

// cache key
const GROUP_MEMBER_LIST_CACHE_KEY = "chat_group_member_list"
const GROUP_SELF_CHAT_STATUS_CACHE_KEY = "chat_group_self_chat_status"
const GROUP_ADMIN_LIST_CACHE_KEY = "chat_group_admin_list"
const GROUP_LIST_CACHE_KEY = "chat_group_list"
const GROUP_INFO_CACHE_KEY = "chat_group_info"
const GROUP_RELATION_CACHE_KEY = "chat_group_relation"


// msg type
const MSG_TYPE_INVITE_MEMBER = "invite_member";
const MSG_TYPE_REMOVE_MEMBER = "remove_member";
const MSG_TYPE_UPDATE_GROUP_INFO = "update_group_info";

const EVENT_NAME = MessageEvent.GROUP_OPT;

const GroupCMDManager = {
	
	getInterceptor()
	{
		return GroupCMDInterceptor;
	},
	
	onStart()
	{
		//console.log("onstart GroupCMDManager ...");
	},
	
	getEvent()
	{
		return EVENT_NAME;
	},
	
	/**
	 * 处理消息
	 * @param {Object} dataJson
	 */
	onReceivMessage(dataJson)
	{
		var that = this;
		//console.log("receiv group opt message : ", dataJson);
		var msgType = dataJson.msgType;
		var fromUserid = dataJson.fromUserid;
		var targetid = dataJson.targetid;
		
		if(StringUtils.isEqual(MSG_TYPE_INVITE_MEMBER, msgType) ||
			StringUtils.isEqual(MSG_TYPE_REMOVE_MEMBER, msgType))
		{
			this.refreshUserGroup(true, (isCache, dataList) => {
				if(!isCache)
				{
					that.refreshMemberList(true, targetid, null)
				}
			});
		}
		else if(StringUtils.isEqual(MSG_TYPE_UPDATE_GROUP_INFO, msgType))
		{
			this.refreshGroupInfo(true, targetid, null);
		}
	},
	
	/**
	 * 好友列表{
		 username:用户名
		 nickname: 好友自己的昵称
		 alias:别名，表示用户自己对好友的备注 - 目前还没这个字段
	 }
	 * @param {Object} success
	 */
	refreshMemberList(refresh, groupid, finishCallback)
	{
		var self = this;
		var groupInfo = this.getGroupInfo(groupid);
		this.loadMemberList(refresh, groupid,  
		(dataList) => 
		{
			var holderRelationIndex = -1;
			for(var index in dataList)
			{
				var model = dataList[index];
				//FriendInfoManager.saveFriendInfo(model);
				self.saveGroupRelation(groupid, model.username, model);
				
				if(holderRelationIndex == -1 && StringUtils.isEqual(model.username, groupInfo.holder))
				{
					holderRelationIndex = index;
				}
			}
			// 将群主放到第一个
			if(holderRelationIndex != -1)
			{
				var item = dataList[holderRelationIndex];
				dataList.splice(holderRelationIndex, 1);
				dataList.unshift(item);
			}
			var cacheKey = GROUP_LIST_CACHE_KEY + "_" +groupid;
			Cache.setValue(cacheKey, dataList);
			// 执行完成回调
			if(finishCallback != null)
			{
				finishCallback(false, dataList);
			}
		});
	},
	
	/**
	 * 好友列表数据
	 * @param {Object} dataList
	 * @param {Object} page
	 * @param {Object} success
	 */
	loadMemberList(refresh, groupid, success)
	{
		GroupApi.getMemberList(refresh, groupid, (dataList) => 
		{
			success(dataList);
		}, (code, msg) => {
			success([]);
		});
	},
	
	saveGroupInfo(data)
	{
		//if(data.id == "20200411174043485276")
		//{
			//console.log("saveGroupInfo=============>", data.enableChat, data);
		//}
		var iconArray = data.icons.split(",");
		data.iconArray = iconArray;
		Cache.setValue(GROUP_INFO_CACHE_KEY + "_" + data.id, data);
	},
	
	getGroupInfo(groupid)
	{
		var groupInfo = Cache.getValue(GROUP_INFO_CACHE_KEY + "_" + groupid);
		return groupInfo;
	},
	
	refreshGroupInfo(reload, groupid, finishCallback)
	{
		var groupInfo = Cache.getValue(GROUP_INFO_CACHE_KEY + "_" + groupid) || null;
		var exist = groupInfo != null && !StringUtils.isEmpty(groupInfo.id);
		if(finishCallback != null && exist)
		{
			finishCallback(true, groupInfo);
		}
		if(!reload && exist)
		{
			return;
		}
		
		GroupApi.getGroupInfo(groupid, (data) => {
			this.saveGroupInfo(data);
			
			//console.log("======load from remote ", data);
			//console.log("======load from local", GroupCMDManager.getGroupInfo(groupid));
			
			if(finishCallback != null)
			{
				finishCallback(false, data);
			}
			
			// 更新我是不是被禁言的状态
			GroupApi.getGroupMemberChatDisableTime(groupid, UserManager.getUserInfo().username,
			(disabledTime) => {
				this.saveSelfChatStatus(groupid, disabledTime);
				//console.log("===========disabledTime ============" + disabledTime);
			}, null);
			
			// 群管理员列表
			this.refreshGroupAdminList(groupid, null);
		}, 
		(code, msg) => {
			if(finishCallback != null)
			{
				finishCallback(false, null);
			}
		});
		
		
	},
	
	getUserGroup(){
		return Cache.getValue(GROUP_LIST_CACHE_KEY) || []; 
	},
	
	refreshUserGroup(reload, completeCallback)
	{
		var dataList = Cache.getValue(GROUP_LIST_CACHE_KEY);
		if(completeCallback != null)
		{
			completeCallback(true, dataList);
		}
		if(!reload && dataList.length > 0)
		{
			return;
		}
		var that = this;
		GroupApi.getUserGroupList((dataArray) => 
		{
			var len = dataArray.length;
			for(var index in dataArray)
			{
				// 数据会被覆盖, 服务端要保证数据
				var item = dataArray[index];
				that.saveGroupInfo(item);
			}
			Cache.setValue(GROUP_LIST_CACHE_KEY, dataArray);
			if(completeCallback != null)
			{
				completeCallback(false, dataArray)
			}
		}, (code, msg) => {
			if(completeCallback != null)
			{
				completeCallback(false, dataList)
			}
		})
	},
	
	saveGroupRelation(groupid, username, data)
	{
		var cachekey = GROUP_RELATION_CACHE_KEY + "_" + groupid + "_" + username;
		Cache.setValue(cachekey, data);
	},
	
	getGroupRelation(groupid, username)
	{
		var cachekey = GROUP_RELATION_CACHE_KEY + "_" + groupid + "_" + username;
		var cacheData = Cache.getValue(cachekey) || null;
		return cacheData;
	},
	
	refreshGroupRelation(refresh, groupid, username, finishCallback)
	{
		var that = this;
		var cacheData = this.getGroupRelation(groupid, username);
		if(!refresh && cacheData != null)
		{
			if(finishCallback != null)
			{
				finishCallback(true, cacheData);
			}
			return;
		}
		GroupApi.getGroupRelation(groupid, username, (item) =>
		{
			that.saveGroupRelation(groupid, username, item);
			if(finishCallback != null)
			{
				finishCallback(false, item)
			}
		}, (code, msg) => {
			if(finishCallback != null)
			{
				finishCallback(false, null)
			}
		})
	},
	
	isJoinGroup(groupid)
	{
		var dataList = this.getUserGroup();
		var len = dataList.length;
		for(var i = 0; i < len; i ++)
		{
			var id = dataList[i].id;
			if(StringUtils.isEqual(groupid, id))
			{
				return true;
			}
		}
		return false;
	},
	
	saveSelfChatStatus(groupid, time)
	{
		var username = UserManager.getUserInfo().username;
		var cachekey = GROUP_SELF_CHAT_STATUS_CACHE_KEY + groupid + username;
		Cache.setValue(cachekey, time);
	},
	
	isEnableSelfChat(groupid)
	{
		//console.log("============isEnableSelfChat");
		var username = UserManager.getUserInfo().username;
		var cachekey = GROUP_SELF_CHAT_STATUS_CACHE_KEY + groupid + username;
		var time = Cache.getValue(cachekey) || 0;
		var timestamp=new Date().getTime();
		if(time == 0 || timestamp > time)
		{
			return true;
		}
		return false;
	},
	
	saveAdminList(groupid, dataList)
	{
		//console.log(dataList);
		var cachekey = GROUP_ADMIN_LIST_CACHE_KEY + groupid;
		Cache.setValue(cachekey, dataList);
	},
	
	getAdminList(groupid)
	{
		var cachekey = GROUP_ADMIN_LIST_CACHE_KEY + groupid;
		var dataList = Cache.getValue(cachekey) || [];
		return dataList;
	},
	
	refreshGroupAdminList(groupid, success)
	{
		GroupApi.getGroupAdminList(groupid, (dataList) => {
			this.saveAdminList(groupid, dataList);
			if(success)
			{
				success(dataList);
			}
		}, null);
	}
	
	
	
}

export default GroupCMDManager