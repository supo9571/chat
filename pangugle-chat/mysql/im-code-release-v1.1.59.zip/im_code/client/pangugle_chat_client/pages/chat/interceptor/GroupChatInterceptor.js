import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import ChatManager from '@/pages/chat/logical/ChatManager.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import BlackFriendManager from "@/pages/chat/logical/BlackFriendManager.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"


// user
import UserManager from '@/pages/user/logical/UserManager.js'

const GroupChatInterceptor = {
	
	doInputInterceptor(dataJson)
	{
		let targetid = dataJson.targetid;
		// 验证是不是群成员,不是则直接丢弃消息
		if(!GroupCMDManager.isJoinGroup(targetid))
		{
			return false;
		}
		return true;
	},
	
	doOutputInterceptor(dataJson)
	{
		let event = dataJson.event;
		let targetid = dataJson.targetid;
		
		//console.log("sendText fro gorup");
		if(!GroupCMDManager.isJoinGroup(targetid))
		{
			let body = ProtocolHelper.localTextTips(targetid, event, '你不是群成员或该群已解散!');
			ChatManager.handleMessage(body);
			return false;
		}
		return true;
	},
	
}

export default GroupChatInterceptor