<template>
	<view>
		<view class="uni-form-item uni-column">
			<view class="title">你需要发送验证申请，等对方通过</view>
			<input class="uni-input" :value="inputValue" placeholder-style="color:#999" placeholder="备注名" />
		</view>
	</view>
</template>

<script>
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	
	// chat
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import UserManager from "@/pages/user/logical/UserManager.js"
	import FriendApi from "@/pages/chat/service/FriendApi.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	
	
	import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	
	import JumpManager from "@/pages/main/logical/JumpManager.js"
	
	export default {
		components:{
			
		},
		data(){
			return {
				friendUsername : '',
				friendNickname : '',
				
				inputValue : ''
			}
		},
		onLoad(options) {
			this.friendUsername = options.friendUsername;
			this.friendNickname = options.friendNickname;
			
			let nickname = UserManager.getUserInfo().nickname;
			if(!StringUtils.isEmpty(nickname))
			{
				this.inputValue = "我是" + nickname;
			}
		},
		onNavigationBarButtonTap(res) {
			this.addFriendRequest()
		},
		
		methods:{
			addFriendRequest()
			{
				uni.hideKeyboard();
				//console.log("===");
				let that = this;
				FriendApi.addFriend(this.friendUsername, this.inputValue, () => 
				{
					
					console.log("===");
					ToastUtils.showSuccess('验证请求已发送', () => {
						JumpManager.jumpToHome();
					});
				}, 
				//
				(code, msg) => 
				{
					// 已为好友
					if(code == -16)
					{
						ToastUtils.showFailure("请勿多次添加!");
					}
					else
					{
						ToastUtils.showFailure(msg);
					}
				})
			}
		}
		
	}
</script>

<style>
	.title{font-size: 14px;margin-top: 8px;color: #999;}
</style>
