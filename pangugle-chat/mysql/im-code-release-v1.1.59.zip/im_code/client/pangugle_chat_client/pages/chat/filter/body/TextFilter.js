// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"

import ChatTextHelper from "@/pages/chat/helper/ChatTextHelper.js"

const TextFilter = {
	
	support(dataJson)
	{
		return StringUtils.isEqual(dataJson.msgType, BasicMsgType.TEXT);
	},
	
	doInputFilter(dataJson, callback)
	{
		let data = dataJson.data;
		data.showText = ChatTextHelper.richText(data.content);
		callback(dataJson);
	},
	
	doOutputFilter(dataJson)
	{
		let newBodyString = JSON.stringify(dataJson);
		let newBody = JSON.parse(newBodyString);
		delete newBody['local'];
		
		let data = newBody['data'];
		delete data["showText"];
		newBody.data = data;
		return newBody;
	}
	
}

export default TextFilter