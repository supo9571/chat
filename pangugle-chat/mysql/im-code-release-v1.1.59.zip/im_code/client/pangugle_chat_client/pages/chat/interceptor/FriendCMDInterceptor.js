import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import ChatManager from '@/pages/chat/logical/ChatManager.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import BlackFriendManager from "@/pages/chat/logical/BlackFriendManager.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"


// user
import UserManager from '@/pages/user/logical/UserManager.js'

const FriendCMDInterceptor = {
	
	doInputInterceptor(dataJson)
	{
		return true;
	},
	
	doOutputInterceptor(body)
	{
		return true;
	},
	
}

export default FriendCMDInterceptor