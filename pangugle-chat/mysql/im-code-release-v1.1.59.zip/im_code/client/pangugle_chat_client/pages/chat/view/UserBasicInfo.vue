<template>
	
	<view class="content">
	
		<!-- uni-list-cell-navigate uni-navigate-right -->
		
		<view class="uni-list pg_uni_media_list">		
			<view class="uni-list-cell" >
				<view class="uni-media-list pg_media_list">
					<pg-image-cache class="uni-media-list-logo pg_media_list_logo" :imgSrc="friendInfo.avatar"></pg-image-cache>
					
					<view class="uni-media-list-body pg_media_list_body">
						<view class="uni-media-list-text-top pg_media_list_text">{{friendInfo.alias}}</view>
						<view class="uni-media-list-text-bottom uni-ellipsis pg_media_list_bottom">昵称：{{friendInfo.nickname}}</view>
						<view class="uni-media-list-text-bottom uni-ellipsis pg_media_list_bottom">用户名：{{friendInfo.username}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<view v-if="!isSelf">
			
			<uni-list v-if="showRemark" class="remark">
				<uni-list-item  title="设置备注" @click="jumpToRemarkFriend()"/>
				<uni-list-item  title="更多设置" @click="openActionSheet()"/>
			</uni-list>
			
			<!-- <uni-list>
				<uni-list-item :show-badge="true" title="设置备注"  />
			</uni-list> -->
			
			<view v-if="isFriend" class="foot" >
				<view @click="jumpToSingleChat()">发消息</view>
				<!-- 
				<view>音视频通话</view>
				-->
			</view>
			<view v-else class="foot" >
				<view @click="jumpToAddFriendApply()">添加到通讯录</view>
			</view>
			
			<view v-if="friendInfo.black" class="bottom_black">
				已添加至黑名单, 你将不再收到对方的消息
			</view>
			
		</view>
		
		 
		<pg-actionsheet
		 	:show="actionSheet.show" 
		 	:tips="actionSheet.tips" 
		 	:item-list="actionSheet.itemList" 
		 	:mask-closable="actionSheet.maskClosable"
		 	:color="actionSheet.color" 
		 	:size="actionSheet.size" 
		 	:is-cancel="actionSheet.isCancel" 
		 	@click="onActionSheetItemClick" 
		 	@cancel="closeActionSheet">
		</pg-actionsheet>
		 
		<pg-modal :show="modal.showDeleteFriendModal" 
			@click="deleteFriend" title="删除联系人" 
			content="删除联系人将同时删除与该联系人的聊天记录!">
		</pg-modal>
		
		<pg-modal :show="modal.showBlackFriendModal"
			@click="blackFriend" title="加入黑名单" 
			content="加入黑名单你将不再收到对方的消息!">
		</pg-modal>
	</view>
	
</template>

<script>
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	import pgmodal from "@/components/pg-modal/modal.vue"
	
	//
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	
	// 
	import JumpManager from "@/pages/main/logical/JumpManager.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import BlackFriendManager from "@/pages/chat/logical/BlackFriendManager.js"
	import FriendApi from "@/pages/chat/service/FriendApi.js"
	import ConversationManager from "@/pages/chat/logical/ConversationManager.js"
	
	import UserManager from "@/pages/user/logical/UserManager.js"
	import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'
	
	export default {
		data() {
			return {
				showRemark : false,
				
				friendInfo : {
					username : '',
					nickname : '',
					avatar: '',
					alias : '',
					black : false,
				},
				
				isSelf : false,
				isFriend : false, // 默认不是好友关系
				
				actionSheet : {
					optValue : {},
					show: false,
					maskClosable: true,
					tips: "",
					itemList: [
						{text: "设置备注",color: "#1a1a1a"},
						//{text: "删除好友",color: "#1a1a1a"},
						//{text: "加入黑名单",color: "#1a1a1a"},
					],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
				
				modal : {
					showDeleteFriendModal : false, // 删除联系人
					showBlackFriendModal : false,// 加入黑名单
				}
			}
		},
		components: {
			uniList,
			uniListItem,
			"pg-actionsheet" : actionSheet,
			'pg-modal' : pgmodal,
		},
		onLoad(options) {
			
			// 参数有长度限制
			let data = JSON.parse(decodeURIComponent(options.data));
			
			//console.log(data);
			this.friendInfo.username = data.username;
			//this.friendInfo.nickname = friendInfo.nickname;
			//this.friendInfo.avatar = friendInfo.avatar;
			
			let userInfo = UserManager.getUserInfo();
			this.isSelf = StringUtils.isEqual(userInfo.username, this.friendInfo.username);
			
			//BlackFriendManager.refreshStatus(false, this.friendInfo.username);
		},
		onShow() {
			this.handleFriendRelation(false);
		},
		methods: {
			
			handleFriendRelation(reload)
			{
				let self = this;
				this.isFriend = FriendCMDManager.isFriend(this.friendInfo.username);
				
				self.showRemark = false;
				FriendInfoManager.refreshFriendInfo(reload, this.friendInfo.username, (data) => {
					self.showRemark = true;
					self.friendInfo = data;
				}, (code, msg) => {
					console.log("load info error:", msg);
				})
			},
			
			getNickname()
			{
				return UserDefHelper.getNickname(this.friendInfo.nickname);
			},
			
			jumpToSingleChat()
			{
				ChatJumpHelper.jumpToSingleChat(this.friendInfo.username, null);
			},
			
			jumpToRemarkFriend()
			{
				uni.navigateTo({
					url:'RemarkFriendInfo?friendUsername=' + this.friendInfo.username
				})
			},
			
			jumpToAddFriendApply()
			{
				uni.navigateTo({
					url: './AddFriendApply?friendUsername=' + this.friendInfo.username + "&friendNickname=" + this.friendInfo.nickname
				})
			},
			
			deleteFriend(e)
			{
				let index = e.index;
				this.modal.showDeleteFriendModal = false;
				if (index === 1) {
					//this.tui.toast("你点击了确定按钮")
					ToastUtils.showLoading();
					let model = this.friendInfo;
					FriendApi.deleteFriend(model.username, () => {
						FriendCMDManager.refreshAll(true);
						//删除聊天记录
						let userInfo = UserManager.getUserInfo();
						ConversationManager.removeItemWithID('single', userInfo.username, model.username);
						// 回到首页
						JumpManager.jumpToHome();
					}, null);
				}
				
			},
			blackFriend(e)
			{
				let that = this;
				this.modal.showBlackFriendModal = false;
				let index = e.index;
				if (index === 1) {
					ToastUtils.showLoading();
					let model = this.friendInfo;
					FriendApi.updateBlackFriend(model.username, true, () => {
						that.handleFriendRelation(true);
					}, null)
				}
				
			},
			removeBlackFriend()
			{
				let that = this;
				ToastUtils.showLoading();
				let model = this.friendInfo;
				FriendApi.updateBlackFriend(model.username, false, () => {
					that.handleFriendRelation(true);
				}, null)
			},
			openActionSheet(){
				
				let itemList = [];
				
				let itemColor = '#1a1a1a';
				let remarkItem = {text: "设置备注",color: itemColor};
				itemList.push(remarkItem);
				if(this.isFriend)
				{
					let recToFriendItem = {text: "推荐给朋友",color: itemColor};
					itemList.push(recToFriendItem);
					
					let deleteItem = {text: "删除好友",color: itemColor};
					itemList.push(deleteItem);
				}
				
				// if(this.friendInfo.black == false)
				// {
				// 	let blackItem = {text: "加入黑名单",color: itemColor};
				// 	itemList.push(blackItem);
				// }
				// else
				// {
				// 	let blackItem = {text: "移除黑名单",color: itemColor};
				// 	itemList.push(blackItem);
				// }
				
				this.actionSheet.itemList = itemList;
				this.actionSheet.show = true;
			},
			closeActionSheet: function() {
				this.actionSheet.show = false
			},
			onActionSheetItemClick(e) {
				let index = e.index;
				let itemTextValue = this.actionSheet.itemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '删除好友'))
				{
					this.modal.showDeleteFriendModal = true;
				}
				else if(StringUtils.isEqual(itemTextValue, '设置备注'))
				{
					this.jumpToRemarkFriend();
				}
				else if(StringUtils.isEqual(itemTextValue, '推荐给朋友'))
				{
					let body = ProtocolHelper.card('', MessageEvent.SINGLE, this.friendInfo.username, this.friendInfo.nickname, this.friendInfo.avatar);
					ChatJumpHelper.jumpToShareCard(body);
				}
				else if(StringUtils.isEqual(itemTextValue, '加入黑名单'))
				{
					this.modal.showBlackFriendModal = true;
				}
				else if(StringUtils.isEqual(itemTextValue, '移除黑名单'))
				{
					this.removeBlackFriend();
				}
				this.closeActionSheet();
			},
			
		}
	}
</script>

<style>
	.remark::before{background-color: #fff!important;}
	.uni-list{margin-bottom: 10px;}
	.uni-list::after{background-color: #fff;}
	
	.foot{margin-top: 10px;text-align: center;background-color: #fff;padding: 0 12px;}
	.foot view{line-height: 50px;font-size: 17px;color: #007aff;border-bottom: 1px solid #e5e5e5;}
	.foot view:nth-last-child(1){border-bottom: none;}
	
	.bottom_black{
		text-align: center;
		font-size: 12px;
		color: #999;
		margin-top: 15px;
	}
</style>
