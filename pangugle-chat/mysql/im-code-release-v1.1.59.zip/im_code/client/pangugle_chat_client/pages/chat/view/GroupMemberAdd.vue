<template>
	
	<view>
		<view class="uni-list">
			<view class="uni-list-cell" 
				hover-class="uni-list-cell-hover"  
				v-for="(item, key) in dataList" :key="key"
				@tap="onClickItemList(item)">
				<view class="uni-media-list ">
					<checkbox v-if="showType !== 'list'" :disabled="true" :checked="item.checked" />
					
					<pg-avatar class="uni-media-list-logo" :dataList="[item.avatar]">
					</pg-avatar>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import pgFab from "@/components/pg-fab/pg-fab.vue"
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	
	import GroupApi from "@/pages/chat/service/GroupApi.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	/**
	 * 消息转发器
	 */
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem,
			uniPopup,
			pgFab,
			pgAvatar
		},
		data() {
			return {
				mCurrentSelectStatus : '',
				maxSelectItemCount : 9, //最多能选择几个人
				
				currentGroupMemberList : [], // 当前群成员列表
				dataList : [],
				
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无好友~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					showView : false,
					// 是否显示内容
					showContent: false,
				},
				
				groupInfo : {
					id : '',
					holder : '',
					name : ''
				}
			}
		},
		onLoad(options) {
			this.showType = options.type;
			this.groupInfo.id = options.groupid;
			
			this.initLoadData();
		},
		onNavigationBarButtonTap() {
			this.addMembers();
		},
		methods: {
			
			initLoadData()
			{
				let that = this;
				GroupCMDManager.refreshGroupInfo(false, that.groupInfo.id, (isCache, groupInfo) => {
					that.groupInfo = groupInfo;
					GroupCMDManager.refreshMemberList(false, this.groupInfo.id, (isCache, dataList) => {
						
						that.currentGroupMemberList = dataList;
						
						let userList = FriendCMDManager.getFriendList();
						
						let dataArray = [];
						for(let i in userList)
						{
							let item = userList[i];
							item.checked = false;
							
							if(StringUtils.isEqual(item.username, groupInfo.holder))
							{
								continue;
							}
							let exist = false;
							for(let j in dataList)
							{
								let groupRelationItem = dataList[j];
								if(StringUtils.isEqual(groupRelationItem.username, item.username))
								{
									exist = true;
									break;
								}
							}
							if(!exist)
							{
								dataArray.push(item);
							}
						}
						that.dataList = dataArray;
					})
				});
			},
			
			addMembers()
			{
				let addMemberList = [];
				for(let i in this.dataList)
				{
					let item = this.dataList[i];
					if(item.checked)
					{
						addMemberList.push(item.username);
					}
				}
				let addMemberListSize = addMemberList.length;
				if(addMemberListSize <= 0)
				{
					ToastUtils.showText("请选择要添加的群成员!", null);
					return;
				}
				
				//return;
				ToastUtils.showLoading("正在添加群成员...");
				GroupApi.inviteMembers(this.groupInfo.id, addMemberList,
				(data) => 
				{
					GroupCMDManager.refreshGroupInfo(true, this.groupInfo.id, (isCache, groupInfo) => {
						//console.log("refresh group info for add : ", isCache, groupInfo);
						GroupCMDManager.refreshMemberList(true, this.groupInfo.id, null);
						if(!isCache)
						{
							uni.navigateBack();
						}
					});
				},null);
				
			},
			
			handleTitle(item) 
			{
				let userInfo = UserManager.getUserInfo();
				let title = item.username;
				if(!StringUtils.isEmpty(item.alias))
				{
					title = item.alias;
				}
				else if(!StringUtils.isEmpty(item.nickname))
				{
					title = item.nickname;
				}
				return title;
			},
			//////////////////////////////////////////////////////
			onClickItemList(item)
			{
				let currentSelectCount = 0;
				//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
				let len = this.dataList.length;
				for(let i = 0; i < len; i ++)
				{
					let item = this.dataList[i];
					if(item.checked)
					{
						currentSelectCount ++;
					}
				}
				if(this.maxSelectItemCount <= currentSelectCount)
				{
					ToastUtils.showText("最多只能选择" + this.maxSelectItemCount + "人!")
					return;
				}
				this.$set(item,'checked', !item.checked)
			},
			
		}
	}
</script>

<style>
	checkbox{
		display: flex;
	}
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
</style>
