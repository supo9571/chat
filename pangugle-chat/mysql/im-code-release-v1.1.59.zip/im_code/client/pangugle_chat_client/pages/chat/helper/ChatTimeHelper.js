
const DAY_TIMESTAMP = 86400000;

const ChatTimeHelper = {
	
	/**
	 * 一天当中时间段别名
	 * 凌晨[0-6], 早上=[6-11], 中午=[11-13], 下午=[13-18], 晚上=[18-24]
	 * @param {Object} hour
	 */
	getDaySliceAlias(hour)
	{
		if(hour < 6) return "凌晨";
		else if(hour < 11) return "早上";
		else if(hour < 13) return "中午";
		else if(hour < 18) return "下午";
		else return "晚上";
	},
	
	getTimeValue(timeStamp)
	{
		
		let nowDate = new Date();
		let oldDate = new Date(timeStamp);
		
		let daySliceAlias = this.getDaySliceAlias(oldDate.getHours());
		//
		//return nowDate.getFullYear() + "年" + (nowDate.getMonth() + 1) + "月" + nowDate.getDate() + "日";
		
		// 今天=[早上11:28 | 下午5:40] 
		if(nowDate.getYear() == oldDate.getYear() && 
		   nowDate.getMonth() == oldDate.getMonth() &&
		   nowDate.getDate() == oldDate.getDate())
		{
			return daySliceAlias + " " + oldDate.getHours() + ":" + oldDate.getMinutes();
		}
		// 昨天=[昨天11:33]
		let yesterday = new Date(nowDate.getTime() - DAY_TIMESTAMP);
		if(yesterday.getYear() == oldDate.getYear() &&
		   yesterday.getMonth() == oldDate.getMonth() &&
		   yesterday.getDate() == oldDate.getDate())
		{
			return "昨天 " + oldDate.getHours() + ":" + oldDate.getMinutes();
		}
		//  同一年内 [10月12日 中午12:41]
		if(nowDate.getYear() == oldDate.getYear())
		{
			return (oldDate.getMonth() + 1) + "月" + oldDate.getDate() + "日";
		}
		// [2019年10月12日 中午12:41]
		else 
		{
			return oldDate.getFullYear() + "年" + (oldDate.getMonth() + 1) + "月" + oldDate.getDate() + "日";
		}
	},
	
	convertSimpleValue(timeStamp)
	{
		
		let nowDate = new Date();
		let oldDate = new Date(timeStamp);
		
		let daySliceAlias = this.getDaySliceAlias(oldDate.getHours());
		
		// 今天=[早上11:28 | 下午5:40] 
		if(nowDate.getYear() == oldDate.getYear() && 
		   nowDate.getMonth() == oldDate.getMonth() &&
		   nowDate.getDate() == oldDate.getDate())
		{
			return daySliceAlias + " " + oldDate.getHours() + ":" + oldDate.getMinutes();
		}
		// 昨天=[昨天11:33]
		let yesterday = new Date(nowDate.getTime() - DAY_TIMESTAMP);
		if(yesterday.getYear() == oldDate.getYear() &&
		   yesterday.getMonth() == oldDate.getMonth() &&
		   yesterday.getDate() == oldDate.getDate())
		{
			return "昨天 " + oldDate.getHours() + ":" + oldDate.getMinutes();
		}
		//  同一年内 [10月12日 中午12:41]
		if(nowDate.getYear() == oldDate.getYear())
		{
			return nowDate.getMonth() + "月" + nowDate.getDate() + " " + oldDate.getHours() + ":" + oldDate.getMinutes();
		}
		// [2019年10月12日 中午12:41]
		else 
		{
			return nowDate.getYear() + "年" +nowDate.getMonth() + "月" + nowDate.getDate() + " " + daySliceAlias + oldDate.getHours() + ":" + oldDate.getMinutes();
		}
	},
}


export default ChatTimeHelper