<template>
	
	<view>
		<view class="uni-list">
			<view class="uni-list-cell" 
				hover-class="uni-list-cell-hover"  
				v-for="(item, key) in dataList" :key="key"
				@tap="onClickItemList(item)">
				<view class="uni-media-list ">
					<checkbox :disabled="true" :checked="item.checked" />
					
					<pg-avatar class="uni-media-list-logo" :dataList="[item.userAvatar]">
					</pg-avatar>
					
					<view class="uni-media-list-body ">
						<view class="uni-media-list-text-top uni-ellipsis">{{handleTitle(item)}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<pg-modal :show="removeAlert.show"
			@click="removeMembers"
			content="确定删除?">
		</pg-modal>
	</view>
</template>
<script>
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import pgFab from "@/components/pg-fab/pg-fab.vue"
	import pgAvatar from '@/components/pg-avatar/pg-avatar.vue'
	import pgmodal from "@/components/pg-modal/modal.vue"
	
	import StringUtils from "@/pages/framework/utils/StringUtils.js"
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	
	import GroupApi from "@/pages/chat/service/GroupApi.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	/**
	 * 消息转发器
	 */
	export default {
		components: {
			uniLoadMore,
			uniList,
			uniListItem,
			uniPopup,
			pgFab,
			pgAvatar,
			'pg-modal' : pgmodal,
		},
		data() {
			return {
				mCurrentSelectStatus : '',
				maxSelectItemCount : 9, //最多能选择几个人
				
				dataList : [],
				mAdminList : [], //
				emptySdk : {
					skyDesc : {
						// 是否显示返回
						// isBack:true,
						// 是否显示加载(加载和返回不建议同时显示)
						// isLoad: true,
						// 页面背景颜色
						bgColor: '#eee',
						// 为空格则不显示该文字
						Desc: '暂无好友~!',
						// 字体以及字体图标颜色
						iconColor: '#000000',
						// 字体图标(可更改iconfont.css，进行覆盖)
						iconName: 'icon-icon-test',
						// 返回按钮颜色/重新按钮颜色,加载字体默认白色
						// btnColor:'#ff0000',
						// 页面高度
						height: '100%',
						// 页面宽度
						width: '100%',
						// 字体图标大小
						fontSize: '5em'
					},
					showView : false,
					// 是否显示内容
					showContent: false,
				},
				
				showType : 'list', // list, add, remove
				groupInfo : {
					id : '',
					holder : '',
					name : ''
				},
				
				removeAlert: {
					show : false
				}
			}
		},
		onLoad(options) {
			this.showType = options.type;
			this.groupInfo.id = options.groupid;
		},
		onShow() {
			this.loadMemberList(false);
		},
		onNavigationBarButtonTap(e) {
			this.removeAlert.show = true;
		},
		methods: {
			
			loadMemberList(refresh)
			{
				let that = this;
				GroupCMDManager.refreshGroupInfo(false, that.groupInfo.id, (isCache, groupInfo) => {
					that.groupInfo = groupInfo;
					//console.log(groupInfo);
					
					this.mAdminList = GroupCMDManager.getAdminList(that.groupInfo.id);
					
					GroupCMDManager.refreshMemberList(refresh, this.groupInfo.id, (isCache, dataList) => {
						let dataArray = [];
						for(let i in dataList)
						{
							let item = dataList[i];
							item.checked = false;
							
							if(StringUtils.isEqual(item.username, groupInfo.holder))
							{
								continue;
							}
							if(this.isAdmin(item.username))
							{
								continue;
							}
							dataArray.push(item);
						}
						that.dataList = dataArray;
						uni.stopPullDownRefresh();
					})
				});
			},
			
			removeMembers(event)
			{
				this.removeAlert.show = false;
				if(event.index == 0)
				{
					return;
				}
				let removeMemberList = [];
				for(let i in this.dataList)
				{
					let item = this.dataList[i];
					if(item.checked)
					{
						removeMemberList.push(item.username);
					}
				}
				if(removeMemberList.length <= 0)
				{
					ToastUtils.showText("请选择要移除的群成员!", null);
					return;
				}
				
				//return;
				ToastUtils.showLoading("正在移除群成员...");
				GroupApi.removeMembers(this.groupInfo.id, removeMemberList, 
				(data) => 
				{
					GroupCMDManager.refreshGroupInfo(true, this.groupInfo.id, (isCache, groupInfo) => {
						//console.log("refresh group info : ", isCache, groupInfo);
						if(!isCache)
						{
							GroupCMDManager.refreshMemberList(true, this.groupInfo.id, null);
							uni.navigateBack();
						}
					});
				},null);
				
			},
			
			handleTitle(item) 
			{
				let userInfo = UserManager.getUserInfo();
				let title = item.username;
				if(!StringUtils.isEmpty(item.groupNickname))
				{
					title = item.groupNickname;
				}
				else if(!StringUtils.isEmpty(item.userNickname))
				{
					title = item.userNickname;
				}
				if(StringUtils.isEqual(this.groupInfo.holder, item.username))
				{
					title += " (群主)";
				}
				else if(StringUtils.isEqual(userInfo.username, item.username))
				{
					title += " (我)";
				}
				return title;
			},
			//////////////////////////////////////////////////////
			onClickItemList(item)
			{
				let currentSelectCount = 0;
				//ToastUtils.showText("dfasdfafdfja;sdjfa;lsdjf;lask")
				let len = this.dataList.length;
				for(let i = 0; i < len; i ++)
				{
					let item = this.dataList[i];
					if(item.checked)
					{
						currentSelectCount ++;
					}
				}
				if(this.maxSelectItemCount <= currentSelectCount)
				{
					ToastUtils.showText("最多只能选择" + this.maxSelectItemCount + "人!")
					return;
				}
				this.$set(item,'checked', !item.checked)
			},
			
			isAdmin(member)
			{
				var len = this.mAdminList.length;
				for(var i = 0; i < len; i ++)
				{
					var adminUsername = this.mAdminList[i];
					if(adminUsername == member)
					{
						return true;
					}
				}
				return false;
			}
			
		}
	}
</script>

<style>
	checkbox{
		display: flex;
	}
	.uni-media-list-body{
		align-items:center; 
		flex-direction:row;
	}
</style>
