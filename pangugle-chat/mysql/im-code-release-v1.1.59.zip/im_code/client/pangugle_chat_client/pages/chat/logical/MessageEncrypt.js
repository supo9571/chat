import AES128Utils from "@/pages/framework/utils/AES128Utils.js"

const AES_KEY = '*^jsdfa#1!jsd3j7';


const MessageEncrypt = {
	
	encrypt(msg)
	{
		return AES128Utils.encrypt(msg, AES_KEY);
	},
	
	decrypt(msg)
	{
		return AES128Utils.decrypt(msg, AES_KEY);
	}
	
}


export default MessageEncrypt