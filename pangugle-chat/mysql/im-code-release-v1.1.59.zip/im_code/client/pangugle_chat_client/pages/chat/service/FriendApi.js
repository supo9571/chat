import ApiRequest from '@/pages/framework/http/ApiRequest.js'
import CachePolicy from "@/pages/framework/http/CachePolicy.js"

import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import MessageHelper from "@/pages/chat/helper/MessageHelper.js"

import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"

import UserDefHelper from "@/pages/user/helper/UserDefHelper.js"

const FriendApi = {
	
	/**
	 * 获取好友列表
	 * @param {Object} refresh
	 * @param {Object} success
	 * @param {Object} failure
	 */
	queryFriendList(refresh, success, failure)
	{
		let params = {}
		//console.log("=========queryFriendList");
		let url = '/im/friendApi/queryFriendList';
		let cachePolicy = CachePolicy.HTTP_CACHE_POLICY_LOCAL_OR_REMOTE;
		if(refresh)
		{
			cachePolicy = CachePolicy.HTTP_CACHE_POLICY_LOCAL_AND_REMOTE;
		}
		ApiRequest.getCacheRequest().post(url, params, cachePolicy,(isCache, data) => 
		{
			success(isCache, data.list);
		}, failure);
	},
	
	/**
	 * 获取待确认好友列表
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	queryUnConfirmList(page, success, failure)
	{
		let params = {
			page : page,
			status : 'unconfirm'
		}
		let url = '/im/friendApi/queryUnConfirmList';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	/**
	 * 获取自己是否被对方拉黑
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	getBlackSelfStatus(friendUsername, success, failure)
	{
		let params = {
			friendUsername :friendUsername
		};
		let url = '/im/friendApi/getBlackSelfStatus';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success(data);
		}, failure);
	},
	
	/**
	 * 确认好友关系
	 * @param {Object} page
	 * @param {Object} success
	 * @param {Object} failure
	 */
	enableFriend(friendUsername, success, failure)
	{
		let params = {
			'friendUsername' : friendUsername
		}
		let url = '/im/friendApi/enableFriend';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, failure);
	},
	
	/**
	 * 添加好友
	 * @param {Object} friendUsername
	 * @param {Object} remark
	 * @param {Object} success
	 * @param {Object} failure
	 */
	addFriend(friendUsername, remark, success, failure)
	{
		let params = {
			'friendUsername' : friendUsername,
			remark, remark
		}
		//console.log(params);
		let url = '/im/friendApi/addFriend';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, failure);
	},
	
	/**
	 * 删除好友
	 * @param {Object} friendUsername
	 * @param {Object} success
	 * @param {Object} failure
	 */
	deleteFriend(friendUsername, success, failure)
	{
		let params = {
			'friendUsername' : friendUsername
		}
		console.log(params);
		let url = '/im/friendApi/deleteFriend';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			FriendCMDManager.deleteFriend(friendUsername);
			success();
		}, failure);
	},
	updateBlackFriend(friendUsername, black, success, failure)
	{
		let params = {
			'friendUsername' : friendUsername,
			'black' : black
		}
		//console.log(params);
		let url = '/im/friendApi/updateFriendInfoBlack';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, failure);
	},
	
	getFriendInfo(friendUsername, success, failure)
	{
		let params = {"friendUsername" : friendUsername};
		
		ApiRequest.post('/im/friendApi/getFriendInfo', params, 
		(isCache, data) =>
		{
			data.avatar = UserDefHelper.getAvatar(data.avatar);
			data.nickname = UserDefHelper.getNickname(data.nickname);
			success(data);
		}, failure);
	},
	
	updateFriendInfo(friendUsername, alias, mobile, remark, success, failure)
	{
		let params = {
			"friendUsername" : friendUsername,
			"alias" : alias,
			"mobile" : mobile,
			"remark" : remark
		};
		
		ApiRequest.post('/im/friendApi/updateFriendInfo', params, 
		(isCache, data) =>
		{
			var friendInfo = FriendInfoManager.getFriendInfo(friendUsername);
			friendInfo.alias = alias;
			friendInfo.mobile = mobile;
			friendInfo.remark = remark;
			FriendInfoManager.saveFriendInfo(friendInfo);
			
			success();
		}, failure);
	},
	
}

export default FriendApi