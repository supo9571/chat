


const BasicMsgType = {
	
	REVOKE : "revoke", //"撤回消息"),
	
	TEXT : 	"text", //"文本消息"),
	IMAGE : "image", //"图片消息"),
	VOICE : "voice", //"语音消息"),
	FILE : 	"file", //"文件消息"),
	SHOURT_VIDEO : "short_video", //"短视频"),
	POSITION : "position", //"位置"),
	SHARE_POSITION : "share_position", //"实时共享位置"),
	SHARE_POSITION_UPDATE : "share_position_update", //"实时共享位置更新, 位置信息不记录"),
	CARD : "card", //"名片消息");
	RED_PACKET : "red_packet",
	
	/**
	 * 验证消息体是不是此类型
	 * @param {Object} msgType
	 * @param {Object} msgBody
	 */
	equals(msgType, msgBody)
	{
		let type = msgBody.msgType;
		return type == msgType;
	}
}

export default BasicMsgType