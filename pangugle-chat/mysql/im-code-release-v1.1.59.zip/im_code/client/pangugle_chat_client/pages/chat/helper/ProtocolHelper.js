// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import UUIDUtils from '@/pages/framework/utils/UUIDUtils.js'

import ChatTextHelper from "@/pages/chat/helper/ChatTextHelper.js"

import UserManager from '@/pages/user/logical/UserManager.js'
	
/**
 */
const ProtocolHelper = {
	
	getData()
	{
		let userInfo = UserManager.getUserInfo();
		let data = {
			'belongType' : 'user'
		}
		return data;
	},
	
	body(targetid, event, msgType, data)
	{
		let userInfo = UserManager.getUserInfo();
		let json = {
			'id' : UUIDUtils.generate(),
			'fromUserid' :userInfo.username,
			'targetid' : targetid,
			'event': event,
			'msgType' : msgType,
			'data' : data,
			'time' : new Date().getTime(),
			'local' : false, // 本地消息只使用在是否走网络通道,其它不做使用
			'optType' : 'new', // [消息操作类型 new=新创建|resend=重新发送]
		};
		return json;
	},
	
	text(targetid, event, content, showText, atUserArray = null)
	{
		let data = this.getData();
		data.content = content;
		data.showText = showText;
		if(atUserArray && atUserArray.length > 0)
		{
			data.at = atUserArray;
		}
		let body = this.body(targetid, event, BasicMsgType.TEXT, data);
		return body;
	},
	
	image(targetid, event, srcUrl, compressUrl, w, h)
	{
		let data = this.getData();
		data.url = compressUrl;
		data.content = compressUrl;
		data.src_url = srcUrl;
		data.width = w;
		data.height = h;
		data.convText = '[图片]';
		
		let body = this.body(targetid, event, BasicMsgType.IMAGE, data);
		return body;
	},
	
	/**
	 * @param {Object} targetid
	 * @param {Object} event
	 * @param {Object} url 音频地址
	 * @param {Object} playTime 音频播放时长
	 */
	voice(targetid, event, url, playTime)
	{
		let data = this.getData();
		data.convText = '[语音]';
		data.url  = url;
		//data.content = url;
		data.playTime = playTime;
		let body = this.body(targetid, event, BasicMsgType.VOICE, data);
		return body;
	},
	
	/**
	 * @param {Object} targetid
	 * @param {Object} event
	 * @param {Object} friendUsername 好友用户名
	 */
	card(targetid, event, friendUsername, nickname, avatar)
	{
		let data = this.getData();
		data.convText = '[名片]';
		data.username = friendUsername;
		data.nickname = nickname;
		data.avatar = avatar;
		let body = this.body(targetid, event, BasicMsgType.CARD, data);
		return body;
	},
	
	/**
	 * 位置消息
	 * @param {Object} targetid
	 * @param {Object} event
	 * @param {Object} addr 地址信息
	 * @param {Object} longitude 经度
	 * @param {Object} latitude 纬度
	 */
	position(targetid, event, addr, longitude, latitude)
	{
		let data = this.getData();
		data.convText = '[位置]';
		data.addr = addr;
		data.longitude = longitude;
		data.latitude = latitude;
		let body = this.body(targetid, event, BasicMsgType.POSITION, data);
		return body;
	},
	
	/**
	 * 共享位置消息
	 * @param {Object} targetid
	 * @param {Object} event
	 */
	sharedPosition(targetid, event)
	{
		let data = this.getData();
		data.content = '[我发起了共享位置]';
		data.convText = '[我发起了共享位置]';
		let body = this.body(targetid, event, BasicMsgType.SHARE_POSITION, '我发起了共享位置');
		return body;
	},
	
	revoke(dataJson)
	{
		delete dataJson.status;
		let data = {
			'convText' : '撤回了一条消息',
			'belongType' : 'system'
		}
		dataJson.data = data;
		dataJson.msgType = BasicMsgType.REVOKE;
		return dataJson;
	},
	
	localReject(targetid, event)
	{
		let userInfo = UserManager.getUserInfo();
		
		let data = {
			'convText' : '对方拒绝你的消息',
			'belongType' : 'system',
			'content' : '对方拒绝你的消息'
		}
		let body = {
			'id' : UUIDUtils.generate(),
			'fromUserid' :userInfo.username,
			'targetid' : targetid,
			'event': event,
			'msgType' : LocalMsgType.REJECT,
			'data' : data,
			'local' : true,
			'optType' : 'new',
		};
		return body;
	},
	
	localVerifyFriend(targetid, event)
	{
		let userInfo = UserManager.getUserInfo();
		
		let data = {
			'convText' : '你发起了好友验证',
			'belongType' : 'system'
		}
		
		let body = {
			'id' : UUIDUtils.generate(),
			'fromUserid' :userInfo.username,
			'targetid' : targetid,
			'event': event,
			'msgType' : LocalMsgType.VERIFY_FRIEND,
			'data' : data,
			'local' : true,
			'optType' : 'new',
		};
		return body;
	},
	
	/**
	 * 本地时间
	 * @param {Object} targetid
	 * @param {Object} event
	 */
	localTime(date)
	{
		let body = {
			'id' : UUIDUtils.generate(),
			'msgType' : LocalMsgType.TIME,
			'time' : date.getTime(),
			'local' : true,
			'optType' : 'new',
			'data' : {
				'belongType' : 'system'
			}
		};
		return body;
	},
	
	/**
	 * 本地提示消息
	 * @param {Object} targetid
	 * @param {Object} event
	 * @param {Object} content
	 */
	localTextTips(targetid, event, content)
	{
		let data = this.getData();
		data.content = content;
		data.convText = content;
		data.belongType = 'system';
		
		let body = this.body(targetid, event, LocalMsgType.TEXT, data);
		body.local = true;
		return body;
	},
	
	//获取消息体文本内容
	getProtocolText(dataJson)
	{
		try{
			let content = dataJson.data.content;
			if(typeof(content) == 'string' && !StringUtils.isEmpty(content))
			{
				return content;
			}
		}catch(e){
		}
		return '';
	},
	
	/**
	 * 是不是用户自己发送的消息
	 * @param {Object} dataJson
	 */
	isSelfProtocol(dataJson)
	{
		let fromUserid = dataJson.fromUserid;
		let selftUsername = UserManager.getUserInfo().username;
		return StringUtils.isEqual(selftUsername, fromUserid);
	}
	
}

export default ProtocolHelper