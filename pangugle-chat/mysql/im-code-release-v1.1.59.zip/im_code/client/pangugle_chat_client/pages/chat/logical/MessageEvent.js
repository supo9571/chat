const MessageEvent = {
	LOGIN : "login", //"登陆相关"),
	FRIEND : "friend", //"好友操作相关"),
	SINGLE : "single", //"单聊"),
	GROUP : "group", //"群聊"),
	GROUP_OPT : "group_opt", //"群聊"),
	
	KEFU : "kefu", //"群聊"),
}

export default MessageEvent