// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import ToastUtils from '@/pages/framework/utils/ToastUtils.js'


import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"

//
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"

import UserManager from "@/pages/user/logical/UserManager.js"

import JsonUtils from "@/pages/framework/utils/JsonUtils.js"

/**
 * 聊天相关页面导航帮助类
 */

const ChatJumpHelper = {
	
	jumpToAddFriend()
	{
		uni.navigateTo({
			url: '/pages/chat/view/SearchUser'
		})
	},
	
	jumpToUserBasicInfo(username)
	{
		try{
			let useNavigateTo = true;
			let friend = {
				username : username
			}
			
			let pages = getCurrentPages();
			let len = pages.length;
			if(pages != null && len > 1)
			{
				let singChatRoute = "pages/chat/view/SingleChat";
				for(let i in pages)
				{
					let page = pages[i];
					if(StringUtils.isEqual(singChatRoute, page.route))
					{
						useNavigateTo = false;
						break;
					}
				}
			}
			if(useNavigateTo)
			{
				uni.navigateTo({
					url: '/pages/chat/view/UserBasicInfo?data=' + encodeURIComponent(JSON.stringify(friend))
				})
			}
			else
			{
				// 如果一开始在singlechat刷新会报异常 Not Found：Page[xxx]
				uni.redirectTo({
					url: '/pages/chat/view/UserBasicInfo?data=' + encodeURIComponent(JSON.stringify(friend))
				})
			}
		}catch(e){
			console.log("handle pages error:", e);
		}
		
	},
	
	jumpToSingleChat(username)
	{
		try{
			let pages = getCurrentPages();
			if(pages != null && pages.length > 3)
			{
				uni.reLaunch({
					url: '/pages/chat/view/SingleChat?friendUsername=' + username,
				})
			}
			else
			{
				uni.navigateTo({
					url: '/pages/chat/view/SingleChat?friendUsername=' + username,
				})
			}
		}catch(e){
			console.log("jump to single chat error:", e);
		}
	},
	
	jumpToGroupCreate()
	{
		uni.navigateTo({
			url: '/pages/chat/view/GroupCreate'
		})
	},
	
	jumpToGroupChat(groupid, isRedirectTo=false)
	{
		GroupCMDManager.refreshGroupInfo(false, groupid, (isCache, groupInfo) => {
			if(groupInfo != null)
			{
				if(isRedirectTo)
				{
					uni.redirectTo({
						url: '/pages/chat/view/GroupChat?groupid=' + groupid,
					})
				}
				else
				{
					uni.navigateTo({
						url: '/pages/chat/view/GroupChat?groupid=' + groupid,
					})
				}
				
				// let userInfo = UserManager.getUserInfo();
				// GroupCMDManager.refreshGroupRelation(false, groupid, userInfo.username, (isCache, data) => {
				// 	//console.log(data);
				// 	if(data != null)
				// 	{
				// 		uni.navigateTo({
				// 			url: '/pages/chat/view/GroupChat?groupid=' + groupid,
				// 		})
				// 	}
				// 	else
				// 	{
				// 		// 刷新下聊天列表和群聊列表,可以被移除群了
				// 		ToastUtils.showText("你未加入或被移出群!");
				// 	}
				// });
			}
			else
			{
				ToastUtils.showText("群组信息获取失败!");
			}
		});
	},
	
	jumpToGroupInfo(groupid)
	{
		uni.navigateTo({
			url: '/pages/chat/view/GroupInfo?groupid=' + groupid
		})
	},
	
	jumpToCreateGroupQrcode(groupid)
	{
		uni.navigateTo({
			url: '/pages/chat/view/GroupCreateQrcode?groupid=' + groupid
		})
	},
	
	jumpToJoinGroup(groupInfo)
	{
		//console.log(groupInfo);
		var groupid = groupInfo.groupid;
		if(GroupCMDManager.isJoinGroup(groupid))
		{
			this.jumpToGroupChat(groupid);
			return;
		}
		let json = JsonUtils.toJsonString(groupInfo);
		var data = encodeURIComponent(json);
		uni.navigateTo({
			url: '/pages/chat/view/JoinGroup?data=' + data
		})
	},
	
	/**
	 * 群成员查看
	 * @param {Object} groupid
	 * @param {Object} type => [look-查看|at-@人]
	 */
	jumpToGroupMemberList(groupid, type='look')
	{
		if(StringUtils.isEmpty(groupid))
		{
			return;
		}
		uni.navigateTo({
			url: '/pages/chat/view/GroupMemberList?groupid=' + groupid + "&type=" + type
		})
	},
	
	/**
	 * 群成员删除
	 * @param {Object} groupid
	 */
	jumpToGroupMemberRemove(groupid)
	{
		if(StringUtils.isEmpty(groupid))
		{
			return;
		}
		uni.navigateTo({
			url: '/pages/chat/view/GroupMemberRemove?groupid=' + groupid
		})
	},
	
	/**
	 * 群成员添加
	 * @param {Object} groupid
	 */
	jumpToGroupMemberAdd(groupid)
	{
		if(StringUtils.isEmpty(groupid))
		{
			return;
		}
		uni.navigateTo({
			url: '/pages/chat/view/GroupMemberAdd?groupid=' + groupid
		})
	},
	
	jumpToShareCard(msgBody)
	{
		if(!(StringUtils.isEqual(BasicMsgType.CARD, msgBody.msgType)))
		{
			// 消息不支持
			console.log("消息类型只支持card");
			return;
		}
		uni.navigateTo({
			url: '/pages/chat/view/ShareCard?data=' + JSON.stringify(msgBody),
		})
	},
	
	jumpToShareToConversation(msgBody)
	{
		//console.log("jumpToShareToConversation=======", msgBody);
		if(!(StringUtils.isEqual(BasicMsgType.TEXT, msgBody.msgType) || 
			StringUtils.isEqual(BasicMsgType.IMAGE, msgBody.msgType)))
		{
			// 消息不支持
			console.log("消息类型只支持text, image");
			return;
		}
		let dataString = encodeURIComponent(JSON.stringify(msgBody));
		uni.navigateTo({
			url: '/pages/chat/view/ShareToConversation?data=' + dataString,
		})
	},
	
	jumpToShareToFriend(msgBody)
	{
		if(!(StringUtils.isEqual(BasicMsgType.TEXT, msgBody.msgType) || 
			StringUtils.isEqual(BasicMsgType.IMAGE, msgBody.msgType)))
		{
			// 消息不支持
			console.log("消息类型只支持text, image");
			return;
		}
		let dataString = encodeURIComponent(JSON.stringify(msgBody));
		uni.navigateTo({
			url: '/pages/chat/view/ShareToFriend?data=' + dataString,
		})
	},
	
	jumpToShareToGroup(msgBody)
	{
		if(!(StringUtils.isEqual(BasicMsgType.TEXT, msgBody.msgType) || 
			StringUtils.isEqual(BasicMsgType.IMAGE, msgBody.msgType)))
		{
			// 消息不支持
			console.log("消息类型只支持text, image");
			return;
		}
		let dataString = encodeURIComponent(JSON.stringify(msgBody));
		uni.navigateTo({
			url: '/pages/chat/view/ShareToGroup?data=' + dataString,
		})
	},
	
	jumpToModifyGroupInfo(groupid, modifyType)
	{
		if(StringUtils.isEmpty(groupid) || StringUtils.isEmpty(modifyType))
		{
			// 消息不支持
			console.log("参数不能为空");
			return;
		}
		let data = {
			groupid,
			modifyType
		}
		uni.navigateTo({
			url: '/pages/chat/view/ModifyGroupInfo?data=' + JSON.stringify(data),
		})
	}
	
	
	
}



export default ChatJumpHelper