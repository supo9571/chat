
const LocalMsgType = {
	
	VERIFY_FRIEND : "local_verify_friend", // 本地消息类型，还不是好友关系, 好友关系被删除
	TEXT : "local_text", // 提示文字信息
	TIME : "local_time", // 显示时间-》
	DELETE : "local_delete", // 删除消息
	
	/**
	 * 验证消息体是不是此类型
	 * @param {Object} msgType
	 * @param {Object} msgBody
	 */
	equals(msgType, msgBody)
	{
		let type = msgBody.msgType;
		return type == msgType;
	}
}

export default LocalMsgType