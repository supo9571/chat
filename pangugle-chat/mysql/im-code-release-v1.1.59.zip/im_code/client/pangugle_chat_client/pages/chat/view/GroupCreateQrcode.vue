<template>
	
	<view class="mgQrcode-box">
		
		<view class="mgQrcode">
			
			<tki-qrcode ref="qrcode"
					:val="myQrcodeConfig.val"
					:size="myQrcodeConfig.size" 
					:onval="myQrcodeConfig.onval" 
					:loadMake="myQrcodeConfig.loadMake" 
					:usingComponents="true" />
			
			<!-- <image :src="myQrcodeValue"></image> -->
			<p>该二维码5天内有效, 重新进入将更新</p>
		</view>
		
		
	</view>
		
		

</template>

<script>
	import QRCode from "@/pages/framework/qrcode/wxqrcode.js"
	import GroupApi from "@/pages/chat/service/GroupApi.js"
	import QrcodeManager from "@/pages/main/logical/QrcodeManager.js"
	
	import tkiQrcode from "@/pages/framework/qrcode/tki-qrcode.vue"
	
	export default {
		components: {
			tkiQrcode
		},
		data() {
			return {
				qrcode : "qrcode",
				myQrcodeConfig : {
					val: '', // 要生成的二维码值
					size: 220, // 二维码大小
					unit: 'px', // 单位
					background: '#b4e9e2', // 背景色
					foreground: '#309286', // 前景色
					pdground: '#32dbc6', // 角标色
					icon: '', // 二维码图标
					iconsize: 40, // 二维码图标大小
					onval: true, // val值变化时自动重新生成二维码
					loadMake: true, // 组件加载完成后自动生成二维码
				},
				
				myQrcodeValue : ''
			}
		},
		onLoad(options) {
			var self = this;
			var groupid = options.groupid;
			GroupApi.createGroupQrcodeInfo(groupid, (groupInfo) => {
				var result = QrcodeManager.generateGroupQrcode(groupInfo);
				self.myQrcodeConfig.val = result;
			}, null);
		},
		methods: {
			onCreateQrCodeSuccess(rs)
			{
				this.myQrcodeValue = rs;
			}
		}
	}
</script>

<style>
	page{
		height: 100%;
	}
	.mgQrcode-box{
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.mgQrcode{
		text-align: center;
		background-color: #fff;
		padding: 30px 30px 20px 30px;border-radius: 2px;
		max-width: 98%;
	}
	.mgQrcode image{padding: 0;margin: 0;}
	p{
		font-size: 12px;
		color: #99999;
		margin-top: 15px;
	}
</style>
