
// framework
import Cache from '@/pages/framework/cache/Cache.js'
import StringUtils from '@/pages/framework/utils/StringUtils.js'


import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js" 

import UserManager from '@/pages/user/logical/UserManager.js'
import UserApi from '@/pages/user/service/UserApi.js'

import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"

import KefuInfoManager from "@/pages/kefu/logical/KefuInfoManager.js"

const CACHE_KEY = "chat_conversation_list"

// 最大记录大小
const DEFAULT_MAX_SIZE = 100;

/**
 * 会话管理器
 */
class ConversationManager {
	
	constructor() {
	    this.dataArray = Cache.getValue(CACHE_KEY) || [];
		this.mChatHandler = {};
	}
	
	registerChatHandler(key, handler)
	{
		this.mChatHandler[key] = handler;
	}
	
	setUICallback(callback)
	{
		this.mUICallback = callback;
	}
	
	/**
	 * 添加会话
	 * @param {Object} id  会话id = (用户id | 群组id | ...)
	 * @param {Object} type 请查看 /pages/chat/manager/ConversationType.js
	 * @param {Object} title 会话标题，也可以表示为id的别名，如果没有这个，则显示id
	 * @param {Object} content
	 */
	handle(json, addBadge)
	{
		let userInfo = UserManager.getUserInfo();
		if(userInfo == null) {
			return;
		}
		
		let fromUserid = json.fromUserid; // 
		let targetid = json.targetid;
		let event = json.event;
		
		let self = this;
		
		// 单聊
		if(StringUtils.isEqual(MessageEvent.SINGLE, event))
		{
			let friendUsername = fromUserid;
			if(StringUtils.isEqual(userInfo.username, fromUserid))
			{
				friendUsername = targetid;
			}
			FriendInfoManager.refreshFriendInfo(false, friendUsername, (friendInfo) =>
			{
				let avatar = friendInfo.avatar;
				let title = friendInfo.username;
				if(!StringUtils.isEmpty(friendInfo.alias))
				{
					title = friendInfo.alias;
				}
				else if(!StringUtils.isEmpty(friendInfo.nickname))
				{
					title = friendInfo.nickname;
				}
				let avatarArray = [];
				avatarArray.push(avatar)
				self.add(json, title, avatarArray, addBadge);
			}, null);
		}
		// 群聊
		else if(StringUtils.isEqual(MessageEvent.GROUP, event))
		{
			//console.log("============conversation receiv = ", json);
			GroupCMDManager.refreshGroupInfo(false, targetid, (isCache, groupInfo) => 
			{
				if(groupInfo == null)
				{
					return;
				}
				let title = groupInfo.alias;
				if(!StringUtils.isEmpty(groupInfo.name))
				{
					title = groupInfo.name;
				}
				let avatarArray = groupInfo.icons.split(",");
				//console.log("avatar array : ", avatarArray, ",  groupInfo.icons = ", groupInfo.icons);
				self.add(json, title, avatarArray, addBadge);
			});
		}
		// 客服
		else if(StringUtils.isEqual(MessageEvent.KEFU, event))
		{
			let targetUsername = fromUserid;
			if(StringUtils.isEqual(userInfo.username, fromUserid))
			{
				targetUsername = targetid;
			}
			
			FriendInfoManager.refreshFriendInfo(false, targetUsername, (friendInfo) =>
			{
				let avatar = friendInfo.avatar;
				let title = friendInfo.username;
				if(!StringUtils.isEmpty(friendInfo.alias))
				{
					title = friendInfo.alias;
				}
				else if(!StringUtils.isEmpty(friendInfo.nickname))
				{
					title = friendInfo.nickname;
				}
				let avatarArray = [];
				avatarArray.push(avatar)
				self.add(json, title, avatarArray, addBadge);
				
				
			}, null);
			
			// UserApi.searchUserInfo(targetUsername, false, (dataUserInfo) => {
			// 	let avatarArray = [];
			// 	avatarArray.push(dataUserInfo.avatar)
			// 	self.add(json, dataUserInfo.nickname, avatarArray, addBadge);
			// });
		}
		else
		{
			console.log("有新的消息事件未处理......................");
			return;
		}
	}
	
	/**
	 * 添加会话
	 * @param {Object} json
	 * @param {Object} addBadge
	 */
	add(json, title, avatar, addBadge)
	{
		var id = json.id;
		var data = json.data;
		var fromUserid = json.fromUserid; // 
		var targetid = json.targetid;
		var event = json.event;
		var msgType = json.msgType;
		var time = json.time;
		var status = json.status ? true : false;
		
		
		var showAt = false;
		var content = '[新消息]';
		if(BasicMsgType.TEXT == msgType)
		{
			content = data.content;
			var atArray = json.data.at;
			var userInfo = UserManager.getUserInfo();
			if(atArray && atArray.length > 0)
			{
				for(var i in atArray)
				{
					var atMember = atArray[i];
					if(atMember == userInfo.username)
					{
						showAt = true;
						break;
					}
				}
			}
			//console.log("==========", atString.indexOf(userInfo.username));
			// if(atString && atString.text(userInfo.username))
			// {
			// 	showAt = true;
			// }
		}
		else if(LocalMsgType.DELETE == msgType)
		{
			content = "你删除了一条消息";
		}
		else if(!StringUtils.isEmpty(data.convText))
		{
			content = data.convText;
		}
		
		
		//console.log("===============add badge ==========");
		
		// 删除旧数据
		let model = this.remove(event, fromUserid, targetid);
		if(model)
		{
			model.title = title;
			model.avatar = avatar;
			model.content = content;
			model.time = time;
			model.badge = model.badge + 1;
			model.showAlert = addBadge;
			model.showAt = showAt;
		}
		else
		{
			// 此处的头像
			model = {
				'avatar' : avatar, // 默认为空
				'event': event,
				'fromUserid': fromUserid,
				'targetid': targetid,
				'title' : title,
				'content' : content,
				'time':time,
				'badge' : 1,
				'showAlert' : addBadge,
				'showAt' : showAt
			};
		}
		
		// 不添加addBadge, 则表示正在会话当中
		if(!addBadge)
		{
			model.badge = 0;
			model.showAlert = false;
		}
		
		// 向数组第一个位置添加元素
		let len = this.dataArray.unshift(model);
		
		// 删除最后一个元素
		if(len > DEFAULT_MAX_SIZE)
		{
			this.dataArray.pop();
		}
		
		// save
		Cache.setValue(CACHE_KEY, this.dataArray);
		
		this.reload();
	}
	
	/**
	 * 删除节点数据, 内部方法
	 * @param {Object} event
	 * @param {Object} fromUserid
	 */
	remove(event, fromUserid, targetid)
	{
		let data = null;
		let currentid = this.generateID(event, fromUserid, targetid);
		
		let len = this.dataArray.length;
		for(let i = 0; i < len; i ++)
		{
			let model = this.dataArray[i];
			let tmpId = this.generateID(model.event, model.fromUserid, model.targetid);
			if(StringUtils.isEqual(tmpId, currentid))
			{
				this.dataArray.splice(i, 1);
				data = model;
				break;
			}
		}
		return data;
	}
	
	removeItemWithID(event, fromUserid, targetid)
	{
		let data = null;
		
		let currentid = this.generateID(event, fromUserid, targetid);
		
		let len = this.dataArray.length;
		for(let i = 0; i < len; i ++)
		{
			let model = this.dataArray[i];
			let tmpId = this.generateID(model.event, model.fromUserid, model.targetid);
			if(StringUtils.isEqual(tmpId, currentid))
			{
				this.dataArray.splice(i, 1);
				data = model;
				break;
			}
		}
		
		// 删除聊天记录
		let handler = this.mChatHandler[event];
		if(handler && handler != null)
		{
			handler.deleteMessageList(event, fromUserid, targetid);
		}
		
		// save
		Cache.setValue(CACHE_KEY, this.dataArray);
		this.reload();
	}
	
	/**
	 * 外部方法，调用
	 * @param {Object} model dataArray 里面的数据模型
	 */
	removeItem(item)
	{
		let fromUserid = item.fromUserid; // 
		let targetid = item.targetid;
		let event = item.event;
		
		this.removeItemWithID(event, fromUserid, targetid);
	}
	
	/**
	 * 外部方法，调用
	 * @param {Object} model dataArray 里面的数据模型
	 */
	updateItem(item)
	{
		//console.log("=============");
		let fromUserid = item.fromUserid; // 
		let targetid = item.targetid;
		let event = item.event;
		
		let currentid = this.generateID(event, fromUserid, targetid);
		
		// delete item
		let len = this.dataArray.length;
		for(let i = 0; i < len; i ++)
		{
			let model = this.dataArray[i];
			let tmpId = this.generateID(model.event, model.fromUserid, model.targetid);
			if(StringUtils.isEqual(tmpId, currentid))
			{
				this.dataArray.splice(i, 1);
				break;
			}
		}
		
		// update item to first poc
		item.badge = 0;
		item.showAlert = false;
		item.showAt = false;
		this.dataArray.unshift(item);
		
		// save
		Cache.setValue(CACHE_KEY, this.dataArray);
		this.reload();
	}
	
	
	generateID(event, fromUserid, toUserid)
	{
		if(StringUtils.isEqual(event, MessageEvent.SINGLE))
		{
			// 自己在
			let username = UserManager.getUserInfo().username;
			if(StringUtils.isEqual(username, fromUserid))
			{
				return event + "_" + fromUserid + "_" + toUserid;
			}
			else
			{
				return event + "_" + toUserid + "_" + fromUserid;
			}
		}
		else if(StringUtils.isEqual(event, MessageEvent.KEFU))
		{
			// 自己在
			let username = UserManager.getUserInfo().username;
			if(StringUtils.isEqual(username, fromUserid))
			{
				return event + "_" + fromUserid + "_" + toUserid;
			}
			else
			{
				return event + "_" + toUserid + "_" + fromUserid;
			}
		}
		else if(StringUtils.isEqual(event, MessageEvent.GROUP))
		{
			return event + "_" + toUserid;
		}
		else
		{
			console.log("please handle conversation event for generate id ...");
		}
		
		
	}
	
	reload()
	{
		if(this.mUICallback)
		{
			this.mUICallback.onMessage(this.dataArray);
		}
	}
	
	getDataList()
	{
		return this.dataArray;
	}
	
	clear()
	{
		this.dataArray = [];
		Cache.setValue(CACHE_KEY, this.dataArray);
	}
	
}

const conversationIntance = new ConversationManager();

export default conversationIntance