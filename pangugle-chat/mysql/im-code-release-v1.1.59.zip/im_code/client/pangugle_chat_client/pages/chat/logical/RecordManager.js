// framework
import Cache from '@/pages/framework/cache/Cache.js'
import StringUtils from '@/pages/framework/utils/StringUtils.js'

import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"

import UserManager from '@/pages/user/logical/UserManager.js'


// 每个记录id最大记录大小, 不要太大，会影响性能问题, 主要看cell能不能复用,app 有list可以用,
const DEFAULT_MAX_RECORLD_SIZE = 300;

/**
 * 聊天记录管理器
 */
class RecordManager {
	
	constructor(event) {
		this.mevent = event;
		
	    this.mCurrentTargetCachekey = '';
		this.mCurrentTargetDataArray = null;
	}
	
	/**
	 * @param {Object} targetid 单聊表示好友用户名, 群聊表示群id
	 */
	setCurrentTargetid(targetid)
	{
		let userInfo = UserManager.getUserInfo();
		
		let fromUserid = userInfo.username;
		let cachekey = this.getCacheKey(this.mevent, fromUserid, targetid);
		
		if(!StringUtils.isEqual(cachekey, this.mCurrentTargetCachekey))
		{
			this.mCurrentTargetCachekey = cachekey;
			// 有一定机率发生覆盖
			this.mCurrentTargetDataArray = Cache.getValue(this.mCurrentTargetCachekey) || [];
		}
	}
	
	getDataArray(event, fromUserid, targetid)
	{
		let cachekey = this.getCacheKey(event, fromUserid, targetid);
		//console.log("cache-key = " + cachekey);
		if(cachekey == null)
		{
			console.log("un support from chat type for " + event);
			return [];
		}
		
		// 放在内存里，防止
		let dataArray = null;
		if(cachekey === this.mCurrentTargetCachekey)
		{
			dataArray = this.mCurrentTargetDataArray;
		}
		else
		{
			dataArray = Cache.getValue(cachekey) || [];
		}
		return dataArray;
	}
	
	updateRecod(jsonData)
	{
		//console.log("add record = ", jsonData);
		let event = jsonData.event;
		let fromUserid = jsonData.fromUserid; // 
		let targetid = jsonData.targetid;
		
		
		let cachekey = this.getCacheKey(event, fromUserid, targetid);
		//console.log("addRecord cache-key = " + cachekey, jsonData);
		if(cachekey == null)
		{
			console.log("un support from chat type for " + event, jsonData);
			return [];
		}
		
		// 放在内存里，防止
		let dataArray = this.getDataArray(event, fromUserid, targetid);
		
		let len = dataArray.length;
		
		// 索引从0 开始
		let index = len - 1;
		while(index >= 0)
		{
			let model = dataArray[index];
			if(StringUtils.isEqual(model.id, jsonData.id))
			{
				model.status = true;
				model.optType = '';
				break;
			}
			index --;
		}
		
		// 持久化到本地
		Cache.setValue(cachekey, dataArray);
	}
	
	addRecord(jsonData)
	{
		//console.log("add record = ", jsonData);
		let event = jsonData.event;
		let fromUserid = jsonData.fromUserid; // 
		let targetid = jsonData.targetid;
		
		let cachekey = this.getCacheKey(event, fromUserid, targetid);
		//console.log("addRecord cache-key = " + cachekey, jsonData);
		if(cachekey == null)
		{
			console.log("un support from chat type for " + event);
			return [];
		}
		
		let dataArray = this.getDataArray(event, fromUserid, targetid);
		
		let arrLen = dataArray.length;
		
		// 数组不为空时
		if(arrLen > 0)
		{
			// 获取数组最后一个元素
			let lastElement = dataArray[arrLen - 1];
			let nowDate = new Date();
			// 两个时间超过1小时才显示
			if(nowDate.getTime() - lastElement.time >= 3600000)
			{
				let localTime = ProtocolHelper.localTime(nowDate);
				dataArray.push(localTime);
			}
		}
		else
		{
			let nowDate = new Date();
			let localTime = ProtocolHelper.localTime(nowDate);
			dataArray.push(localTime);
		}
		
		// 元素不能超过最大的容量，会影响性能问题
		let len = dataArray.push(jsonData);
		while((len --) > DEFAULT_MAX_RECORLD_SIZE)
		{
			// 第一位默认是时间,不能删除
			dataArray.splice(1,1);
			//dataArray.shift(); // 删除第一个元素，并返回这个元素
		}
		// 持久化到本地
		Cache.setValue(cachekey, dataArray);
		
		return dataArray;
	}
	
	/**
	 * 删除指定消息记录, 比如删除和某个人聊天的所有信息
	 * @param {Object} event
	 * @param {Object} fromUserid
	 */
	deleteRecordList(event, fromUserid, targetid)
	{
		// delete memory cache
		let dataArray = this.getDataArray(event, fromUserid, targetid);
		let len = dataArray.length;
		if(dataArray && len > 0)
		{
			dataArray.splice(0);
			// delete local cache
			let cachekey = this.getCacheKey(event, fromUserid, targetid);
			Cache.deleteValue(cachekey);
		}
	}
	
	/**
	 * 更新指定消息记录的某一条数据
	 * @param {Object} event
	 * @param {Object} fromUserid
	 * @param {Object} msgId
	 */
	updateRecordItem(json)
	{
		let msgid = json.id;
		let fromUserid = json.fromUserid; // 
		let targetid = json.targetid;
		let event = json.event;
		
		let cachekey = this.getCacheKey(event, fromUserid, targetid);
		let dataArray = this.getDataArray(event, fromUserid, targetid);
		
		let len = dataArray.length;
		if(len <= 0) 
		{
			return;
		}
		
		for(let i = 0; i < len; i ++)
		{
			let model = dataArray[i];
			if(StringUtils.isEqual(msgid, model.id))
			{
				// 更新数据
				model.data = json.data;
				// 更新消息类型, 比如撤回消息,一般不会变
				model.msgType = json.msgType;
				//
				model.status = json.status;
				
				// 保存
				Cache.setValue(cachekey, dataArray);
				break;
			}
		}
		
		return dataArray;
	}
	
	/**
	 * 删除指定消息记录的某一条数据
	 * @param {Object} event
	 * @param {Object} fromUserid
	 * @param {Object} msgId
	 */
	deleteRecordItem(json)
	{
		let msgid = json.id;
		let fromUserid = json.fromUserid; // 
		let targetid = json.targetid;
		let event = json.event;
		
		let cachekey = this.getCacheKey(event, fromUserid, targetid);
		//console.log("addRecord cache-key = " + cachekey, jsonData);
		if(cachekey == null)
		{
			console.log("un support from chat type for " + event);
			return [];
		}
		let dataArray = this.getDataArray(event, fromUserid, targetid);
		
		let len = dataArray.length;
		if(len <= 0) 
		{
			return;
		}
		
		for(let i = 0; i < len; i ++)
		{
			let model = dataArray[i];
			if(msgid === model.id)
			{
				dataArray.splice(i, 1);
				break;
			}
		}
		// 保存
		Cache.setValue(cachekey, dataArray);
		
		return dataArray;
	}
	
	getCacheKey(event, fromUserid, targetid)
	{
		//console.log("record ============== event = " + event + ",  " + (MessageEvent.SINGLE == event));
		let userInfo = UserManager.getUserInfo();
		if(StringUtils.isEqual(MessageEvent.SINGLE, event))
		{
			if(StringUtils.isEqual(userInfo.username, fromUserid))
			{
				// 自己发送的
				return 'chat_record_' + event + "_" + fromUserid + "_" + targetid;
			}
			else 
			{
				// 好友发送过来的
				return 'chat_record_' + event + "_" + targetid + "_" + fromUserid;
			}
		}
		else if(StringUtils.isEqual(MessageEvent.KEFU, event))
		{
			if(StringUtils.isEqual(userInfo.username, fromUserid))
			{
				// 自己发送的
				return 'chat_record_' + event + "_" + fromUserid + "_" + targetid;
			}
			else 
			{
				// 好友发送过来的
				return 'chat_record_' + event + "_" + targetid + "_" + fromUserid;
			}
		}
		else if( StringUtils.isEqual(MessageEvent.GROUP, event))
		{
			return 'chat_record_' + event + "_" + targetid;
		}
		else{
			console.log("=======================聊天类型为空，请及时处理")
			return null;
		}
		
	}
	
	
}

export default RecordManager