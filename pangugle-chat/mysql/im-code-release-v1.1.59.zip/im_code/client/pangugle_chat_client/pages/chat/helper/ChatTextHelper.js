// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import EmotionUtils from "@/pages/framework/utils/EmotionUtils.js"

const ChatTextHelper = {
	
	richText(content)
	{
		
		// 匹配有没有网页地址
		//content = StringUtils.replaceUrlToLink(content);
		
		// 匹配有没有表情
		content = EmotionUtils.replaceEmoji(content);
		
		return content;
	}
	
}

export default ChatTextHelper