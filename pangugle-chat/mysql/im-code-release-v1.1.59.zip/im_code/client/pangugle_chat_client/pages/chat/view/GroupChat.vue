<template>
	<view :style="{height:style.pageHeight+'px'}">
		<!-- :style="{height:style.contentViewHeight+'px'}" -->
		<view id="content" class="content" :style="{height:style.contentViewHeight+'px'}">
			<scroll-view class="msg-list" scroll-y="true"
				:style="{height:style.contentViewHeight+'px'}"
				:scroll-with-animation="scrollAnimation" 
				:scroll-top="scrollTop" 
				:scroll-into-view="scrollToView" 
				@click.stop="refreshDefault"
				upper-threshold="50">
				<view class="row" v-for="(row,index) in msgList" :key="index" :id="'msg'+row.id">
					<!-- 系统消息 -->
					<block v-if="row.data.belongType == 'system'">
						<view class="system">
							<!-- 文字消息 -->
							<view v-if="LocalMsgType.TEXT == row.msgType" class="text">
								{{row.data.content}}
							</view>
							<!-- 时间消息 -->
							<view v-else-if="LocalMsgType.TIME == row.msgType" class="text">
								{{ChatTimeHelper.getTimeValue(row.time)}}
							</view>
							<!-- 撤回消息 -->
							<view v-else-if="BasicMsgType.REVOKE == row.msgType" class="text">
								{{ChatViewManager.handleRevokeMessage(row)}}
							</view>
							<view v-else-if="LocalMsgType.VERIFY_FRIEND == row.msgType" class="verify_friend">
								对方开启了好友验证，你还不是他(她)的好友。请先发送好友验证请求，对方验证通过后，才能聊天。
								<text class="text-blue" @click.stop="sendAddFriendRequest()">发送好友验证</text>
							</view>
							<!-- 领取红包消息 -->
							<view v-else-if="row.data.type=='redEnvelope'" class="red-envelope">
								<pg-image-cache imgSrc="/static/img/red-envelope-chat.png"></pg-image-cache>
								{{row.data.text}}
							</view>
							<!-- 消息不支持 -->
							<view v-else class="text">
								该消息不支持
							</view>
						</view>
					</block>
					<!-- 用户消息-自己发送的 -->
					<block v-else-if="row.data.belongType == 'user'">
						<!-- 自己发出的消息 -->
						<view class="my" v-if="row.fromUserid == userInfo.username">
							<!-- 左-消息 -->
							<view class="left">
								<!-- 消息未送达提示 -->
								<view class="unsend" v-if="!row.status" ><text >!</text></view>
								<!-- 文字消息 -->
								<!-- 
									@touchstart.stop.prevent="discard"
									@touchmove.stop.prevent="discard"
									-->
								<view v-if="BasicMsgType.TEXT == row.msgType" class="bubble"
									@longpress="openActionSheet(row)">
									<rich-text :nodes="row.data.showText"></rich-text>
								</view>
								<!-- 语言消息 -->
								<view v-else-if="BasicMsgType.VOICE == row.msgType" 
									@longpress="openActionSheet(row)"
									class="bubble voice" 
									@click.stop="playVoice(row)" 
									:class="playMsgid == row.id?'play':''">
									<view class="length">{{row.data.playTime}}</view>
									<view class="icon my-voice"></view>
								</view>
								<!-- 图片消息 -->
								<view v-else-if="BasicMsgType.IMAGE == row.msgType"
									@longpress="openActionSheet(row)"
									class="bubble img" 
									@click.stop="showPic(row)">
									<pg-image-cache :imgSrc="row.data.url" :style="{'width': row.data.width+'px','height': row.data.height+'px'}"></pg-image-cache>
								</view>
								<!-- 名片消息 -->
								<view v-else-if="BasicMsgType.CARD == row.msgType" class="bubble card" 
									@longpress="openActionSheet(row)"
									@click.stop="jumpToUserBasicInfo(row)">
									<view class="card_top">
										<view class="card_top_img"><pg-image-cache :imgSrc="row.data.avatar"></pg-image-cache></view>
										<view class="card_top_rg">
											<view>{{row.data.nickname}}</view>
											<view>{{row.data.username}}</view>
										</view>
									</view>
									<view class="card_bot">个人名片</view>
								</view>
								<!-- 红包 -->
								<view v-else-if="BasicMsgType.RED_PACKET == row.msgType" class="bubble red-envelope" @click="openRedEnvelope(row.msg,index)">
									<pg-image-cache imgSrc="/static/chat/red-envelope.png"></pg-image-cache>
									<view class="tis">
										<!-- 点击开红包 -->
									</view>
									<view class="blessing">
										<!-- 祝福语 -->
										{{row.data.blessing}}
									</view>
								</view>
								<!-- 消息不支持 -->
								<view v-else class="bubble">
									<text>该消息不支持,请升级最新版本</text>
								</view>
							</view>
							<!-- 右-头像 -->
							<view class="right">
								<pg-image-cache :imgSrc="userInfo.avatar"></pg-image-cache>
							</view>
						</view>
						<!-- 别人发出的消息 -->
						<view class="other" v-if="row.fromUserid !== userInfo.username">
							<!-- 左-头像 -->
							<view class="left" @click="jumpToUserBasicInfo(row)">
								<pg-image-cache :imgSrc="handleFriendAvatar(row)"></pg-image-cache>
							</view>
							<!-- 右-用户名称-时间-消息 -->
							<view class="right">
								<view class="username">
									<view class="name">{{handleFriendTitle(row)}}</view>
								</view>
								<!-- 文字消息 -->
								<view 
									v-if="BasicMsgType.TEXT == row.msgType" class="bubble"
									@longpress="openActionSheet(row)">
									<rich-text :nodes="row.data.showText" ></rich-text>
								</view>
								<!-- 语音消息 -->
								<view v-else-if="BasicMsgType.VOICE == row.msgType" 
									@longpress="openActionSheet(row)"
									class="bubble voice" 
									@click.stop="playVoice(row)" 
									:class="playMsgid == row.id?'play':''">
									<view class="icon other-voice"></view>
									<view class="length">{{row.data.playTime}}</view>
								</view>
								<!-- 图片消息 -->
								<view v-else-if="BasicMsgType.IMAGE == row.msgType"
									@longpress="openActionSheet(row)"
									class="bubble img" @click.stop="showPic(row)">
									<pg-image-cache :imgSrc="row.data.url" :style="{'width': row.data.width+'px','height': row.data.height+'px'}"></pg-image-cache>
								</view>
								<!-- 名片消息 -->
								<view v-else-if="BasicMsgType.CARD == row.msgType" class="bubble card" 
									@longpress="openActionSheet(row)"
									@click.stop="jumpToUserBasicInfo(row)">
									<view class="card_top">
										<view class="card_top_img"><pg-image-cache :imgSrc="row.data.avatar"></pg-image-cache></view>
										<view class="card_top_rg">
											<view>{{row.data.nickname}}</view>
											<view>{{row.data.username}}</view>
										</view>
									</view>
									<view class="card_bot">个人名片</view>
								</view>
								<!-- 红包 -->
								<view v-else-if="BasicMsgType.RED_PACKET == row.msgType" class="bubble red-envelope" @click="openRedEnvelope(row.msg,index)">
									<pg-image-cache imgSrc="/static/chat/red-envelope.png"></pg-image-cache>
									<view class="tis">
										<!-- 点击开红包 -->
									</view>
									<view class="blessing">
										{{row.data.blessing}}
									</view>
								</view>
								<!-- 消息不支持 -->
								<view v-else class="bubble">
									<text>该消息不支持,请升级最新版本</text>
								</view>
							</view>
							
						</view>
					</block>
				</view>
			</scroll-view>
		</view>
			
		<!-- 底部 -->
		<view id="footInputBar">
			<!-- 抽屉栏 -->
			<view class="popup-layer" :class="popupLayerClass" 
			@touchmove.stop.prevent="discard">
				<!-- 表情 --> 
				<!-- -->
				<view :class="{hidden:optStatus != optStatusMap.emotion}" >
					<swiper class="emoji-swiper" 

					indicator-dots="true" 
					duration="150" 
					>
						<swiper-item v-for="(page,pid) in emojiList" :key="pid">
							<view v-for="(em,eid) in page" :key="eid" @tap="addEmoji(em)">
								<!-- <image mode="widthFix" :src="emojiPath+em.url"></pg-image-cache> -->
								<pg-image-cache :imgSrc="emojiPath+em.url"></pg-image-cache>
							</view>
						</swiper-item>
					</swiper> 
					<view class="foot_emoji">
						<view class="foot_emoji_send" @click="sendText()">发送</view>
						<view class="foot_emoji_del" @click="backText()"><pg-image-cache imgSrc="/static/chat/tab/keyboard_key_delete_down.png" ></pg-image-cache></view>
					</view>
				</view>
				<!-- 
				<emotion @addEmoji="addEmoji" :class="{hidden:optStatus != optStatusMap.emotion}" ></emotion>
				-->
				<!-- 更多功能 相册-拍照-红包 -->
				<view class="more-layer" :class="{hidden:optStatus != optStatusMap.more}">
					<view class="list">
						<view class="box" @tap="openAlbum">
							<view class="icon tupian2"></view>
						</view>
						<view class="box" @tap="openCamera">
							<view class="icon paizhao"></view>
						</view>
						<view class="box" @tap="openPersonCard">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/userinfo.png"></pg-image-cache>
						</view>
						
						<!-- 
						<view class="box" @tap="handRedEnvelopes">
							<view class="icon hongbao"></view>
						</view>
						<view class="box" @tap="yuyintonghua">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/yuyintonghua.png"></pg-image-cache>
						</view>
						<view class="box" @tap="weizhi">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/weizhi.png"></pg-image-cache>
						</view>
						<view class="box" @tap="yuyinshuru">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/yuyinshuru.png"></pg-image-cache>
						</view>
						<view class="box" @tap="meShouchang">
							<pg-image-cache setStyle="font-size:16px;width: 32px; height: 32px;" 
							imgSrc="/static/chat/more/me-shouchang.png"></pg-image-cache>
						</view>
						-->
						
					</view>
				</view>
			</view>
			<!-- 底部输入栏 -->
			<view class="input-box" 
				:style="{bottom:style.input_bottom +'px'}"
				:class="popupLayerClass" 
				@touchmove.stop.prevent="discard">
				<!-- H5下不能录音，输入栏布局改动一下     -->
				<!-- #ifndef H5 -->
				<view class="voice">
					<!--
					<view class="icon" :class="isVoice?'jianpan':'yuyin'" @tap="switchVoice"></view>
					<view class="icon" :class="optStatus == optStatusMap.input ? 'jianpan':'yuyin'" @tap="switchVoice"></view>
					-->
					<view v-if="optStatus == optStatusMap.def" class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					<view v-else-if="optStatus == optStatusMap.voice" class="jianpan" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/keyboard.png" mode=""></pg-image-cache>
					</view>
					<view v-else-if="optStatus == optStatusMap.input" class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					<view v-else class="yuyin" @tap="switchVoice">
						<pg-image-cache imgSrc="/static/chat/voice.png" mode=""></pg-image-cache>
					</view>
					
				</view>
				<!-- #endif -->
			
				<view class="textbox">
					<view class="voice-mode" 
						:class="[(optStatus == optStatusMap.voice)?'':'hidden', recording?'recording':'']" 
						@touchstart="onVoiceBegin" @touchmove.stop.prevent="onVoiceIng"
						@touchend="onVoiceEnd" @touchcancel="onVoiceCancel">{{voiceTis}}
					</view>
					<view class="text-mode"  :class="optStatus == optStatusMap.voice?'hidden':''">
						<view class="box">
							<!-- <input 
								:maxlength="inputMaxlength" 
								:focus="optStatus == optStatusMap.input"
								:confirm-hold="true"
								confirm-type="go"
								v-model="textMsg" 
								@focus="onInputFocus" 
								@blur="onInputBlur"
								@confirm="onInputConfirm" /> -->
								
								<!-- :focus="optStatus == optStatusMap.input" -->
								<textarea
									:disabled="mIsDisabledChat"
									:placeholder="textPlaceHolder"
									:maxlength="inputMaxlength" 
									:confirm-hold="true"
									:auto-height="false"
									:adjust-position="false"
									:show-confirm-bar="false"
									v-model="textMsg" 
									@focus="onInputFocus" 
									@blur="onInputBlur"
									@input="onInputChange"
									/>
						</view>
						<view class="em" @tap="chooseEmoji">
							<view class="biaoqing">
								<pg-image-cache imgSrc="/static/chat/emotion.png" mode=""></pg-image-cache>
							</view>
						</view>
					</view>
				</view>
				
				<view class="more" @tap="showMore">
					<!--  v-if="textMsg.length == 0 || optStatus != optStatusMap.input" 发送会跳，暂时关闭 -->
					<view v-if="textMsg.length > 0 && optStatus == optStatusMap.input" @touchend.prevent="sendText" class="send">
						<view class="btn">发送</view>
					</view>
					<view v-else class="add">
						<pg-image-cache imgSrc="/static/chat/moreinfo.png" mode=""></pg-image-cache>
					</view>
					<!-- 发送会跳，暂时关闭, 日后有方案再处理
					<input v-else class="btn_send_message"
						:focus="isActiveSend"
						:adjust-position="false"
						:confirm-hold="true"
						value="发送"
						@focus="onSendFocus"
						@blur="onSendBlur"/>
						-->
				</view>
				
				<!-- <view class="send" :class="optStatus == optStatusMap.voice?'hidden':''" @tap="sendText">
					<view class="btn">发送</view>
				</view> -->
			</view>
			<!-- 录音UI效果 -->
			<!-- #ifndef H5 -->
			<chat-record ref="mChatRecordUI" @onRecordFinish="onRecordFinish" /> 
			<!-- #endif -->
		</view>
		
		<!-- 红包弹窗 -->
		<view class="windows" :class="windowsState">
			<!-- 遮罩层 -->
			<!-- <view class="mask" @touchmove.stop.prevent="discard" @tap="closeRedEnvelope"></view> -->
			<view class="layer" @touchmove.stop.prevent="discard">
				<view class="open-redenvelope">
					<view class="top">
						<view class="close-btn">
							<!-- <view class="icon close" @tap="closeRedEnvelope"></view> -->
						</view>
						<!-- <pg-image-cache imgSrc="/static/chat/im/face/face_1.jpg"></pg-image-cache> -->
					</view>
					<view class="from">来自{{redenvelopeData.from}}</view>
					<view class="blessing">{{redenvelopeData.blessing}}</view>
					<view class="money">{{redenvelopeData.money}}</view>
					<view class="showDetails" @tap="toDetails(redenvelopeData.rid)">
						查看领取详情 <view class="icon to"></view>
					</view>
				</view>
			</view>
		</view>
		
		<pg-actionsheet
			:show="actionSheet.show" 
			:tips="actionSheet.tips" 
			:item-list="actionSheet.currentItemList" 
			:mask-closable="actionSheet.maskClosable"
			:color="actionSheet.color" 
			:size="actionSheet.size" 
			:is-cancel="actionSheet.isCancel" 
			@click="onActionSheetItemClick" 
			@cancel="closeActionSheet">
		</pg-actionsheet>
	</view>
</template>
<script>
	import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import CachePolicy from '@/pages/framework/http/CachePolicy.js'
	import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
	import EmotionUtils from "@/pages/framework/utils/EmotionUtils.js"
	import chatRecord from "@/components/pg-chat/chat-record.vue"
	
	import CopyUtils from "@/pages/framework/utils/CopyUtils.js"
		
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserManager from '@/pages/user/logical/UserManager.js'
	import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'
	
	// chat
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
	import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
	import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
	import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
	import ChatTimeHelper from "@/pages/chat/helper/ChatTimeHelper.js"
	import GroupChatManager from "@/pages/chat/logical/handler/GroupChatManager.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
	import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	import ChatViewManager from "@/pages/chat/logical/ChatViewManager.js"
	
	import GroupAtMemberManager from "@/pages/chat/logical/GroupAtMemberManager.js"
	
	import IMApi from "@/pages/chat/service/IMApi.js"
	import FriendApi from "@/pages/chat/service/FriendApi.js"
	
	// 进入其它特殊页面，并不是退出，如转成，查看图册
	var isActive = false;
	export default {
		components: {
			"pg-actionsheet" : actionSheet,
			chatRecord,
		},
		data() {
			return {
				
				style: {
					pageHeight: 0,
					defPageHeight : 0,
					contentViewHeight: 0,
					footInputHeight: 49,
					mitemHeight: 0,
					input_bottom : -0.5
				},
				optStatusMap : {
					def : 'def',
					voice : 'voice',
					input : 'input',
					more : 'more',
					emotion : 'emotion',
					showpic : 'showpic',
					dispatch : 'dispatch',
				},
				optStatus : 'def', // default, voice, input, more, emotion
				
				
				//文字消息
				// dotsCurrent:1,
				mIsDisabledChat : false,
				textMsg:'',
				textPlaceHolder : '',
				inputMaxlength : 150,
				isActiveSend : false, // 
				//消息列表
				isHistoryLoading:false,
				scrollAnimation:false,
				scrollTop:0,
				scrollToView:'',
				msgList:[],
				myuid:0,
				
				//录音相关参数
				recording:false,
				voiceTis:'按住 说话',
				initPoint:{identifier:0,Y:0},
				
				//播放语音相关参数
				AUDIO:uni.createInnerAudioContext(),
				playMsgid:null,
				VoiceTimer:null,
				// 抽屉参数
				popupLayerClass:'',
				// more参数
				//hideMore:true,
				//表情定义
				//hideEmoji:true,
				emojiList:[{}],
				emojiPath:'https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/',
				//emojiPath : 'https://s2.ax1x.com/2019/04/12/',
				
				//红包相关参数
				windowsState:'',
				redenvelopeData:{
					rid:null,	//红包ID
					from:null,
					face:null,
					blessing:null,
					money:null
				},
				
				// 实体信息
				groupInfo : {
					id : '',
				},
				userInfo : {
					username : '',
					nickname : '',
					avatar : '',
				},
				
				// 引入进来的都要在这里定义下
				BasicMsgType : BasicMsgType,
				LocalMsgType : LocalMsgType,
				
				//
				ChatTimeHelper : ChatTimeHelper,
				ProtocolHelper : ProtocolHelper,
				ChatViewManager : ChatViewManager,
				
				//
				messageEvent : 'group',
				
				longPress : {
					loopTime : -1,
				},
				
				actionSheet : {
					optValue : null,
					show: false,
					maskClosable: true,
					tips: "",
					currentItemList : [],
					leftItemList : [
						{text: "复制",color: "#1a1a1a"},
						{text: "删除",color: "#1a1a1a"},
					],
					rightItemList: [
						{text: "复制",color: "#1a1a1a"},
						{text: "删除",color: "#1a1a1a"},
						//{text: "撤回",color: "#1a1a1a"},
					],
					color: "#9a9a9a",
					size: 26,
					isCancel: true
				},
			};
		},
		onLoad(options) {
			isActive = false;
			this.defPageHeight = uni.getSystemInfoSync().windowHeight;
			
			this.groupInfo.id = options.groupid;
			
			// user
			let userInfo = UserManager.getUserInfo();
			this.userInfo.username = userInfo.username;
			this.userInfo.nickname = userInfo.nickname;
			this.userInfo.avatar = userInfo.avatar;
			//console.log("user info : ", UserManager, userInfo);
			
			// 设置UI
			GroupChatManager.setUICallback(this, this.groupInfo.id)
			
			//语音自然播放结束
			this.AUDIO.onEnded((res)=>{
				this.playMsgid=null;
			});
			
			// 微信表情
			this.emojiList = EmotionUtils.getDataList();
			this.emojiPath = EmotionUtils.getServerPath();
				
			let that = this;
			setTimeout(function() {
				that.scrollAnimation = true;
				//console.log("scrollAnimation ======= " +that.scrollAnimation);
			}, 1500);
			
			// #ifdef H5
			uni.onWindowResize((res) => {
				//console.log("=====onWindowResize");
				//console.log('变化后的窗口宽度=' + res.size.windowWidth)
				//const info = uni.getSystemInfoSync();
				//console.log('变化后的窗口高度=' + res.size.windowHeight, ",   ", info.windowHeight + ",   safeare = ", info.safeArea.height)
				
				// // #ifdef APP-PLUS
				// that.style.pageHeight = res.size.windowHeight;
				// //  #endif

				
				let myRes = uni.getSystemInfoSync();
				let platform = myRes.platform;
				if(!StringUtils.isEqual("ios", platform))
				{
					that.style.pageHeight = res.size.windowHeight;
					
					that.scrollToView = '';
					that.updateContentHeight(true);
				}
			})
			//  #endif
			
			// #ifndef H5
			uni.onKeyboardHeightChange(res => {
				let myRes = uni.getSystemInfoSync();
				let platform = myRes.platform;
				
				
				that.style.input_bottom = res.height;
				that.style.pageHeight = that.style.defPageHeight - res.height;
				//console.log("================= defPageHeight = " + that.style.defPageHeight, ", keybodyHeight = ",  res);
				that.scrollToView = '';
				that.updateContentHeight(true);
				
			});
			// #endif
		},
		
		onUnload() {
			//console.log("============onUnload");
			uni.offWindowResize(function(){
				
			})
			isActive = false;
			GroupChatManager.setActive(false);
			uni.hideKeyboard();
			GroupAtMemberManager.clear();
		},
		
		onShow(){
			//console.log("============onShow");
			this.style.defPageHeight = uni.getSystemInfoSync().windowHeight;
			if(isActive)
			{
				this.optStatus = this.optStatusMap.def;
				this.updateContentHeight(false);
				return;
			}
			// 放在最后
			isActive = true;
			GroupChatManager.setActive(true);
			
			// 重新加载数据
			GroupChatManager.reload(UserManager.getUserInfo().username, this.groupInfo.id);
			
			this.$nextTick(function(){
				this.reloadData();
			})
			
			if(GroupAtMemberManager.isActive())
			{
				this.textMsg = GroupAtMemberManager.getInputValue();
			}
			
		},
		onHide() {
			//console.log("============onHide");
			if(StringUtils.isEqual(this.optStatus, this.optStatusMap.showpic))
			{
				return;
			}
			isActive = false;
			GroupChatManager.setActive(false);
		},
		onNavigationBarButtonTap() {
			ChatJumpHelper.jumpToGroupInfo(this.groupInfo.id);
		},
		methods:{
			
			reloadData()
			{
				GroupCMDManager.refreshGroupInfo(false, this.groupInfo.id, (isCache, groupInfo) => {
					if(groupInfo == null)
					{
						console.log("=========== empty group info =========");
						return;
					}
					//var groupInfo = GroupCMDManager.getGroupInfo(this.groupInfo.id);
					this.groupInfo = groupInfo;
					//console.log("group info chat === ", groupInfo.enableChat);
					// 设置导航栏标题
					var title = groupInfo.alias;
					if(!StringUtils.isEmpty(groupInfo.name))
					{
						title = groupInfo.name;
					}
					uni.setNavigationBarTitle({
					    title: title
					});
					
					// 是否全员禁言，除了群主
					if(UserManager.getUserInfo().username != groupInfo.holder)
					{
						if(!groupInfo.enableChat)
						{
							this.textPlaceHolder = "全员禁言!";
							this.mIsDisabledChat = true;
						}
						else 
						{
							// 自己是否被禁言了
							if(!GroupCMDManager.isEnableSelfChat(groupInfo.id))
							{
								this.textPlaceHolder = "你已被禁言!";
								this.mIsDisabledChat = true;
							}
							else
							{
								this.textPlaceHolder = "";
								this.mIsDisabledChat = false;
							}
							
						}
					}
					else
					{
						this.textPlaceHolder = "";
						this.mIsDisabledChat = false;
					}
				})
			},
			
			scrollToBottom()
			{
				if(!StringUtils.isEqual(this.optStatus, this.optStatusMap.input))
				{
					this.scrollToView = '';
				}
				let that = this;
				this.$nextTick(function() {
					let len = that.msgList.length;
					if(len > 0)
					{
						let model = that.msgList[len - 1];
						// 滚动到底
						that.scrollToView = 'msg'+model.id;
					}
				});
			},
			
			updateContentHeight(isScrollToBottom)
			{
				let that = this;
				// #ifdef H5
				let myRes = uni.getSystemInfoSync(); 
				let platform = myRes.platform;
				if(StringUtils.isEqual("ios", platform))
				{
					that.style.contentViewHeight = that.style.defPageHeight - 50;
					if(isScrollToBottom)
					{
						//console.log("=======pageHeight = " + pageHeight, ", footerHeight = " + data.height, ",    contentHeight = " + that.style.contentViewHeight, "       = ", data);
						that.scrollToBottom();
					}
					return;
				}
				// #endif
				
				this.$nextTick(function(){
					
					// input
					if(StringUtils.isEqual(that.optStatus, that.optStatusMap.input))
					{
						let popupQuery = uni.createSelectorQuery().in(that).select(".input-box");
						popupQuery.fields({
							size: true
						}, data => {
							const res = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = res.windowHeight;
							// #ifndef H5
								// 由于app 计算高度时的bug，这里不就不采用这个api，直接采用监听windowsize的高度
								pageHeight = that.style.pageHeight;
							// #endif
							
							that.style.contentViewHeight = pageHeight - data.height ; //像素
							if(isScrollToBottom)
							{
								that.scrollToBottom();
							}
						}).exec();
						
					}
					// more emotion
					else if(
						StringUtils.isEqual(that.optStatus, that.optStatusMap.more) || 
						StringUtils.isEqual(that.optStatus, that.optStatusMap.emotion))
					{
						let query = uni.createSelectorQuery()
						query.select('.input-box').boundingClientRect()
						query.select('.popup-layer').boundingClientRect()
						query.exec((res) => {
							
							const systemInfo = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = systemInfo.windowHeight;
							that.style.pageHeight = systemInfo.windowHeight;
							that.style.contentViewHeight = pageHeight - res[1].height - res[0].height ; //像素
							if(isScrollToBottom)
							{
								that.scrollToBottom();
							}
						})
					}
					else {
						let popupQuery = uni.createSelectorQuery().in(that).select(".input-box");
						popupQuery.fields({
							size: true
						}, data => {
							const res = uni.getSystemInfoSync();// 获取系统信息
							let pageHeight = res.windowHeight;
							that.style.pageHeight = res.windowHeight;
							that.style.contentViewHeight = that.defPageHeight - data.height ; //像素
							if(isScrollToBottom)
							{
								that.scrollToBottom();
							}
						}).exec();
					}
				})
			},
			// 切换语音/文字输入
			switchVoice(){
				if(this.mIsDisabledChat)
				{
					return;
				}
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				this.hideDrawer();
				// 默认， 语音按钮
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.def))
				{
					this.optStatus = this.optStatusMap.voice;
				}
				else if(StringUtils.isEqual(this.optStatus, this.optStatusMap.voice))
				{
					// 输入状态，键盘
					this.optStatus = this.optStatusMap.input;
				}
				else if(StringUtils.isEqual(this.optStatus, this.optStatusMap.input))
				{
					// 语音状态，语音
					this.optStatus = this.optStatusMap.voice;
				}
				else 
				{
					this.optStatus = this.optStatusMap.def;
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			// 选择表情
			chooseEmoji(){
				if(this.mIsDisabledChat)
				{
					return;
				}
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.emotion))
				{
					this.optStatus = this.optStatusMap.def;
					this.hideDrawer();
				}
				else
				{
					this.optStatus = this.optStatusMap.emotion;
					this.openDrawer();
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			//更多功能(点击+弹出) 
			showMore(){
				if(this.mIsDisabledChat)
				{
					return;
				}
				let isUpdateHeight = !StringUtils.isEqual(this.optStatus, this.optStatusMap.input);
				if(StringUtils.isEqual(this.optStatus, this.optStatusMap.more))
				{
					this.optStatus = this.optStatusMap.def;
					this.hideDrawer();
				}
				else
				{
					this.optStatus = this.optStatusMap.more;
					this.openDrawer();
				}
				if(isUpdateHeight)
				{
					this.updateContentHeight(true);
				}
			},
			/**
			 * 恢复默认
			 */
			refreshDefault()
			{
				if(this.optStatus != this.optStatusMap.def && this.optStatus != this.optStatusMap.voice)
				{
					this.optStatus = this.optStatusMap.def;
					//uni.hideKeyboard();
					this.hideDrawer();
					this.updateContentHeight(true);
					uni.hideKeyboard();
				}
			},
			// 打开抽屉
			openDrawer(){
				this.popupLayerClass = 'showLayer';
			},
			// 隐藏抽屉
			hideDrawer(){
				this.popupLayerClass = '';
			},
			onSendFocus(){
				this.optStatus = this.optStatusMap.input;
				this.isActiveSend = false;
				this.sendText();
			},
			//获取焦点，如果不是选表情ing,则关闭抽屉
			onInputFocus(e){
				//console.log('onInputFocus===========')
				this.optStatus = this.optStatusMap.input;
				this.hideDrawer();
				
				
				//this.updateContentHeight(true);
			},
			//失去焦点
			onInputBlur(e){
			},
			onInputConfirm()
			{
				this.sendText();
			},
			onInputChange(e)
			{
				try{
					//console.log("============, ", this.optStatus);
					if(this.optStatus !== this.optStatusMap.input)
					{
						return;
					}
					//console.log("============, ", e);
					let value = e.detail.value;
					let len = value.length;
					let ch = value.charAt(value.length - 1).charCodeAt();
					//var num = Number(ch);
					
					var inputIndex = e.detail.cursor - 1;
					var inputValue = value.charAt(inputIndex);
					var inputNum = Number(inputValue.charCodeAt());
					
					
					if(inputNum == 64)
					{
						if(GroupAtMemberManager.isBackText(value))
						{
							GroupAtMemberManager.setInputValue(value);
							return;
						}
						this.handleAtMember(e.detail.cursor);
					}
				}catch(e){
					console.log("error:", e);
					//TODO handle the exception
				}
			},
			// =========================== 长按相关================
			openActionSheet(optValue){
				let itemList = [];
				this.actionSheet.optValue = optValue;
				let item = optValue;
				if(StringUtils.isEqual(BasicMsgType.TEXT, item.msgType))
				{
					//itemList.push({text: "复制",color: "#1a1a1a"});
				}
				itemList.push({text: "删除",color: "#1a1a1a"});
				if(ProtocolHelper.isSelfProtocol(item))
				{
					// 没有发送成功
					if(!item.status)
					{
						let resendItem = {text: "重发",color: "#1a1a1a"};
						itemList.push(resendItem);
					}
					// 时间超过120s 不能撤回
					let date = new Date();
					if( date.getTime() - item.time <= 120000)
					{
						let resendItem = {text: "撤回",color: "#1a1a1a"};
						itemList.push(resendItem);
					}
				}
				
				if(
					StringUtils.isEqual(BasicMsgType.TEXT, this.actionSheet.optValue.msgType) || 
					StringUtils.isEqual(BasicMsgType.IMAGE, this.actionSheet.optValue.msgType))
				{
					// 
					let dispatchItem = {text: "转发", color: "#1a1a1a"};
					itemList.push(dispatchItem);
				}
				if(StringUtils.isEqual(item.msgType, BasicMsgType.IMAGE))
				{
					let album = {text: "图册",color: "#1a1a1a"};
					itemList.push(album)
				}
				this.actionSheet.currentItemList = itemList;
				this.actionSheet.show = true;
				//
				this.$nextTick(function(){
					uni.hideKeyboard();
				})
			},
			closeActionSheet: function() {
				this.actionSheet.optValue = null;
				this.actionSheet.show = false;
			},
			onActionSheetItemClick: function(e) {
				if(this.actionSheet.optValue == null)
				{
					return;
				}
				let index = e.index;
				let itemTextValue = this.actionSheet.currentItemList[index].text;
				if(StringUtils.isEqual(itemTextValue, '复制'))
				{
					let content = ProtocolHelper.getProtocolText(this.actionSheet.optValue);
					CopyUtils.doCopy(content);
				}
				else if(StringUtils.isEqual(itemTextValue, '删除'))
				{
					GroupChatManager.deleteMessage(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '撤回'))
				{
					let msgBody = ProtocolHelper.revoke(this.actionSheet.optValue);
					MessageHelper.sendMessage(msgBody);
				}
				else if(StringUtils.isEqual(itemTextValue, '图册'))
				{
					this.showPic(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '重发'))
				{
					// 重新发送
					this.actionSheet.optValue.optType = 'resend';
					MessageHelper.sendMessage(this.actionSheet.optValue);
				}
				else if(StringUtils.isEqual(itemTextValue, '转发'))
				{
					isActive = true;
					// 转发
					ChatJumpHelper.jumpToShareToConversation(this.actionSheet.optValue);
				}
				
				this.closeActionSheet();
			},
			//=================================================== 文本消息
			// 发送文字消息
			sendText(){
				if(StringUtils.isEmpty(this.textMsg))
				{
					return;
				}
				
				var atMemberArray = GroupAtMemberManager.getAllMember();
				var atUserArray = '';
				if(atMemberArray && atMemberArray.length > 0)
				{
					atUserArray = [];
					for(var i in atMemberArray)
					{
						var item = atMemberArray[i];
						var nickname = item.nickname;
						if(this.textMsg.indexOf(nickname) > 0)
						{
							atUserArray.push(item.username);
						}
					}
				}
				//console.log("==============at user array : ", atUserArray);
				
				ChatViewManager.sendText(this.groupInfo.id, this.messageEvent, this.textMsg, atUserArray);
				this.textMsg = '';
				GroupAtMemberManager.clear();
			},
			handleAtMember(cursor)
			{
				var atMemberArray = GroupAtMemberManager.getAllMember();
				if(atMemberArray && atMemberArray.length > 5)
				{
					ToastUtils.showText("最多@5个人!");
					return;
				}
				this.$nextTick(function(){
					//console.log("=========handleAtMember");
					
					GroupAtMemberManager.start(this.inputMaxlength);
					GroupAtMemberManager.setCursor(cursor);
					GroupAtMemberManager.setInputValue(this.textMsg);
					ChatJumpHelper.jumpToGroupMemberList(this.groupInfo.id, 'at');
					
					this.refreshDefault();
				})
			},
			backText()
			{
				if(StringUtils.isEmpty(this.textMsg))
				{
					return;
				}
				let value = this.textMsg;
				let len = value.length;
				this.textMsg = StringUtils.substr(value, 0, len - 2);
			},
			//添加表情
			addEmoji(em){
				this.textMsg+=em.alt;
			},
			
			//=================================================== 语音消息
			// 播放语音
			playVoice(row){
				// this.playMsgid=row.id;
				// this.AUDIO.src = row.data.url;
				// this.AUDIO.src = '/static/voice/2.mp3';
				
				// this.$nextTick(function() {
				// 	this.AUDIO.play();
				// });
				
				if(!StringUtils.isEmpty(this.playMsgid))
				{
					this.playMsgid = null;
					this.AUDIO.stop();
				}
				this.playMsgid=row.id;
				this.AUDIO.src = row.data.url;
				//this.AUDIO.src = '/static/voice/2.mp3';
				this.$nextTick(function() {
					this.AUDIO.play();
				});
			},
			// 录音开始
			onVoiceBegin(e){
				if(e.touches.length>1){
					return ;
				}
				this.recording = true;
				this.initPoint.Y = e.touches[0].clientY;
				this.initPoint.identifier = e.touches[0].identifier;
				this.$refs.mChatRecordUI.start();
			},
			// 录音被打断
			onVoiceCancel(){
				this.recording = false;
				this.voiceTis='按住 说话';
				this.$refs.mChatRecordUI.cancer();
			},
			// 录音中(判断是否触发上滑取消发送)
			onVoiceIng(e){
				if(!this.recording){
					return;
				}
				let touche = e.touches[0];
				//上滑一个导航栏的高度触发上滑取消发送
				if(this.initPoint.Y - touche.clientY>=uni.upx2px(100)){
					this.$refs.mChatRecordUI.updateStopStatus(true);
				}else{
					this.$refs.mChatRecordUI.updateStopStatus(false);
				}
			},
			// 结束录音
			onVoiceEnd(e){
				if(!this.recording){
					return;
				}
				this.recording = false;
				this.voiceTis='按住 说话';
				this.$refs.mChatRecordUI.stop();
			},
			//录音结束(回调文件)
			onRecordFinish(e){
				let recordPath = e.recordPath;
				let recordLenght = e.recordLenght;
				// 上传音频地址
				let that = this;
				IMApi.uploadVoice(recordPath, (data) => {
					//console.log("voice url = ", data);
					MessageHelper.sendVoice(that.groupInfo.id, that.messageEvent, data, recordLenght);
				}, null);
			},
			//=================================================== 图片消息
			//选照片 or 拍照
			chooseImage(type){
				this.refreshDefault(false);
				ChatViewManager.doChooseImage(type, this.groupInfo.id, this.messageEvent)
			},
			
			// 打开红包
			openRedEnvelope(msg,index){
			},
			// 预览图片
			showPic(row){
				this.optStatus = this.optStatusMap.showpic;
				ChatViewManager.doShowPicture(row, this.msgList);
			},
			discard(){
				return;
			},
			
			//=================================================== 消息处理
			handleFriendTitle(item)
			{
				let fromUserid = item.fromUserid;
				let friendInfo = FriendInfoManager.getFriendInfo(fromUserid);
				
				if(!StringUtils.isEmpty(friendInfo.alias))
				{
					return friendInfo.alias;
				}
				if(!StringUtils.isEmpty(friendInfo.nickname))
				{
					return friendInfo.nickname;
				}
				return friendInfo.username;
			},
			
			handleFriendAvatar(item)
			{
				let fromUserid = item.fromUserid;
				let friendInfo = FriendInfoManager.getFriendInfo(fromUserid);
				return friendInfo.avatar;
			},
			
			//=================================================== 消息监听
			/**
			 * 监听消息回调
			 * @param {Object} dataArray
			 */
			onReceivedMessage(dataArray)
			{
				this.msgList = dataArray;
				//console.log(dataArray);
				this.updateContentHeight(true);
				
				//console.log(this.msgList);
			},
			
			//=================================================== 底部更多按钮
			// 选择图片发送
			openAlbum(){
				this.chooseImage('album');
			},
			//拍照发送
			openCamera(){
				this.chooseImage('camera');
			},
			openPersonCard()
			{
				this.optStatus = this.optStatusMap.dispatch;
				let body = ProtocolHelper.card(this.groupInfo.id, this.messageEvent, '', '', '');
				ChatJumpHelper.jumpToShareCard(body);
				this.hideDrawer();
			},
			jumpToUserBasicInfo(item)
			{
				let username = '';
				if(StringUtils.isEqual(item.msgType, BasicMsgType.CARD))
				{
					username = item.data.username;
				}
				else
				{
					username = item.fromUserid;
				}
				ChatJumpHelper.jumpToUserBasicInfo(username);
			},
			
			/**
			 * 好友验证请求
			 */
			sendAddFriendRequest()
			{
				return;
				if(FriendCMDManager.isFriend(this.friendInfo.username))
				{
					ToastUtils.showText("你已是对方的好友了!");
					return;
				}
				let that = this;
				let remark = '';
				if(!StringUtils.isEmpty(this.friendInfo.nickname))
				{
					remark = "我是" + this.friendInfo.nickname;
				}
				FriendApi.addFriend(that.friendInfo.username, remark, () => 
				{
					ToastUtils.showSuccess('验证请求已发送', null);
				}, 
				//
				(code, msg) => 
				{
					// 已为好友
					if(code == -16)
					{
						FriendCMDManager.refreshFriendList(true, null);
						// 你已添加了
						let showName = that.friendInfo.username;
						if(!StringUtils.isEmpty(that.friendInfo.alias))
						{
							showName = that.friendInfo.alias;
						}
						else if(!StringUtils.isEmpty(that.friendInfo.nickname))
						{
							showName = that.friendInfo.nickname;
						}
						let content = '你已添加了' + showName + ", 现在可以聊天了。";
						let body = ProtocolHelper.localTextTips(that.friendUsername, 'single', content);
						MessageHelper.sendMessage(body);
					}
					else
					{
						ToastUtils.showFailure(msg);
					}
				})
			},
			//=================================================== 底部按钮
		}
	}
</script>
<style lang="scss">
	@import "@/components/pg-chat/style.scss"; 
	.add image{width: 30px;height: 30px;margin-top: 6px;}
	
	.voice image{width: 30px;height: 30px;margin-top: 6px}
	.biaoqing{padding-right: 5px;}
	.biaoqing image{width: 30px;height: 30px;margin-top: 8px;}
	.uni-swiper-dots{bottom: 0;}
</style>