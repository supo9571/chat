<template>
	
	<!-- 文字消息 -->
	<!-- 
		@touchstart.stop.prevent="discard"
		@touchmove.stop.prevent="discard"
		-->
	<view v-if="BasicMsgType.TEXT == row.msgType" class="bubble"
		@longpress="openActionSheet(row)">
		<rich-text :nodes="row.data.showText"></rich-text>
	</view>
	<!-- 语言消息 -->
	<view v-else-if="BasicMsgType.VOICE == row.msgType" 
		@longpress="openActionSheet(row)"
		class="bubble voice" 
		@click.stop="playVoice(row)" 
		:class="playMsgid == row.id?'play':''">
		<view class="length">{{row.data.playTime}}</view>
		<view class="icon my-voice"></view>
	</view>
	<!-- 图片消息 -->
	<view v-else-if="BasicMsgType.IMAGE == row.msgType"
		@longpress="openActionSheet(row)"
		class="bubble img" 
		@click.stop="showPic(row)">
		<pg-image-cache :imgSrc="row.data.url" :style="{'width': row.data.width+'px','height': row.data.height+'px'}"></pg-image-cache>
	</view>
	<!-- 名片消息 -->
	<view v-else-if="BasicMsgType.CARD == row.msgType" class="bubble card" 
		@longpress="openActionSheet(row)"
		@click.stop="jumpToUserBasicInfo(row)">
		<view class="card_top">
			<view class="card_top_img"><pg-image-cache :imgSrc="row.data.avatar"></pg-image-cache></view>
			<view class="card_top_rg">
				<view>{{row.data.nickname}}</view>
				<view>{{row.data.username}}</view>
			</view>
		</view>
		<view class="card_bot">个人名片</view>
	</view>
	<!-- 红包 -->
	<view v-else-if="BasicMsgType.RED_PACKET == row.msgType" class="bubble red-envelope" @click="openRedEnvelope(row.msg,index)">
		<pg-image-cache imgSrc="/static/chat/red-envelope.png"></pg-image-cache>
		<view class="tis">
			<!-- 点击开红包 -->
		</view>
		<view class="blessing">
			<!-- 祝福语 -->
			{{row.data.blessing}}
		</view>
	</view>
	<!-- 消息不支持 -->
	<view v-else class="bubble">
		<text>该消息不支持,请升级最新版本</text>
	</view>
	
</template>

<script>
	
import actionSheet from "@/components/pg-actionsheet/pg-actionsheet.vue"

// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import CachePolicy from '@/pages/framework/http/CachePolicy.js'
import ToastUtils from "@/pages/framework/utils/ToastUtils.js"
import EmotionUtils from "@/pages/framework/utils/EmotionUtils.js"
import chatRecord from "@/components/pg-chat/chat-record.vue"

// user
import UserApi from '@/pages/user/service/UserApi.js'
import UserManager from '@/pages/user/logical/UserManager.js'
import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'

// chat
import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
import MessageEvent from "@/pages/chat/logical/MessageEvent.js"
import BasicMsgType from "@/pages/chat/logical/BasicMsgType.js"
import LocalMsgType from "@/pages/chat/logical/LocalMsgType.js"
import ChatTimeHelper from "@/pages/chat/helper/ChatTimeHelper.js"
import GroupChatManager from "@/pages/chat/logical/handler/GroupChatManager.js"
import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
import FriendInfoManager from "@/pages/chat/logical/FriendInfoManager.js"
import FriendCMDManager from "@/pages/chat/logical/handler/FriendCMDManager.js"
import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
import ChatViewManager from "@/pages/chat/logical/ChatViewManager.js"

import GroupAtMemberManager from "@/pages/chat/logical/GroupAtMemberManager.js"

import IMApi from "@/pages/chat/service/IMApi.js"
import FriendApi from "@/pages/chat/service/FriendApi.js"
	
export default {
	name: 'pg-chat-item-msg',
	components: {
		"pg-actionsheet" : actionSheet,
		chatRecord,
	},
	props: {
		row : {
			type: Object,
		},
		msgList : {
			type: Array,
		}
	},
	data() {
		return {
			
			//文字消息
			// dotsCurrent:1,
			textMsg:'',
			inputMaxlength : 150,
			isActiveSend : false, // 
			//消息列表
			isHistoryLoading:false,
			scrollAnimation:false,
			scrollTop:0,
			scrollToView:'',
			myuid:0,
			
			optStatusMap : {
				def : 'def',
				voice : 'voice',
				input : 'input',
				more : 'more',
				emotion : 'emotion',
				showpic : 'showpic',
				dispatch : 'dispatch',
			},
			
			optStatus : 'def', // default, voice, input, more, emotion
			
			//录音相关参数
			recording:false,
			voiceTis:'按住 说话',
			initPoint:{identifier:0,Y:0},
			
			//播放语音相关参数
			AUDIO:uni.createInnerAudioContext(),
			playMsgid:null,
			VoiceTimer:null,
			// 抽屉参数
			popupLayerClass:'',
			// more参数
			//hideMore:true,
			//表情定义
			//hideEmoji:true,
			emojiList:[{}],
			emojiPath:'https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/',
			//emojiPath : 'https://s2.ax1x.com/2019/04/12/',
			
			//红包相关参数
			windowsState:'',
			redenvelopeData:{
				rid:null,	//红包ID
				from:null,
				face:null,
				blessing:null,
				money:null
			},
			
			// 实体信息
			groupInfo : {
				id : '',
			},
			userInfo : {
				username : '',
				nickname : '',
				avatar : '',
			},
			
			// 引入进来的都要在这里定义下
			BasicMsgType : BasicMsgType,
			LocalMsgType : LocalMsgType,
			
			//
			ChatTimeHelper : ChatTimeHelper,
			ProtocolHelper : ProtocolHelper,
			ChatViewManager : ChatViewManager,
			
			//
			messageEvent : 'group',
			
			longPress : {
				loopTime : -1,
			},
			
			actionSheet : {
				optValue : null,
				show: false,
				maskClosable: true,
				tips: "",
				currentItemList : [],
				leftItemList : [
					{text: "复制",color: "#1a1a1a"},
					{text: "删除",color: "#1a1a1a"},
				],
				rightItemList: [
					{text: "复制",color: "#1a1a1a"},
					{text: "删除",color: "#1a1a1a"},
					//{text: "撤回",color: "#1a1a1a"},
				],
				color: "#9a9a9a",
				size: 26,
				isCancel: true
			},
		};
	},
	
	mounted() {
		//语音自然播放结束
		this.AUDIO.onEnded((res)=>{
			this.playMsgid=null;
		});
	},

	methods: {
		
		// =========================== 长按相关================
		openActionSheet(optValue){
			let itemList = [];
			this.actionSheet.optValue = optValue;
			let item = optValue;
			if(StringUtils.isEqual(BasicMsgType.TEXT, item.msgType))
			{
				//itemList.push({text: "复制",color: "#1a1a1a"});
			}
			itemList.push({text: "删除",color: "#1a1a1a"});
			if(ProtocolHelper.isSelfProtocol(item))
			{
				// 没有发送成功
				if(!item.status)
				{
					let resendItem = {text: "重发",color: "#1a1a1a"};
					itemList.push(resendItem);
				}
				// 时间超过120s 不能撤回
				let date = new Date();
				if( date.getTime() - item.time <= 120000)
				{
					let resendItem = {text: "撤回",color: "#1a1a1a"};
					itemList.push(resendItem);
				}
			}
			
			if(
				StringUtils.isEqual(BasicMsgType.TEXT, this.actionSheet.optValue.msgType) || 
				StringUtils.isEqual(BasicMsgType.IMAGE, this.actionSheet.optValue.msgType))
			{
				// 
				let dispatchItem = {text: "转发", color: "#1a1a1a"};
				itemList.push(dispatchItem);
			}
			if(StringUtils.isEqual(item.msgType, BasicMsgType.IMAGE))
			{
				let album = {text: "图册",color: "#1a1a1a"};
				itemList.push(album)
			}
			this.actionSheet.currentItemList = itemList;
			this.actionSheet.show = true;
			//
			this.$nextTick(function(){
				uni.hideKeyboard();
			})
		},
		closeActionSheet: function() {
			this.actionSheet.optValue = null;
			this.actionSheet.show = false;
		},
		onActionSheetItemClick: function(e) {
			if(this.actionSheet.optValue == null)
			{
				return;
			}
			let index = e.index;
			let itemTextValue = this.actionSheet.currentItemList[index].text;
			if(StringUtils.isEqual(itemTextValue, '复制'))
			{
				let content = ProtocolHelper.getProtocolText(this.actionSheet.optValue);
				uni.setClipboardData({
				    data: content
				});
			}
			else if(StringUtils.isEqual(itemTextValue, '删除'))
			{
				GroupChatManager.deleteMessage(this.actionSheet.optValue);
			}
			else if(StringUtils.isEqual(itemTextValue, '撤回'))
			{
				let msgBody = ProtocolHelper.revoke(this.actionSheet.optValue);
				MessageHelper.sendMessage(msgBody);
			}
			else if(StringUtils.isEqual(itemTextValue, '图册'))
			{
				this.showPic(this.actionSheet.optValue);
			}
			else if(StringUtils.isEqual(itemTextValue, '重发'))
			{
				// 重新发送
				this.actionSheet.optValue.optType = 'resend';
				MessageHelper.sendMessage(this.actionSheet.optValue);
			}
			else if(StringUtils.isEqual(itemTextValue, '转发'))
			{
				isActive = true;
				// 转发
				ChatJumpHelper.jumpToShareToConversation(this.actionSheet.optValue);
			}
			
			this.closeActionSheet();
		},
		
		// 打开红包
		openRedEnvelope(msg,index){
		},
		// 预览图片
		showPic(row){
			ChatViewManager.doShowPicture(row, this.msgList);
		},
		
		//=================================================== 语音消息
		// 播放语音
		playVoice(row){
			// this.playMsgid=row.id;
			// this.AUDIO.src = row.data.url;
			// this.AUDIO.src = '/static/voice/2.mp3';
			
			// this.$nextTick(function() {
			// 	this.AUDIO.play();
			// });
			
			if(!StringUtils.isEmpty(this.playMsgid))
			{
				this.playMsgid = null;
				this.AUDIO.stop();
			}
			this.playMsgid=row.id;
			this.AUDIO.src = row.data.url;
			//this.AUDIO.src = '/static/voice/2.mp3';
			this.$nextTick(function() {
				this.AUDIO.play();
			});
		},
		// 录音开始
		onVoiceBegin(e){
			if(e.touches.length>1){
				return ;
			}
			this.recording = true;
			this.initPoint.Y = e.touches[0].clientY;
			this.initPoint.identifier = e.touches[0].identifier;
			this.$refs.mChatRecordUI.start();
		},
		// 录音被打断
		onVoiceCancel(){
			this.recording = false;
			this.voiceTis='按住 说话';
			this.$refs.mChatRecordUI.cancer();
		},
		// 录音中(判断是否触发上滑取消发送)
		onVoiceIng(e){
			if(!this.recording){
				return;
			}
			let touche = e.touches[0];
			//上滑一个导航栏的高度触发上滑取消发送
			if(this.initPoint.Y - touche.clientY>=uni.upx2px(100)){
				this.$refs.mChatRecordUI.updateStopStatus(true);
			}else{
				this.$refs.mChatRecordUI.updateStopStatus(false);
			}
		},
		// 结束录音
		onVoiceEnd(e){
			if(!this.recording){
				return;
			}
			this.recording = false;
			this.voiceTis='按住 说话';
			this.$refs.mChatRecordUI.stop();
		},
		//录音结束(回调文件)
		onRecordFinish(e){
			let recordPath = e.recordPath;
			let recordLenght = e.recordLenght;
			// 上传音频地址
			let that = this;
			IMApi.uploadVoice(recordPath, (data) => {
				//console.log("voice url = ", data);
				MessageHelper.sendVoice(that.groupInfo.id, that.messageEvent, data, recordLenght);
			}, null);
		},
	}
}
	
</script>



<style lang="scss">
	@import "@/components/pg-chat/style.scss"; 
	.add image{width: 30px;height: 30px;margin-top: 6px;}
	
	.voice image{width: 30px;height: 30px;margin-top: 6px}
	.biaoqing{padding-right: 5px;}
	.biaoqing image{width: 30px;height: 30px;margin-top: 8px;}
	.uni-swiper-dots{bottom: 0;}
</style>
