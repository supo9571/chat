<template>
	<view>
		<view class="uni-form-item uni-column">
			<input class="uni-input" v-model="inputValue" placeholder-style="color:#999" placeholder="请输入内容" />
		</view>
	</view>
</template>

<script>
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	
	// chat
	import ChatJumpHelper from "@/pages/chat/helper/ChatJumpHelper.js"
	import UserManager from "@/pages/user/logical/UserManager.js"
	import FriendApi from "@/pages/chat/service/FriendApi.js"
	import GroupApi from "@/pages/chat/service/GroupApi.js"
	import GroupCMDManager from "@/pages/chat/logical/handler/GroupCMDManager.js"
	
	import ProtocolHelper from "@/pages/chat/helper/ProtocolHelper.js"
	import MessageHelper from "@/pages/chat/helper/MessageHelper.js"
	
	import JumpManager from "@/pages/main/logical/JumpManager.js"
	
	export default {
		components:{
			
		},
		data(){
			return {
				modifyType : '',
				groupid : '',
				
				inputValue : ''
			}
		},
		onLoad(options) {
			let data = JSON.parse(decodeURIComponent(options.data));
			this.modifyType = data.modifyType;
			this.groupid = data.groupid;
			
			let groupInfo = GroupCMDManager.getGroupInfo(this.groupid);
			if(StringUtils.isEqual(this.modifyType, "modify_group_name"))
			{
				this.inputValue = groupInfo.alias;
				if(!StringUtils.isEmpty(groupInfo.name))
				{
					this.inputValue = groupInfo.name;
				}
			}
			
		},
		onNavigationBarButtonTap(res) {
			uni.hideKeyboard();
			
			if(StringUtils.isEmpty(this.inputValue))
			{
				ToastUtils.showText("内容不能为空！");
				return;
			}
			
			if(StringUtils.isEqual(this.modifyType, "modify_group_name"))
			{
				this.modifyGroupName();
			}
		},
		
		methods:{
			modifyGroupName()
			{
				GroupApi.updateGroupName(this.groupid, this.inputValue, () => 
				{
					uni.navigateBack();
				}, null);
			},
			
		}
		
	}
</script>

<style>
	.title{font-size: 14px;margin-top: 8px;color: #999;}
</style>
