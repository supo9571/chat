// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import RegexUtils from '@/pages/framework/utils/RegexUtils.js'
import ConfigHelper from '@/pages/framework/config/ConfigHelper.js'

const UserDefHelper = {
	
	getAvatar(value)
	{
		if(StringUtils.isEmpty(value))
		{
			value = ConfigHelper.getString('static_server') + '/static/pg_def_avatar.png';
		}
		else if(!RegexUtils.isUrl(value))
		{
			value = ConfigHelper.getString('upload_server') + value;
		}
		return value;
	},
	
	getNickname(value)
	{
		if(StringUtils.isEmpty(value))
		{
			return '未设置'
		}
		return value;
	},
}

export default UserDefHelper;