// framework
import StringUtils from '@/pages/framework/utils/StringUtils.js'
import RouterUtils from '@/pages/framework/utils/RouterUtils.js'
import Cache from '@/pages/framework/cache/Cache.js'

import ChatManager from "@/pages/chat/logical/ChatManager.js"
import ConversationManager from '@/pages/chat/logical/ConversationManager.js'

import UserManager from '@/pages/user/logical/UserManager.js'

/**
 * 用户相关路由管理器
 */
const UserJumpHelper = {
	
	handleRouter(key, parameter)
	{
		if(StringUtils.isEqual("user_login", key))
		{
			this.jumpToLogin();
		}
		else if(StringUtils.isEqual("user_reg", key))
		{
			this.jumpToRegister();
		}
		else
		{
			console.log("unknow route key : ", key);
		}
	},
	
	// setActiveLogin(active)
	// {
	// 	this.mActiveLogin = active;
	// },
	
	jumpToLogin()
	{
		//console.log("jumpToLogin===========");
		// if(this.mActiveLogin == true)
		// {
		// 	return;
		// }
		
		// 删除用户
		//UserManager.deleteUser();
		
		// 关闭socket
		//ChatManager.logout();
		
		RouterUtils.reLaunch({
			url:'/pages/user/view/Login'
		})
	},
	
	jumpToRegister()
	{
		RouterUtils.navigateTo({
			url:'/pages/user/view/Register'
		})
	},
	
	jumpToMyQrcodeCard()
	{
		RouterUtils.navigateTo({
			url:'/pages/user/view/more/MyQrcodeCard'
		})
	},
	
	jumpToModifyNickname()
	{
		RouterUtils.navigateTo({
			url:'/pages/user/view/more/ModifyNickname'
		})
	},
	
	jumpToModifyPassword()
	{
		RouterUtils.navigateTo({
			url:'/pages/user/view/ModifyPassword'
		})
	}
	
}



export default UserJumpHelper