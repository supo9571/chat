<template>
	<view>
		<view class="uni-form-item uni-column">
			<view class="title">昵称</view>
			<input class="uni-input" v-model="nickname" placeholder-style="color:#999" placeholder="昵称" />
		</view>
	</view>
</template>

<script>

	import StringUtils from "@/pages/framework/utils/StringUtils.js"

	import UserApi from "@/pages/user/service/UserApi.js"
	import UserManager from "@/pages/user/logical/UserManager.js"
	
	export default {
		data() {
			return {
				nickname : ''
			}
		},
		
		onShow() {
			this.nickname = UserManager.getUserInfo().nickname;
		},
		onNavigationBarButtonTap(res) {
			this.updateNickname();
		},
		methods: {
			updateNickname()
			{
				console.log("fasdfa")
				if(StringUtils.isEmpty(this.nickname))
				{
					return;
				}
				let userInfo = UserManager.getUserInfo();
				if(StringUtils.isEqual(userInfo.nickname, this.nickname))
				{
					return;
				}
				
				UserApi.updateNickname(this.nickname, () => 
				{
					uni.navigateBack();
				}, null);
			}
		}
	}

</script>

<style>
</style>
