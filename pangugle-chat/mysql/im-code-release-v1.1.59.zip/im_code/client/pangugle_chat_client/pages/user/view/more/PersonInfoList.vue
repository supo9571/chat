<template>
	
	<view>
		<!-- <view class="pg_list">
			<view class="pg_list_single_item pg_separator_line_left pg_navigate_right" hover-class="uni-list-cell-hover" >
				<text>头像</text>
				<view class="pg_list_single_item_right">
					<avatar
					    selWidth="200px" selHeight="400upx" @upload="updateAvatar" :avatarSrc="this.userInfo.avatar"
						avatarStyle="width: 130upx;height: 130upx;border-radius: 10upx;"
						>
					</avatar>
					
					<image class="avatar" :src="this.getAvatar()"></image>
					
				</view>
			</view>
			
			<view class="pg_list_single_item pg_separator_line_left pg_navigate_right" 
				@click="jumpToModifyNickname"
				hover-class="uni-list-cell-hover" >
				<text>昵称</text>
				<view class="pg_list_single_item_right">
					<text>{{this.userInfo.nickname}}</text>
				</view>
			</view>
			
			<view class="pg_list_single_item pg_separator_line_left" hover-class="uni-list-cell-hover" >
				<text>用户名</text>
				<view class="pg_list_single_item_right">
					<text>{{this.userInfo.username}}</text>
				</view>
			</view>
			
			<view class="pg_list_single_item pg_separator_line_left pg_navigate_right" 
				@click="jumpToMyQrcodeCard"
				hover-class="uni-list-cell-hover" >
				<text>二维码名片</text>
				<view class="pg_list_single_item_right">
					<image class="qrcode" src="/static/pg_def_qrcode.png"></image>
				</view>
			</view>
		</view> -->
		
		
		<uni-list>
			
			<view class="uni-list-cell" hover-class="uni-list-cell-hover">
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="pg_list_cell_left">头像</text>
					  <view class="pg_list_cell_right">
						  <avatar
						      selWidth="200px" selHeight="200px" @upload="updateAvatar" :avatarSrc="userInfo.avatar"
						  	avatarStyle="width: 50px;height: 50px;border-radius: 5px;"
						  	>
						  </avatar>
					  </view>
				  </view>
			 </view>
			
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" @click="jumpToModifyNickname">
				  <view class="uni-list-cell-navigate uni-navigate-right">
					  <text class="pg_list_cell_left">昵称</text>
					  <view class="pg_list_cell_right uni-ellipsis">
						  <text>{{userInfo.nickname}}</text>
					  </view>
				  </view>
			 </view>
			 <view class="uni-list-cell" >
			 	  <view class="uni-list-cell-navigate ">
			 		  <text class="pg_list_cell_left">用户名</text>
			 		  <view class="pg_list_cell_right uni-ellipsis">
			 			  <text>{{userInfo.username}}</text>
			 		  </view>
			 	  </view>
			  </view>
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" @click="jumpToMyQrcodeCard">
			 	  <view class="uni-list-cell-navigate uni-navigate-right">
			 		  <text class="pg_list_cell_left">二维码名片</text>
					  <view class="pg_list_cell_right">
						  <image class="qrcode" src="/static/pg_def_qrcode.png"></image>
					  </view>
			 	  </view>
			  </view>
			
			
		</uni-list>
		
	</view>
</template>

<script>
	
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import avatar from "@/components/yq-avatar/yq-avatar.vue";
	
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserManager from '@/pages/user/logical/UserManager.js'
	import UserJumpHelper from '@/pages/user/helper/UserJumpHelper.js'
	
	export default {
		components: {
			uniList,
			uniListItem,
			avatar
		},
		data() {
			return {
				userInfo : {
					username : '',
					nickname : '',
					avatar : ''
				},
				
				reload : false,
			}
		},
		onShow() {
			
			UserApi.getUserInfo(this.reload, userInfo => {
				this.userInfo = userInfo;
				//console.log("user info  : ", this.userInfo)
			});
		},
		methods: {
			updateAvatar(res) {
				let self = this;
				this.userInfo.avatar = res.path;
				//console.log(res);
				UserApi.uploadAvatar(this.userInfo.avatar, (avatarURL) => {
					//console.log(res);
					console.log("user :", UserManager.getUserInfo().avatar);
					self.userInfo.avatar = avatarURL;
				}, 
				(code, msg) => 
				{
					
				});
			},
			updateNickname() {
				
			},
			
			jumpToMyQrcodeCard()
			{
				UserJumpHelper.jumpToMyQrcodeCard();
			},
			
			jumpToModifyNickname()
			{
				UserJumpHelper.jumpToModifyNickname();
			}
			
		}
	}
</script>

<style>

	.avatar{width: 130upx;height: 130upx;border-radius: 10upx;}
	.qrcode{width: 50upx;height: 50upx;}
	
</style>
