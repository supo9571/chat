<template>
	<view>
		<view class="uni-form-item uni-column">
			<input class="uni-input" v-model="oldPwd" password="true" placeholder-style="color:#999" placeholder="填写旧密码" />
		</view>
		<view class="uni-form-item uni-column">
			<input class="uni-input" v-model="newPwd" password="true" placeholder-style="color:#999" placeholder="填写新密码" />
		</view>
		<view class="uni-form-item uni-column">
			<input class="uni-input" v-model="newPwd2" password="true"  placeholder-style="color:#999" placeholder="再次填写新密码" />
		</view>
	</view>	
</template>

<script>
	
	
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"
	import UserManager from '@/pages/user/logical/UserManager.js'
	
	
	export default {
		data() {
			return {
				oldPwd : '',
				newPwd : '',
				newPwd2 : '',
			}
		},
		onNavigationBarButtonTap(e) {
			this.updatePassword();
		},
		methods: {
			
			updatePassword()
			{
				if(StringUtils.isEmpty(this.oldPwd))
				{
					ToastUtils.showText("请输入旧密码!");
					return;
				}
				if(StringUtils.isEmpty(this.newPwd))
				{
					ToastUtils.showText("请输入新密码!");
					return;
				}
				if(this.newPwd.length < 6)
				{
					ToastUtils.showText("新密码长度不能小于6位!");
					return;
				}
				if(StringUtils.isEmpty(this.newPwd2))
				{
					ToastUtils.showText("请输入确认密码!");
					return;
				}
				if(!StringUtils.isEqual(this.newPwd, this.newPwd2))
				{
					ToastUtils.showText("新密码输入不一致!");
					return;
				}
				if(StringUtils.isEqual(this.oldPwd, this.newPwd))
				{
					ToastUtils.showText("旧密码和新密码不能相同!");
					return;
				}
				
				UserApi.updatePassword(this.oldPwd, this.newPwd, this.newPwd2, ()=>
				{
					UserJumpHelper.jumpToLogin();
				}, null);
			}
			
		}
		
	}
	
</script>

<style>
</style>
