
export default class UserInfo {
	
	constructor() {
	    this.username = '';
		this.nickname = '';
	}
	
}