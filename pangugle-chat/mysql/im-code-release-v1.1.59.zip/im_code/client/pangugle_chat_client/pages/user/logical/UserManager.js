// framework
import Cache from '@/pages/framework/cache/Cache.js'
import StringUtils from '@/pages/framework/utils/StringUtils.js'

const DEFAULT_ACCESS_TOKEN_KEY = 'passport_access_token'
const DEFAULT_ACCESS_TOKEN_EXPIRES_TIME_KEY = 'passport_access_token_expires_time'
const DEFAULT_LOGIN_TOKEN_KEY = 'passport_login_token'
const DEFAULT_USER_INFO_KEY = 'passport_user_info'
const DEFAULT_FRIEND_INFO_KEY = 'passport_friend_info'

const DEFAULT_LAST_LOGIN_USERNAME = "passport_last_login_username";

/**
 * 用户信息管理类
 */
const UserManager = {
	
	saveLastLoginUsername(username)
	{
		Cache.setValue(DEFAULT_LAST_LOGIN_USERNAME, username);
	},
	
	getLastLoginUsername()
	{
		return Cache.getValue(DEFAULT_LAST_LOGIN_USERNAME) || null; 
	},
	
	isSameUsernameLogin(username)
	{
		let lastUsername = Cache.getValue(DEFAULT_LAST_LOGIN_USERNAME);
		return StringUtils.isEqual(username, lastUsername);
	},
	
	//============= accessToken start =============
	saveAccessToken(token)
	{
		Cache.setValue(DEFAULT_ACCESS_TOKEN_KEY, token);
	},
	
	getAccessToken()
	{
		return Cache.getValue(DEFAULT_ACCESS_TOKEN_KEY);
	},
	
	saveAccessTokenExpires(expiresTime)
	{
		var nowDate = new Date();
		var timeStamp = nowDate.getTime() / 1000 + expiresTime;// 精确到秒
		Cache.setValue(DEFAULT_ACCESS_TOKEN_EXPIRES_TIME_KEY, timeStamp);
	},
	
	isValidAccessToken()
	{
		var expiresTime = Cache.getValue(DEFAULT_ACCESS_TOKEN_EXPIRES_TIME_KEY) || -1;
		if(expiresTime <= 0)
		{
			return false;
		}
		var nowDate = new Date();
		var timeStamp = nowDate.getTime() / 1000;
		// 600s 表示token即将过期, 让accessToken 提前失效
		if(expiresTime - timeStamp < 600)
		{
			return false;
		}
		return true;
	},
	
	//============= loginToken start =============
	saveLoginToken(token) 
	{
		Cache.setValue(DEFAULT_LOGIN_TOKEN_KEY, token);
	},
	
	getLoginToken()
	{
		return Cache.getValue(DEFAULT_LOGIN_TOKEN_KEY);
	},
	
	//============= other start =============
	isLogin()
	{
		let accessToken = UserManager.getAccessToken(DEFAULT_ACCESS_TOKEN_KEY);
		if(!StringUtils.isEmpty(accessToken))
		{
			return true;
		}
		else
		{
			return false;
		}
	},
	
	//
	saveUserInfo(userInfo){
		this.mUserInfo = userInfo;
		Cache.setValue(DEFAULT_USER_INFO_KEY, userInfo);
	},
	
	getUserInfo()
	{
		if(this.mUserInfo == null || StringUtils.isEmpty(this.mUserInfo.username))
		{
			this.mUserInfo = Cache.getValue(DEFAULT_USER_INFO_KEY);
		}
		return this.mUserInfo;
	},
	
	deleteUser()
	{
		// 删除token
		Cache.deleteValue(DEFAULT_ACCESS_TOKEN_KEY);
		Cache.deleteValue(DEFAULT_LOGIN_TOKEN_KEY);
		
		// 删除用户信息
		Cache.deleteValue(DEFAULT_USER_INFO_KEY);
		
		this.mUserInfo = null;
	}
}



export default UserManager