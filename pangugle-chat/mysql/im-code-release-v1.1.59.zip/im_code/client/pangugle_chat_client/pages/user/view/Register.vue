<template>
	<view class="login_box">
		<!-- <image class="logo" src="/static/logo.png"></image> -->
		<view class="input_box">
			<input type="text" v-model="username" @input="onUsernameChange" placeholder="用户名(小写字母+数字>=6位字符)" />
		</view>
		<view class="input_box">
			<input type="text" v-model="nickname" @input="onNicknameChange" placeholder="昵称" />
		</view>
		<view class="input_box">
			<input type="password" v-model="password" @input="onPasswordChange" placeholder="密码" />
		</view>
		<view class="input_box">
			<input type="password" v-model="password2" @input="onPasswordChange2" placeholder="确认密码" />
		</view>
		<view class="btn_box">
		    <button hover-class="hover" @click="register()">注册</button>
		</view>
		<!-- 验证码弹出框 show: false :show="show" this.show = true -->
		<uni-popup ref="popup" :custom="true" type="center">
			<view class="uni-tip">
				<view class="uni-tip-title">请输入验证码</view>
				<view class="uni-tip-content"> 
					<input class="code_inp" type="text" v-model="imgCode" @input="onImgCodeChange" placeholder="验证码" />
					<!-- <image class="code_img" src="/static/logo.png"></image> -->
				</view>
				<view class="uni-tip-group-button">
					<view class="uni-tip-button" @click="cancel()">取消</view>
					<view class="uni-tip-button" @click="yes()">确定</view>
				</view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import RouterUtils from '@/pages/framework/utils/RouterUtils.js'
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	
	//user
	import UserApi from '@/pages/user/service/UserApi.js'
	
	export default {
		components: {
			uniPopup
		},
		data() {
			return {
				username  : '',
				nickname  : '',
				password  : '',
				password2 : '',
				imgCode:''
			}
		},
		methods: {
			onUsernameChange(event){
				// 实时更新,处理空格
				var val = event.target.value;
			},
			onNicknameChange(event){
				// 实时更新,处理空格
				var val = event.target.value;
			},
			onPasswordChange(event){
				// 实时更新,处理空格
				var val = event.target.value;
			},
			onPasswordChange2(event){
				// 实时更新,处理空格
				var val = event.target.value;
			},
			
			register:function(){
				uni.hideKeyboard();
				var reg = /^[0-9a-zA-Z]+$/;
				
				if(StringUtils.isEmpty(this.username) ||　this.username.length < 6 || !reg.test(this.username))
				{
					ToastUtils.showText("用户名输入有误, 长度大于等于6且小于等于20的字母和数字组合!");
					return;
				}
				if(StringUtils.isEmpty(this.nickname) || this.nickname.length < 1)
				{
					ToastUtils.showText("昵称输入有误!");
					return;
				}
				if(StringUtils.isEmpty(this.password))
				{
					ToastUtils.showText("密码输入有误!");
					return;
				}
				if(StringUtils.isEmpty(this.password2))
				{
					ToastUtils.showText("确认密码输入有误!");
					return;
				}
				if(!StringUtils.isEqual(this.password, this.password2))
				{
					ToastUtils.showText("两次密码不一致!");
					return;
				}
				// console.log("username = ", this.username);
				// console.log("nickname = ", this.nickname);
				// console.log("password = ", this.password);
				// console.log("password2 = ", this.password2);
				
				UserApi.registerByUsername(this.username, this.nickname, this.password, this.password2, this.imgCode, 
				() => {
					
					ToastUtils.showText("注册成功", () => {
						uni.navigateBack();
					})
				});
				return;
				this.imgCode='';
				this.$refs.popup.open();
			},
			yes:function(){
				this.$refs.popup.close();
			},
			cancel:function(){
				this.$refs.popup.close();
			}
		}
		
	}
</script>

<style>
	page{
		background: #f5f5f5;
		height: 100%;width: 100%;
		display: flex;
		display: -webkit-flex;
		justify-content:center;
		align-items:center;
	}
	.login_box{
		width: 350px;
		top: 50%;
		background-color: #fff;
		border-radius: 4px;
		box-shadow: 0 0 8px rgba(0, 0, 0, .1);
		padding: 45px 35px 65px 35px;
		margin-top: -30px;
		display: flex;
		display: -webkit-flex;
		flex-direction:column;
	}
	.logo{
		width: 52px;height: 52px;
		margin-left: auto;
		margin-right: auto;
	}
	.title{text-align: center;font-size: 24px;margin-top: 30px;margin-bottom: 40px;}
	.input_box{margin-bottom: 20px;}
	input{
		border: 1px solid #ddd;
		padding-left: 15px;
	}
	.input_box input{
		height: 40px;
		line-height: 35px;
	}
	.btn_box{}
	.btn_box button{
		width: 100%;
		height: 40px;
		background-color: #0e90d2;
		color: #fff;
		line-height: 38px;
		border-radius: 2px;
	}
	.hover{background-color: #007AFF;}
	.uni-tip-content{
		display: flex;
		display: -webkit-flex;
		justify-content:center;
		align-items:center;
	}
	.code_inp{width: 150px;height: 35px;margin-right: 14px;}
	.code_img{width: 55px;height: 30px;}
	.link_box{font-size: 12px;padding-top: 10px;}
	.link{color: #0e90d2;}
	/* 提示窗口 */
	.uni-tip {
		padding: 15px;
		width: 300px;
		background: #fff;
		box-sizing: border-box;
		border-radius: 10px;
	}
	
	.uni-tip-title {
		text-align: center;
		font-weight: bold;
		font-size: 16px;
		color: #333;
	}
	
	.uni-tip-content {
		padding: 15px;
		font-size: 14px;
		color: #666;
	}
	
	.uni-tip-group-button {
		margin-top: 10px;
		display: flex;
	}
	
	.uni-tip-button {
		width: 100%;
		text-align: center;
		font-size: 14px;
		color: #3b4144;
	}
	
</style>
