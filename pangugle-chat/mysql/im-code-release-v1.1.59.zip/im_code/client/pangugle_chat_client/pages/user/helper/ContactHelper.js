

const ContactHelper = {
	
	handle : (dataList) => {
		if(dataList.length == 0) return dataList;
		
	}
	
}