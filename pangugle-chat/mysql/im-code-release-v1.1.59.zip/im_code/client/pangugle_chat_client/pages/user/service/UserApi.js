import CacheRequest from '@/pages/framework/http/CacheRequest.js'
import CachePolicy from '@/pages/framework/http/CachePolicy.js'
import ApiRequest from '@/pages/framework/http/ApiRequest.js'
import md5 from '@/pages/framework/utils/md5.js'
import RegexUtils from "@/pages/framework/utils/RegexUtils.js"
import StringUtils from "@/pages/framework/utils/StringUtils.js"

import UserManager from '@/pages/user/logical/UserManager.js'
import UserDefHelper from '@/pages/user/helper/UserDefHelper.js'
import UserCacheHelper from "@/pages/user/helper/UserCacheHelper.js"

const UserApi = {
	
	uploadAvatar(filePath, success, failure)
	{
		let params = {
			filePath : filePath
		}
		let url = '/passport/userApi/uploadAvatarByIM';
		ApiRequest.uploadFile(url, params, (isCache, data) => 
		{
			let userInfo = UserManager.getUserInfo();
			userInfo.avatar = data;
			UserManager.saveUserInfo(userInfo);
			
			//console.log("user api:", userInfo);
			
			success(data);
		}, failure);
	},
	
	updateNickname(nickname, success, failure)
	{
		let params = {
			nickname : nickname
		}
		let url = '/im/userApi/updateNickname';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			let userInfo = UserManager.getUserInfo();
			userInfo.nickname = nickname;
			UserManager.saveUserInfo(userInfo);
			
			success(data);
		}, failure);
	},
	
	/**
	 * 用户名注册
	 */
	registerByUsername : (username, nickname, password, password2, imgCode, success) => {
		let encryPwd = md5(password);
		let encryPwd2 = md5(password2);
		
		let params = {
			'username' : username,
			'nickname' : nickname,
			'password' : encryPwd,
			'password2' : encryPwd2,
			'imgCode' : imgCode
		};
		
		ApiRequest.post('/im/userApi/registerByUsername', params, (isCache, data) => 
		{
			success();
		}, null);
	},
	
	/**
	 * 用户名登陆
	 */
	doLoginByUsername : (username, password, imgCode, success, failure) =>
	{
		
		let encryPwd = md5(password);
		let params = {
			loginname : username,
			password : encryPwd,
			imgCode : imgCode,
			'version' : '1',
		}
		//console.log("encryPwd = " + encryPwd);
		//console.log(params);
		ApiRequest.get('/im/userApi/login', params, 
		// success
		(isCache, res) =>
		{
			// if(!UserManager.isSameUsernameLogin(username))
			// {
			// 	UserCacheHelper.clear();
			// }
			UserCacheHelper.clear();
			UserManager.saveLastLoginUsername(username);
			//console.log(res);
			let loginToken = res.loginToken;
			let accessToken = res.accessToken;
			UserManager.saveLoginToken(loginToken);
			UserManager.saveAccessToken(accessToken)
			
			success();
		},
		// failure
		failure);
	},
	
	/**
	 * 获取accessToken
	 */
	refreshAccessToken(success, failure) {
		ApiRequest.refreshAccessToken(success, failure);
	},
	
	
	getUserInfo(reload, success, failure)
	{
		let params = null;
		if(!reload)
		{
			success(UserManager.getUserInfo());
			return;
		}
		
		ApiRequest.get('/im/userApi/getUserInfo', params, 
		(isCache, data) =>
		{
			data.avatar = UserDefHelper.getAvatar(data.avatar);
			data.nickname = UserDefHelper.getNickname(data.nickname);
			UserManager.saveUserInfo(data);
			if(success) success(data);
		}, failure);
	},
	
	updatePassword(oldpwd, newpwd, newpwd2, success, failure)
	{
		let params = {
			"oldpwd" : md5(oldpwd),
			"newpwd" : md5(newpwd), 
			"newpwd2": md5(newpwd2)
		}
		//console.log(params);
		let url = '/im/userApi/updatePassword';
		ApiRequest.post(url, params, (isCache, data) => 
		{
			success();
		}, failure);
	},
	
	searchUserInfo(friendUsername, reload, success)
	{
		let params = {"username" : friendUsername};
		let cachePolicy = CachePolicy.HTTP_CACHE_POLICY_LOCAL_OR_REMOTE;
		if(reload)
		{
			cachePolicy = CachePolicy.HTTP_CACHE_POLICY_LOCAL_AND_REMOTE;
		}
		
		// 先判断是不是自己
		ApiRequest.getCacheRequest().post('/im/userApi/searchUserInfo?username='+friendUsername, params, cachePolicy, 
		(isCache, data) =>
		{
			data.avatar = UserDefHelper.getAvatar(data.avatar);
			data.nickname = UserDefHelper.getNickname(data.nickname);
			success(data);
		}, (code, msg) => {
			
		});
	},
	
};



export default UserApi