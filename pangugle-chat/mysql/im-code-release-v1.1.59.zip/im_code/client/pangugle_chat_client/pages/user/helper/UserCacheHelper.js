import Cache from '@/pages/framework/cache/Cache.js'
import ChatManager from "@/pages/chat/logical/ChatManager.js"
import ConversationManager from '@/pages/chat/logical/ConversationManager.js'
import UserManager from '@/pages/user/logical/UserManager.js'

const UserCacheHelper = {
	
	/**
	 * 清除所有与用户相关的缓存
	 */
	clear()
	{
		// 会话信息
		ConversationManager.clear();
		
		// 清除所有缓存
		Cache.clearAllCache();
	}
	
}

export default UserCacheHelper