<template>
	
	<view class="mgQrcode-box">
		<view class="mgQrcode">
			<tki-qrcode ref="qrcode"
					:val="myQrcodeConfig.val"
					:size="myQrcodeConfig.size" 
					:onval="myQrcodeConfig.onval" 
					:loadMake="myQrcodeConfig.loadMake" 
					:usingComponents="true"/>
					 
			<p>扫一扫上面的二维码图片，加我为好友</p>
		</view>
		
	</view>
		
		

</template>

<script>
	import tkiQrcode from "@/pages/framework/qrcode/tki-qrcode.vue"
	
	import UserApi from '@/pages/user/service/UserApi.js'
	import QrcodeManager from "@/pages/main/logical/QrcodeManager.js"
	
	export default {
		components: {
			tkiQrcode
		},
		data() {
			return {
				myQrcodeConfig : {
					val: '', // 要生成的二维码值
					size: 220, // 二维码大小
					unit: 'px', // 单位
					background: '#b4e9e2', // 背景色
					foreground: '#309286', // 前景色
					pdground: '#32dbc6', // 角标色
					icon: '', // 二维码图标
					iconsize: 40, // 二维码图标大小
					//lv: 3, // 二维码容错级别 ， 一般不用设置，默认就行
					onval: true, // val值变化时自动重新生成二维码
					loadMake: true, // 组件加载完成后自动生成二维码
				},
				
				myQrcodeValue : ''
			}
		},
		onLoad(options) {
			var self = this;
			UserApi.getUserInfo(false, userInfo => {
				var result = QrcodeManager.generateUserBasicInfo(userInfo.username);
				self.myQrcodeConfig.val = result;
			});
		},
		methods: {
			onQrcodeResult(event)
			{
				console.log(event);
			}
		}
	}
</script>

<style>
	page{
		height: 100%;
	}
	.mgQrcode-box{
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.mgQrcode{
		text-align: center;
		background-color: #fff;
		padding: 30px 30px 20px 30px;border-radius: 2px;
		max-width: 98%;
	}
	.mgQrcode image{padding: 0;margin: 0;}
	p{
		font-size: 12px;
		color: #99999;
		margin-top: 15px;
	}
</style>
