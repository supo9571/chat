
import ConfigHelper from "@/pages/framework/config/ConfigHelper.js"

import UserManager from "@/pages/user/logical/UserManager.js"
import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"
import UserApi from "@/pages/user/service/UserApi.js"

import ChatManager from "@/pages/chat/logical/ChatManager.js"

import ToastUtils from "@/pages/framework/utils/ToastUtils.js"

/**
 * 登陆连接im serve相关
 */
const LogonServer = {
	
	init()
	{
		ChatManager.setLogonServer(this);
		this.isConnectingTask = false;
	},
	
	startListener()
	{
		var timeoutID = this.mTimeoutID || -1;
		let self = this;
		if(timeoutID != -1)
		{
			clearTimeout(timeoutID);
		}
		
		LogonServer.doConnect();
		this.mTimeoutID = setInterval(function(){
			LogonServer.doConnect();
		}, 5000);
	},
	
	/**
	 * 主要是app.vue调用
	 */
	doConnect()
	{
		// 判断是否连接成功，连接成功，结束
		if(!ChatManager.isClose())
		{
			return;
		}
		
		// 判断是否登陆、如果没有登陆，直接退出
		if(!UserManager.isLogin())
		{
			return;
		}
		
		if(!UserManager.isValidAccessToken())
		{
			this.refreshAndConnect(1);
			return;
		}
		
		if(this.isConnectingTask)
		{
			return;
		}
		this.isConnectingTask = true;
		
		// 如果有则关闭
		this.doClose();
		
		// 初始化连接
		let accessToken = UserManager.getAccessToken();
		let serverURL = ConfigHelper.getString('socket_server') + "?accessToken=" + accessToken + "&version=1";
		ChatManager.start(serverURL);
		
		this.isConnectingTask = false;
	},
	
	doHeartCheck()
	{
		return false;
	},
	
	doClose()
	{
		// 消息管理
		ChatManager.close();
	},
	
	/**
	 * 回调方法, 成功连接上服务器
	 */
	onSuccess()
	{
		//console.log("connect server success ......");
	},
	
	/**
	 * 需要验证，什么情况会出错
	 * @param {Object} code
	 * @param {Object} msg
	 */
	onError(code, msg)
	{
		console.log("=========== 与服务端链接失败 =========", msg);
	},
	
	onReceivMessage(protocol)
	{
		console.log("connect server error ......", protocol);
		
		let dataJson = protocol.data;
		let code = dataJson.code;
		
		this.doClose();
		if(code == 10001)
		{
			//DispatchManager.onDisconnect();
			this.refreshAndConnect(1);
		}
		// 被踢下线, 重新登陆
		else if(code == 10002)
		{
			// 跳转到登陆
			UserJumpHelper.jumpToLogin();
		}
		else
		{
			this.refreshAndConnect(1);
		}
	},
	
	/**
	 * 内部方法
	 * @param {Object} retry 重试次数
	 */
	refreshAndConnect(retry)
	{
		//console.log("=====刷新token==== start refreshAndConnect");
		let self = this;
		UserApi.refreshAccessToken(() => {
			//console.log("=====刷新token==== success ");
			self.retry = 0;
			self.doConnect();
		}, (code, msg) => {
			//console.log("=====刷新token==== error, retry count ");
			//return;
			if(retry >= 10)
			{
				self.close();
				//UserJumpHelper.jumpToLogin();
				ToastUtils.showToast("请检查网络,并退出应用重新打开!")
			}
			else
			{
				ToastUtils.showToast("正在重连服务器...")
				retry = retry + 1;
				setTimeout(()=> {
					self.refreshAndConnect(retry);
				}, 2000)
				
			}
		});
	},
	
	
}

export default LogonServer