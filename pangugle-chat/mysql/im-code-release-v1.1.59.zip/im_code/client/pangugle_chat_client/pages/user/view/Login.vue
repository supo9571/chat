<template>
		
	<view class="wrap_login">
		
		<view class="bgcl"></view>
		<view class="blk">
			
			<view class="login_box">
				<!-- <view class="title"></view> -->
				<view class="input_box">
					<input type="text" v-model="name" placeholder="用户名(小写字母+数字>=6位字符)" />
				</view>
				<view class="input_box">
					<input type="password" v-model="pwd" placeholder="密码" />
				</view>
				<view class="btn_box">
				    <button hover-class="hover" @click="login()">登录</button>
				</view>
				<view class="link_box">
					<text>还没有账号？</text>
					<text class="link" @click="jumpToRegister()">去注册</text>
				</view>
				<!-- 验证码弹出框 show: false :show="show" this.show = true -->
				<uni-popup ref="popup" :custom="true" type="center">
					<view class="uni-tip">
						<view class="uni-tip-title">请输入验证码</view>
						<view class="uni-tip-content"> 
							<input class="code_inp" type="text" v-model="code" placeholder="验证码" />
							<!-- <image class="code_img" src="/static/logo.png"></image> -->
						</view>
						<view class="uni-tip-group-button">
							<view class="uni-tip-button" @click="cancel()">取消</view>
							<view class="uni-tip-button" @click="yes()">确定</view>
						</view>
					</view>
				</uni-popup>
			</view>
			
		</view>
		
	</view>
	

</template>
<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	
	// framework
	import StringUtils from '@/pages/framework/utils/StringUtils.js'
	import ToastUtils from '@/pages/framework/utils/ToastUtils.js'
	import ChatManager from '@/pages/chat/logical/ChatManager.js'
	import LogonServer from "@/pages/user/logical/LogonServer.js"
	
	// user
	import UserApi from '@/pages/user/service/UserApi.js'
	import UserJumpHelper from "@/pages/user/helper/UserJumpHelper.js"
	import UserManager from '@/pages/user/logical/UserManager.js'
	
	export default {

		
		components: {
			uniPopup
		},
		data() {
			return {
				name:'',
				pwd:'',
				code:''
			}
		},
		onShow() {
			console.log("login onShow");
			UserManager.deleteUser();
			LogonServer.doClose();
			
			var lastUsername = UserManager.getLastLoginUsername();
			if(lastUsername)
			{
				this.name = lastUsername;
			}
		},
		onHide() {
			console.log("login onHide");
		},
		onUnload() {
			console.log("login onUnload");
		},
		methods: {
			login:function(){
				let that = this;
				// if(this.name==''&&this.pwd==''){
				// 	return;
				// }
				this.code='';
				
				if(StringUtils.isEmpty(this.name) || StringUtils.isEmpty(this.pwd))
				{
					if(process.env.NODE_ENV === 'development'){
						this.name = "test02";
						this.pwd = "123456";
					}else{
					    //console.log('生产环境')
						ToastUtils.showFailure("参数输入有误!");
						return;
					}
				}
				
				UserApi.doLoginByUsername(this.name, this.pwd, null, 
				// success
				() => {
					this.loadUserInfo();
				}, null);
			},
			loadUserInfo()
			{
				UserApi.getUserInfo(true, data => {
					uni.switchTab({
						url:'../../main/home/HomeTabbar',
					});
					
					// 
					LogonServer.doConnect();
				}, null);
			},
			jumpToRegister:function(){
				UserJumpHelper.jumpToRegister();
			},
			
			
			yes:function(){
				this.$refs.popup.close();
			},
			cancel:function(){
				this.$refs.popup.close();
			}
		}
		
	}
</script>

<style>

	page{
		background: #f5f5f5;
		height: 100%;width: 100%;
	}
	.wrap_login{
		height: 100%;width: 100%;
	}
	.bgcl{
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 40%;
		background: #fff linear-gradient(to bottom, #0e90d2, #5bb9e8);
		z-index: 200;
	}
	.blk{
		height: 100%;width: 100%;
		display: flex;
		justify-content:center;
		align-items:center;
	}
	.login_box{
		width: 90%;
		top: 50%;
		background-color: #fff;
		border-radius: 4px;
		box-shadow: 0 0 8px rgba(0, 0, 0, .1);
		padding: 45px 35px 65px 35px;
		margin-top: -30px;
		display: flex;
		display: -webkit-flex;
		flex-direction:column;
		z-index: 700;
	}
	.logo{
		width: 52px;height: 52px;
		margin-left: auto;
		margin-right: auto;
	}
	/* .title{text-align: center;font-size: 50upx;margin-top: 30upx;margin-bottom: 60upx;} */
	.input_box{margin-bottom: 25px;}
	input{
		border: 1px solid #ddd;
		padding-left: 15px;
	}
	.input_box input{
		height: 50px;
		line-height: 25px;
		font-size: 16px;
	}
	.btn_box{}
	.btn_box button{
		width: 100%;
		height: 44px;
		background-color: #0e90d2;
		color: #fff;
		line-height: 44px;
		border-radius: 2px;
		font-size: 19px;
	}
	.hover{background-color: #007AFF;}
	.uni-tip-content{
		display: flex;
		display: -webkit-flex;
		justify-content:center;
		align-items:center;
	}
	.code_inp{width: 150px;height: 35px;margin-right: 14px;}
	.code_img{width: 55px;height: 30px;}
	.link_box{font-size: 14px;padding-top: 15px;}
	.link{color: #0e90d2;}
	/* 提示窗口 */
	.uni-tip {
		padding: 15px;
		width: 300px;
		background: #fff;
		box-sizing: border-box;
		border-radius: 10px;
	}
	
	.uni-tip-title {
		text-align: center;
		font-weight: bold;
		font-size: 16px;
		color: #333;
	}
	
	.uni-tip-content {
		padding: 15px;
		font-size: 14px;
		color: #666;
	}
	
	.uni-tip-group-button {
		margin-top: 10px;
		display: flex;
	}
	
	.uni-tip-button {
		width: 100%;
		text-align: center;
		font-size: 14px;
		color: #3b4144;
	}
	
	@media all and (min-width:500px){
	    page{background: #fff;}
	    .login_box{
	        width: 65%;
	    }
	}
	@media all and (min-width:800px){
	    page{background: #fff;}
	    .login_box{
	        width: 40%;
	    }
	}
</style>